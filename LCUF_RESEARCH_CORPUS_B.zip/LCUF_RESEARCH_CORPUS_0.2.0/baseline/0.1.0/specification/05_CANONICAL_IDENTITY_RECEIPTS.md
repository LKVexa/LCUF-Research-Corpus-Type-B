# Volume 05 — Canonical IR, source identity and receipts

## 5.1 Canonical encoding authority

The authoritative helpers are [`canonical`](../runtime/lcuf.py) (20), `hash_value` (23), IR construction in `compile_source` (181–185), and receipt construction in `simulate` (187–205). Define:

```text
C(v) = json.dumps(v, sort_keys=True, separators=(",",":"),
                  ensure_ascii=False, allow_nan=False)
H(v) = SHA256(UTF8(C(v))) as lowercase 64-hex text
```

This is the runtime's Python JSON encoding recipe. It is not a claim of conformance to a separately standardized canonical-JSON algorithm. Object keys sort; list order remains significant unless the compiler explicitly normalizes a list. Non-ASCII scalar characters remain characters where JSON permits them; required JSON escaping is still applied. Nonfinite floats are disallowed by canonical encoding, and admitted values already contain no floats.

Hash equality is a practical identity comparison under the SHA256 collision assumption; it is not mathematical injectivity of the serializer/digest pair. Canonical JSON equality can be reasoned about independently of cryptographic assumptions. Receipt-chain integrity additionally requires a trusted head or checkpoint outside the chain itself.

<a id="LCUF-ID-001"></a><a id="LCUF-ID-006"></a>
## 5.2 IR construction and compiler version

**LCUF-ID-001 / LCUF-ID-006.** A successful compilation returns:

```text
compiled = { "ir": I, "semantic_sha256": H(I),
             "source_sha256": SHA256(raw_source_bytes) }
```

The IR includes `language`, `module`, `sites`, `grants`, `links`, `rows`, derived `admission`, and `compiler_version="0.1.0"`. A site retains its trust label, memory limit and step limit. The admission object contains `reserved_steps` and `retained_output_bytes` maps. Rows retain every parsed column in normalized form plus a `literal` field for `const`; physical `line` is removed. For constants, `inputs` becomes an empty list, because the literal is a value rather than a named operand. Other input lists retain their ordered names and repetitions.

The version field is part of the semantic hash. It identifies the interpretation used to construct this IR; it is not a proof that an independently supplied object was compiled by that implementation. The reviewed runtime byte hash gives a stronger provenance pin for this research collection. If a future compiler changes semantics without changing its version, a version-only identity scheme would be insufficient; such toolchain governance is a future contract.

The `source_sha256` field is outside `I` and therefore outside `semantic_sha256`. Two source byte sequences can produce one canonical IR and semantic hash. Conversely, the same source under changed runtime semantics is not guaranteed to produce the same IR. Both source and implementation identity are needed for a reproducible provenance claim.

<a id="LCUF-ID-002"></a>
## 5.3 Raw source byte identity

**LCUF-ID-002.** For byte input, source identity hashes the exact input bytes before UTF 8 BOM removal or line/cell normalization. For string input, it hashes the string's UTF 8 encoding. This preserves distinctions among LF/CRLF, BOM/no BOM, indentation, comments, escape spelling and declaration/row presentation order.

The CLI reads source with `Path.read_bytes()`, so it does not perform newline translation before hashing. A byte BOM and CRLF program can have the same semantic hash as the plain LF source while having a different source hash. A raw source hash does not itself show that the source was admitted; admission is established by the compiler invocation and result, under a trusted toolchain assumption.

<a id="LCUF-ID-003"></a><a id="LCUF-ID-005"></a>
## 5.4 Normalization classes and non-equivalences

**LCUF-ID-003.** Changes that preserve parsed data and the graph preserve canonical IR in this reference: comments/blank records, permitted edge whitespace, line-ending/BOM byte differences, order of site/grant declarations, order of directed link declarations, grant-capability order, row effect/capability/`after` order, and source row order. The scheduler—not source order—orders IR rows.

**LCUF-ID-005.** Normalization is intentionally limited. The following details remain significant:

| Detail | Why it remains in identity |
|---|---|
| Ordered input operands | Argument order and repetition are retained; no commutative algebra normalization is implemented |
| Row/output/module/site IDs | They identify graph nodes, bindings and declared policy ownership |
| Explicit `after` members | Even a redundant member is retained as source policy/control metadata |
| Unused sites, grants, links and rows | No declaration or dead-code elimination occurs |
| An absent grant versus `grant site caps=-` | The IR map contains different declaration presence |
| Unicode code-point sequence | No Unicode normalization is applied |
| Evidence selection | Receipt policy changes execution observation and is retained |
| Compiler version | It pins the current IR interpretation |

For example, adding `after=a` to row `b` in the worked program leaves the observed schedule and scalar values unchanged, yet changes semantic identity. Swapping the independent source text rows `a` and `b` preserves identity because graph ordering restores the same row order. Changing `20` to `20.0` is not a normalization example: it rejects typing before IR exists.

The term semantic fingerprint here means the identity of the complete normalized admitted IR. It is not a quotient by every observational equivalence of programs. Equal final output values do not imply equal fingerprints. This protects policy fields from disappearing behind arithmetic equivalence.

<a id="LCUF-ID-004"></a>
## 5.5 Policy sensitivity

**LCUF-ID-004.** Trust labels, capacities, grant lists, directed links, row budgets, exact effect/capability lists and evidence choice are included in `I`. When one of these normalized fields changes while both sources remain admitted, canonical IR changes. Under the hash collision assumption, semantic identity changes.

Changing a trust label can leave all scalar results unchanged. Increasing a site's memory or steps can preserve admission and results. Adding a currently unused capability grant can also preserve results. Their changed semantic hashes correctly signal a changed policy declaration rather than claiming changed arithmetic. Any native adapter must preserve these fields or explicitly state a versioned lowering equivalence; the current host simulator does not supply such an adapter.

<a id="LCUF-SEM-005"></a>
## 5.6 Receipt body and chain recurrence

**LCUF-SEM-005.** Let receipt-selected rows, in schedule order, be `r1,...,rk`. Let `q0="0"×64`. Define the body for row `ri`:

```text
body_i = {
  kind: "LCUF_LOCAL_SIMULATION",
  execution_scope: "single_process_model",
  row: id(ri), site: site(ri), profile: profile(ri),
  semantic_sha256: H(I),
  previous_sha256: q_(i−1),
  result_sha256: H(result(ri))
}
q_i = H(body_i)
receipt_i = body_i extended with {sha256:q_i}
receipt_chain_head = q_k, or q0 if k=0
```

Only the receipt body is hashed; the added `sha256` field is excluded from its own digest. The previous hash links selected observations, not every row. Non-receipt rows can occur between two receipts and remain represented by the common semantic IR identity. Receipts bind row, site and profile explicitly; the result type is represented indirectly through the IR and canonical result representation.

For value operations, the result hash covers the produced scalar. For an assertion it covers `None`/JSON `null` after equality succeeds. For emit it covers the operand. The terminal source type `unit` therefore must not be used to infer the emit result hash.

## 5.7 Worked receipt derivation

In the common program, selected rows are `c,d,f,g`. Write `h42=H(42)` and `hu=H(None)`:

```text
c: result=h42, previous=0^64, q1=H(body_c)
d: result=h42, previous=q1,   q2=H(body_d)
f: result=hu,  previous=q2,   q3=H(body_f)
g: result=h42, previous=q3,   q4=H(body_g)
```

The repeated result digest does not make the receipt bodies equal: their row/site/profile and previous digests differ. The final head is `q4`. Thirty focused reference observations include verification of this recurrence, the row filter, the null assertion result and the scalar emit result. Exact golden hashes are in [`REFERENCE_CHECKS.json`](REFERENCE_CHECKS.json), tied to the pinned runtime and example source identity.

## 5.8 What receipt integrity does and does not establish

Given a trusted `qk`, the complete ordered receipt sequence, the IR semantic identity, and collision resistance, a verifier can compare the bodies and recurrence to detect altered records or truncation relative to that trusted head. The runtime provides construction, not a complete standalone external verifier. A chain supplied with an equally untrusted head can be recreated from invented bodies. SHA256 is not a signature and does not authenticate an owner.

There is no receipt source hash, clock, nonce, run identifier, verifier key, transport acknowledgment or hardware attestation field. Replaying the same compiled object deterministically produces the same receipt sequence and head. That is reference replay consistency, not freshness or replay protection. The constant scope strings deliberately prevent interpreting these records as network/device qualification or MSSL resealing.

<a id="LCUF-ID-007"></a>
## 5.9 External object integrity is not admission authenticity

**LCUF-ID-007.** `simulate` checks the hash of its `ir` object against the supplied semantic digest. A changed IR without an updated digest rejects with `IR hash mismatch`. A changed IR with a recomputed digest can pass that check. The digest check establishes consistency between those two supplied fields, not compiler origin, source correspondence, capability validity or schema completeness.

The CLI always obtains the compiled object from source admission and exposes no external IR-loading command. Its trust boundary is therefore narrower than a general IR execution service. Any future loader must revalidate type, graph, capabilities, resources, version and canonical fields and bind trusted toolchain/source provenance; adding a signature still would not replace semantic admission. Volume 08 states that extension contract without asserting it is implemented.
