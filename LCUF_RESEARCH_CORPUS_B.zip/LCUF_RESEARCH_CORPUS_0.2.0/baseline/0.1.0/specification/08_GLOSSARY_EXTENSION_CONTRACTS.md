# Volume 08 — Glossary and extension contracts

## 8.1 Controlled vocabulary

| Term | Meaning in this collection |
|---|---|
| Admission | Successful syntax, structural, type, effect, grant, graph, value and resource checks in `compile_source` |
| Admitted object | The unmodified return value of successful compilation under the pinned runtime |
| Arity | Number of ordered value references required by an operation; const uses a literal rather than a value reference |
| Assertion | Same-type local scalar equality tested at compilation and simulation |
| Binding | A globally named immutable output and its unique producer |
| Budget | Positive source-declared per-row abstract step reservation |
| Capability | A static named requirement checked against a site grant; not a signed credential |
| Canonical encoding | The precise `canonical` Python JSON recipe |
| Canonical IR | Complete normalized admitted declaration/row/policy data and derived admission with compiler version |
| Cell | A stripped component of a record split by raw ASCII pipe |
| Columned | A source format with exactly twelve ordered named fields per row |
| Compiler evaluation | The finite value computation performed during admission |
| Copy | Explicit value-preserving remote-to-local binding creation in the single-process model |
| Dependency | An input-producer edge or explicit same-site `after` edge |
| Diagnostic | A `Diagnostic` exception message, optionally prefixed by a physical LF line number |
| Directed link | Declared `(from,to)` permission shape for modeled copy; not a live connection |
| Effect | An exact operation-contract name set checked statically |
| Emit | A terminal evidence operation requiring evidence.write and receipt selection |
| Evidence selection | `none` or `receipt` in a row; optional host instrumentation except emit's mandatory receipt |
| External IR | An object not established to be the unmodified output of trusted source compilation |
| Forward reference | An input/dependency referring to a writer/row later in source presentation order |
| Grant | One capability-list declaration per site; absence means empty permission set for checking |
| Graph order | The one-at-a-time lexicographically least-ready topological sequence |
| Host reference | The Python implementation executing the closed subset in one process |
| i64 | Signed integer domain [−2^63,2^63−1] excluding booleans |
| Identity | A name or cryptographic digest with its specified namespace and trust assumptions |
| Instrumentation | Local observation recorded by the simulator, without implied external I/O authority |
| IR hash check | Equality of a supplied semantic digest with the digest of the supplied IR; not provenance authentication |
| Logical record | Nonempty noncomment record after LF splitting and edge stripping |
| Module | One declared source identity; not an importable Python/native module |
| Named output | A non-`-` output installed in the global writer map |
| Payload byte | A byte counted by the retained-value measure, excluding object/serialization overhead |
| Physical record | A substring delimited by literal LF in decoded source |
| Profile | A closed owner string associated with an operation in `OPS` |
| Receipt | A local simulation result body with semantic/result/previous hashes and its body digest |
| Receipt head | Last body digest, or 64 zero characters for no receipts |
| Reservation sum | Sum of all row budgets at one site, including terminal/unused rows |
| Retained output | A named value binding kept through the end of the model evaluation |
| Row | One operation, policy metadata and graph identity represented by twelve cells |
| Scalar | An admitted i64, bool or UTF 8 encodable text value |
| Semantic fingerprint | Digest of normalized complete IR; not all-program observational equivalence |
| Site | A declared location in the local model, with trust/resource metadata and optional grants |
| Source hash | SHA256 of input bytes before parser normalization, or UTF 8 bytes of supplied text |
| Terminal operation | assert_eq/emit with source type unit and output `-` |
| Trust domain label | A retained identifier naming intended ownership context, with no current authentication behavior |
| Unit | Terminal source type; `None` as a host result for successful assertion instrumentation |
| Unikernel plan | A design-only target object with null images and unmet build/transport gates |
| Value store | Immutable output-name map built in graph order |

## 8.2 Future contract status

Every contract below is **future/unimplemented** in `LCUF/0.1`. No grammar production, operation or authority is added by naming a contract. A later implementation must select a new versioned specification, define accepted syntax and error behavior, and supply positive/negative conformance evidence. These contracts are research obligations rather than commitments that a backend already exists.

### LCUF-EXT-001 — Trusted external-IR admission

A loader needs a complete schema and duplicate-field policy; exact supported language/compiler identities; row and output uniqueness; closed operation/profile/type contracts; exact effects/capabilities; known sites/grants/links; defined references and graph ordering; value/overflow/assertion evaluation; independent resource recomputation; and canonical identity comparison. It must decide whether source bytes and trusted compiler provenance are mandatory and how signatures, if any, bind them. A consistent recomputable hash alone cannot establish admission. Diagnostics must distinguish malformed IR, version mismatch, provenance failure and semantic rejection.

### LCUF-EXT-002 — Complete native resource closure

A native backend needs an image/data layout, allocator and stack discipline, codegen temporary bounds, library/driver dependency closure, receipt and transfer buffers, and enforceable per-site memory/time models. Its adapter must show how current retained-output and reservation fields map to physical limits. Native overflow, text representation and copy ownership must agree with the current semantics or be versioned explicitly. Boot success with one example is insufficient: boundary rejection, crash and resource exhaustion cases are needed.

### LCUF-EXT-003 — Authenticated transport and site ownership

A real transfer requires an identity and trust policy independent of user-chosen labels; versioned authenticated request/receipt schemas; source/destination capabilities with issuer, scope, expiry and revocation; link establishment and denial behavior; bounded queues; acknowledgment and replay policies; and clear failure states. Local copy may serve as a value-level reference equation, but cannot stand in for these protocols. Source grants must never be translated into verified authentication without external authority.

### LCUF-EXT-004 — Asynchronous dependency semantics

Independent site workers need a partial-order execution contract, message/event identities, completion/failure propagation, ordering under retries, and a policy for nondeterministic interleavings. The current serial schedule and receipt chain are deterministic reference choices. A parallel implementation needs either a refinement theorem preserving allowed observations or a new version describing changed observation order. Explicit cross-site control dependencies would require implemented protocol semantics; they cannot simply bypass current `after` locality.

### LCUF-EXT-005 — Lifetime and ownership calculus

Release, move, borrow, shared references, mutable state and device reservations require resource kinds, ownership transitions, alias rules, lifetime checks and corresponding operational transitions. The current copy is duplication of scalar bindings and retains the sender. A proposed linear type system cannot retroactively be attributed to it. The payload proof must be revised if outputs are released, reallocated, serialized or held in transit.

### LCUF-EXT-006 — Signed, fresh execution evidence

Evidence beyond local replay needs verifier/issuer identity, authenticated signatures, algorithm/version identifiers, source and toolchain binding, unique execution context, challenge or nonce, epoch/time policy and scope-specific attestations. It must specify what device or transport event is actually attested, how trust anchors are provisioned, and how replay/truncation is detected. The current chain is useful construction evidence but has no freshness or owner signature.

### LCUF-EXT-007 — Versioned domain-profile adapters

JA, DeepML, LCTL, MSSL, MCRT and coupling8s need owner-specific grammar, operator semantics and authoritative maturity boundaries. An adapter must preserve raw source identity and policy metadata, state its supported subset, define exact input/output/error mappings, and demonstrate positive and denial cases. MSSL authority bytes cannot be rewritten under an unrelated receipt format. JA arithmetic must bind the actual user-supplied mechanics semantics rather than silently equating it with conventional i64 addition. Registry metadata is a discovery mechanism, not proof of an adapter.

### LCUF-EXT-008 — Formalization and independent verification

A mechanically checked model would need executable syntax definitions, exact decoding/Unicode assumptions, finite-map/set/order lemmas, JSON encoding semantics or a pinned serializer model, arithmetic bounds, proof of compiler evaluation and simulation refinement, and an explicit trusted computing base. A receipt verifier should be independent of the constructor. The human-readable proofs here can guide that effort, but no formal-machine result is claimed.

## 8.3 Implemented planning boundary

<a id="LCUF-SEM-006"></a>
**LCUF-SEM-006.** [`target_plan`](../runtime/lcuf.py) returns `status=design_plan_only`, a compiler version, semantic identity, per-site trust/resource/capability summaries, a candidate adapter label, `bootable_image=None`, and a list of required gates. This is a planning projection from already admitted data. It does not call a builder, install a toolchain, fetch dependencies, boot a VM or establish transport.

[`simulate`](../runtime/lcuf.py) explicitly returns `native_unikernel_built=False` and `physical_federation_executed=False`. These scope fields must remain associated with derived examples and dataset labels. An institutional research collection may catalog a target and its obligations; it cannot convert a design-plan status into production readiness through documentation alone.

## 8.4 Unresolved specification boundaries

The predecessor EBNF described only admitted integer/bool/text constants and approximated newline/whitespace behavior. This collection additionally documents the parser's JSON float/null recognition followed by type rejection, and distinguishes physical LF preprocessing from Unicode text characters. These are descriptive refinements, not changes to accepted admitted programs.

The direct-IR precondition remains explicit and observed by `REF-025`. Whole-process resource limits, native backend closure, peer authentication, receipt freshness, external receipt verification and the domain-profile compilers remain unimplemented. No critical defect requiring mutation of the pinned runtime was found during this formal-volume work. Any subsequent runtime fix must update the byte pin, traceability, observations and derived assumptions together.
