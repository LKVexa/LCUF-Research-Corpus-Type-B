# LCUF 0.1 formal specification collection

This collection specifies the implemented `LCUF/0.1` language and Python host reference, runtime version `0.1.0`. It is a research specification of an existing finite, deterministic subset: declaration parsing, static type and capability admission, dependency scheduling, constant evaluation, retained-output accounting, canonical intermediate representation, local simulation, and hash-chain instrumentation. It supplies explicit judgments and scoped proof sketches. It does not claim institutional endorsement, a mechanically checked proof, native unikernel execution, authenticated transport, or device qualification.

The normative implementation reference is [`runtime/lcuf.py`](../runtime/lcuf.py), whose reviewed SHA256 is `e205b88168564ae63d75bd05f3e35b09cc69d983dd7cc7f994883b797c785b8f`. Function names and line ranges in the rule registry are tied to that byte identity. The predecessor draft is [`LCUF_SPEC.md`](../provenance/upstream_snapshot/fabric_language/LCUF_SPEC.md). In a discrepancy, this collection describes observed runtime behavior and records the difference explicitly; it does not silently invent accepted syntax or modify the reference implementation.

The selected upstream evidence snapshot preserves these referenced artifacts, their original bytes and their paths within the upstream release. Its selection and provenance are documented in the release's provenance records.

## Volumes and machine-readable companions

| Artifact | Subject and intended use |
|---|---|
| [01_LEXICAL_GRAMMAR.md](01_LEXICAL_GRAMMAR.md) | Byte decoding, physical/logical lines, exact declaration and cell syntax, JSON boundaries, syntax versus admission |
| [LCUF_0_1.ebnf](LCUF_0_1.ebnf) | Precise grammar over the runtime's preprocessed logical lines, with stated side conditions |
| [02_STATIC_TYPES_EFFECTS_CAPABILITIES.md](02_STATIC_TYPES_EFFECTS_CAPABILITIES.md) | Static environments, closed operation contracts, value/output typing, effects, grants, site and link admission |
| [03_DEPENDENCY_OPERATIONAL_SEMANTICS.md](03_DEPENDENCY_OPERATIONAL_SEMANTICS.md) | Dependency graph, deterministic linear extension, compiler evaluation and simulator transitions |
| [04_RETAINED_PAYLOAD_RESOURCE_CALCULUS.md](04_RETAINED_PAYLOAD_RESOURCE_CALCULUS.md) | Positive resource domains, step reservations, exact model payload measure, conservative retention, exclusions |
| [05_CANONICAL_IDENTITY_RECEIPTS.md](05_CANONICAL_IDENTITY_RECEIPTS.md) | Canonical IR, normalization classes, source identity, evidence hashes and receipt-chain semantics |
| [06_PROPOSITIONS_PROOF_SKETCHES.md](06_PROPOSITIONS_PROOF_SKETCHES.md) | Explicit assumptions, determinism, progress, preservation, locality, resource and identity propositions with limits |
| [07_DIAGNOSTICS_TRACEABILITY.md](07_DIAGNOSTICS_TRACEABILITY.md) | Full diagnostic taxonomy, phase precedence, rule-to-function-to-observation traceability |
| [08_GLOSSARY_EXTENSION_CONTRACTS.md](08_GLOSSARY_EXTENSION_CONTRACTS.md) | Vocabulary, interpretation boundaries and separately labeled future contracts |
| [RULES.json](RULES.json) | Stable requirement IDs, rule meanings, source references, volume anchors and scope |
| [DIAGNOSTICS.json](DIAGNOSTICS.json) | Exact implemented diagnostic strings or templates, research taxonomy IDs and requirements |
| [TRACEABILITY.json](TRACEABILITY.json) | Requirement mapping and observed check coverage, with explicit coverage gaps |
| [REFERENCE_CHECKS.json](REFERENCE_CHECKS.json) | Thirty executed focused observations against the pinned reference |
| [SPECIFICATION_MANIFEST.json](SPECIFICATION_MANIFEST.json) | File byte counts and hashes, with method/scope and no self-referential digest |
| [SPECIFICATION_VALIDATION.json](SPECIFICATION_VALIDATION.json) | Runtime pin, rule/diagnostic coverage, local-link/anchor and grammar-symbol validation |

## Interpretation discipline

The words **implemented**, **derived**, **observed**, and **future contract** have distinct meanings. An implemented rule restates executable admission or execution behavior. A derived proposition is a mathematical argument about that finite model under named assumptions. An observed check records a concrete Python execution; thirty checks are not exhaustive proof. A future contract is a design obligation with no current parser form or runtime authority.

Notation such as `Γ ⊢ r : τ` is metalanguage. It cannot appear in an LCUF source file. The only accepted operation names are `const`, `add`, `mul`, `copy`, `assert_eq`, and `emit`; the only accepted source type labels are `i64`, `bool`, `text`, and `unit`. A site and trust label are declarations in a local model. Their names do not establish peer identity, ownership, network reachability, or authentication.

Requirement prefixes are fixed: `LCUF-LEX-*`, `LCUF-TYPE-*`, `LCUF-CAP-*`, `LCUF-GRAPH-*`, `LCUF-RES-*`, `LCUF-ID-*`, and `LCUF-SEM-*`. The first 37 IDs retain the collection-level dataset meanings. Additional IDs refine boundaries without renumbering those rules. Diagnostic taxonomy IDs `LCUF-DIAG-*`, proposition IDs `LCUF-PROP-*`, observation IDs `REF-*`, and future contract IDs `LCUF-EXT-*` are research metadata, not emitted runtime error codes.

## Common worked program

The seven-row `demo.federated_sum` program from the frozen baseline is used across volumes. Sites `edge` and `cloud` each declare `memory=64 steps=8`; `edge` grants `fabric.send`; `cloud` grants `fabric.receive,evidence.write`; the directed link is `edge → cloud`. The value rows compute `left=20`, `right=22`, `total=42`, copy `total` into `received=42`, and declare `expected=42`. The terminal rows assert equality and emit a local receipt. The graph order is `a,b,c,d,e,f,g`; reserved steps are `edge:3, cloud:4`; retained model payload is `edge:24, cloud:16` bytes. Receipt-bearing rows are `c,d,f,g`.

The complete text is preserved in the embedded frozen [baseline example](../provenance/upstream_snapshot/fabric_language/examples/federated_sum.lcuf). Derived numeric and identity observations are recorded in `REFERENCE_CHECKS.json`. This example demonstrates directed transfer in one process. It does not demonstrate physical federation.

## Research use and reproduction limits

Use rule IDs when labeling training examples, rejection cases, proofs, implementation gaps, or adapter requirements. A case can involve more than one rule. The first observed rejection depends on compiler phase order and can differ from the broad reason a dataset annotator intended. Preserve both the exact diagnostic and the intended invariant rather than equating them.

This collection does not contain a parser generator proof, an independently verified receipt verifier, or a trusted external-IR admission path. The CLI compiles source before simulation. Direct calls to `simulate` assume compiler-produced, unmodified, admitted IR; recomputing a hash over a modified IR does not establish that assumption. Future trust boundaries are enumerated in volume 08. All propositions are consequently scoped to successful `compile_source` results and the pinned reference version unless explicitly stated otherwise.
