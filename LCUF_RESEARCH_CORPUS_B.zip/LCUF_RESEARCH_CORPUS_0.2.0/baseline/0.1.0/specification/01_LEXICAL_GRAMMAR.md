# Volume 01 — Lexical structure and grammar

## 1.1 Authority and grammar domain

The implementation references are [`parse`](../runtime/lcuf.py) (line 42), `identity` (25), `names` (36), `positive_integer` (29), and the decoding prefix of `compile_source` (108). [`LCUF_0_1.ebnf`](LCUF_0_1.ebnf) defines the accepted logical-line shapes. Semantic side conditions are necessary: a context-free grammar alone cannot require one writer, known sites, profile ownership, acyclic dependencies, or value bounds.

We distinguish raw bytes `B`, decoded text `S`, physical records `P`, logical records `L`, parsed structure `p`, and admitted IR `I`. The pipeline is `B → S → P → L → p → I`. Failure at any stage rejects the source; no following stage repairs an invalid earlier form. For callers supplying a Python string, `B = UTF8(S)` is constructed for source identity; the byte-decoding stage is absent. This distinction matters for a leading byte-order mark.

<a id="LCUF-LEX-008"></a><a id="LCUF-LEX-011"></a>
## 1.2 UTF 8 and byte versus string entry

**LCUF-LEX-008 / LCUF-LEX-011.** Byte input is decoded by `utf-8-sig`. A leading UTF 8 BOM is removed from parser text but retained in the raw source digest. Invalid UTF 8 rejects with `source is not UTF 8`. A second BOM, a BOM in a later position, or a BOM supplied as a character in a string is not a general whitespace exemption. `compile_source("\ufeffLCUF/0.1...")` fails the header; `compile_source(b"\xef\xbb\xbfLCUF/0.1...")` can succeed. This is observed behavior, not a claim that BOMs have semantic significance.

Text values must encode with Python's strict UTF 8 encoder. `"\ud800"` is JSON-shaped but its decoded unpaired surrogate is rejected. A valid escaped surrogate pair that decodes to a scalar can be admitted. Unicode normalization is not performed: canonically equivalent strings such as a precomposed accent and a base-plus-combining-mark sequence remain distinct scalar payloads and normally produce different semantic hashes. UTF 8 validity establishes a character encoding contract; it does not establish locale, collation or grapheme length.

<a id="LCUF-LEX-010"></a>
## 1.3 Physical and logical records

**LCUF-LEX-010.** The parser splits on the literal LF character `\n`, then strips both ends of each physical record using `str.strip()`. Empty records and records whose stripped first character is `#` are discarded. Original one-based physical LF line numbers are retained for diagnostics. The logical sequence is therefore:

```text
L = [(n, strip(Pn)) | strip(Pn) ≠ "" ∧ not starts_with(strip(Pn), "#")]
```

This is not `splitlines()`. U+0085, U+2028 and U+2029 can occur inside a JSON text cell without splitting the row. Ordinary CRLF works because the terminal CR is stripped. A lone CR between declarations does not establish a physical record boundary. Unicode whitespace stripped at a record or cell edge is governed by the Python host's Unicode predicates; it is not pinned to an independent LCUF Unicode table.

Comments are full-record comments only. A suffix `# commentary` following a declaration or row is source content and ordinarily causes a diagnostic. Comment records after `end` are ignored before the end-state machine runs, while any noncomment logical record after `end` rejects. A source need not end with LF. Indentation and blank-record placement do not affect admitted IR but do affect raw source identity.

<a id="LCUF-LEX-001"></a><a id="LCUF-LEX-002"></a>
## 1.4 Header and first declaration

**LCUF-LEX-001.** The first logical record must equal `LCUF/0.1` exactly. Other versions, case variants, appended tokens and a missing header reject with `required header LCUF/0.1`. Leading comment/blank records are permitted by preprocessing. The header is not a switch that selects another language implementation.

**LCUF-LEX-002.** The first following declaration must be one module declaration. Its prefix is the exact string `module ` with an ASCII space. After that prefix check, `.split()` must yield exactly two tokens; thus `module   demo` is accepted whereas `module\tdemo` does not pass the prefix test. The module identifier then passes `identity`. Exactly one module is required. Later module declarations reject as duplicates before the row section, and are malformed rows after the section boundary.

The parser recognizes `end` before the module-first guard, but an early `end` never produces an admitted empty program: the final required-components check rejects it. This state-machine detail matters when assigning diagnostic labels to intentionally incomplete sources.

<a id="LCUF-LEX-003"></a>
## 1.5 Declaration syntax, order and uniqueness

**LCUF-LEX-003.** Before the column header, the permitted declaration forms are:

```text
site SITE trust=TRUST memory=DIGITS steps=DIGITS
grant SITE caps=NAMES
link FROM TO transfer=copy
```

Spaces displayed here are exact single ASCII spaces. Site field order is fixed: `trust`, `memory`, `steps`. There is no arbitrary key/value parser. Double spaces between site keywords, a reordered field, trailing extra tokens, or an unsupported transfer kind reject. Module declarations have the separately described whitespace behavior.

Site names are unique. A site may have at most one grant declaration. Directed `(from,to)` link pairs are unique, and self-links reject. `from→to` and `to→from` are different declarations. Grants and links can precede the corresponding site declarations after the module, because known-site checks occur after parsing the entire source. At least one site is required. There is no requirement that every site be used, granted capabilities, or incident to a link.

No declaration is allowed after the exact column boundary. An unfamiliar declaration before it yields `unknown declaration or invalid column header`; a declaration-like string after it is interpreted by the twelve-cell row parser and fails accordingly. This is why diagnostic categorization must record parser phase.

<a id="LCUF-LEX-004"></a>
## 1.6 Identifiers and separate namespaces

**LCUF-LEX-004.** An identifier matches `[A-Za-z_][A-Za-z0-9_.-]*`. The first character is an ASCII letter or underscore; later characters may additionally be ASCII digits, dot or hyphen. Identifiers are case sensitive and have no declared maximum length. Dots are ordinary identifier characters, not a namespace-resolution operator. Unicode letters, embedded whitespace, a leading digit and empty identifiers reject.

Module, site, trust, row, output, profile, effect, capability and `after` names use this lexical predicate. Their semantic namespaces differ. A row identity may equal an output identity; a site may equal a trust label. Only the specified uniqueness constraints apply. Names such as `lcuf.scalar` look qualified but profile ownership is a closed string comparison, not dynamic import or registry lookup.

<a id="LCUF-LEX-005"></a>
## 1.7 Column boundary and twelve cells

**LCUF-LEX-005.** A logical record is split on raw ASCII `|`, and each resulting cell is stripped. The declaration-to-row transition occurs only when those stripped cells equal, in order:

```text
id | site | profile | op | inputs | output | type | effects | caps | after | budget | evidence
```

This permits optional whitespace around separators and at record edges; it does not permit renamed, duplicated, reordered or additional columns. Every subsequent row must contain exactly twelve cells. There is no quoting layer protecting the delimiter itself. A raw pipe inside a JSON string creates an extra cell; use `\u007c` to represent a pipe payload. That escape is decoded by JSON, not by a general LCUF escape rule.

<a id="LCUF-LEX-006"></a>
## 1.8 Lists and repeated operands

**LCUF-LEX-006.** `-` alone is the empty-list sentinel. Otherwise a list is split at commas and each untrimmed item must be an identifier. Internal whitespace in `left, right` invalidates the second item, even though whitespace around the entire cell is stripped. An empty member, trailing comma or empty cell rejects.

Effects, row capabilities, `after`, and grant capabilities are distinct-member lists. Their presentation order is later normalized. Non-`const` inputs are ordered operand lists and may repeat: `add left,left` is meaningful and consumes two references to one immutable value. Dependency construction converts producer row IDs into a set, so the repeated operand supplies one graph edge but two evaluation arguments. There is no mismatch between those two representations.

<a id="LCUF-LEX-007"></a>
## 1.9 JSON syntax versus admitted scalar values

**LCUF-LEX-007.** A `const` input cell is decoded as a complete JSON scalar. Leading `[` or `{` is rejected explicitly; JSON decoding rejects trailing content and malformed escapes. Nonstandard `NaN`, `Infinity` and `-Infinity` decoder constants trigger `nonfinite literal`. The grammar includes ordinary JSON numbers, strings, booleans and `null` because those are recognized scalar forms. Successful admission is narrower: `i64` accepts bounded Python integers excluding booleans, `bool` accepts booleans, and `text` accepts UTF 8 encodable strings. Float-valued JSON numbers, including `1.0`, have no admitted source type. JSON `null` decodes to `None`, but `const` is a value operation and cannot have `unit`, so there is no admitted null constant.

The phrase “bounded JSON scalar” in a diagnostic does not imply a fixed source-size bound. The implementation prevents some nesting paths, caps resource numeral length, and checks i64 values; it does not impose a text literal byte limit before decoding. Compiler process exhaustion is outside the language's retained-payload model.

<a id="LCUF-LEX-009"></a>
## 1.10 End-state and complete program predicate

**LCUF-LEX-009.** Exactly one logical `end` closes the source. A missing end marker rejects. Any later logical content, including a second `end`, rejects with a physical line number. A program is structurally complete only if it has a module, one or more sites, the exact column boundary, and one or more rows. Those conditions are independent of whether all semantic admission checks subsequently pass.

A parser success is not compiler success. For example, `const null → unit`, an unknown grant site, a cycle, and an overflowing multiplication have different failure stages after structural recognition. Dataset annotations should label the exact stage and rule, rather than classifying every rejection as a syntax error. The phase taxonomy is in [volume 07](07_DIAGNOSTICS_TRACEABILITY.md).
