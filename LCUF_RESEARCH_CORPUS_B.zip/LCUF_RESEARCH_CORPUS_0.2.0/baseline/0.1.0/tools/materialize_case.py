"""Extract the exact bytes of one core case for compiler comparison."""
import argparse, base64, gzip, json, pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]

def find(record_id):
    with gzip.open(ROOT/'datasets/core_conformance.jsonl.gz','rt',encoding='utf-8') as stream:
        for raw in stream:
            record=json.loads(raw)
            if record['record_id']==record_id: return record
    raise ValueError('Unknown core record: '+record_id)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('record_id'); parser.add_argument('--out',type=pathlib.Path,required=True); parser.add_argument('--paired',action='store_true'); args=parser.parse_args()
    record=find(args.record_id); key='paired_source' if args.paired else 'source'
    if key not in record: parser.error('This record has no paired source')
    if args.out.exists(): parser.error('Output exists; select a new output path')
    args.out.parent.mkdir(parents=True,exist_ok=True); args.out.write_bytes(base64.b64decode(record[key]['bytes_base64'],validate=True))
    print(json.dumps({'record_id':args.record_id,'source_sha256':record[key]['sha256'],'output':str(args.out),'expected':record['expected']},indent=2))
