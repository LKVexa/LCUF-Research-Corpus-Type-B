"""Deterministically construct and actually evaluate the LCUF core research corpus.

Expected scalar answers are specified independently of runtime outputs by the
construction. Rejections identify one intended violated contract. This is synthetic
conformance evidence, not a native execution, training, or proof certificate.
"""
from __future__ import annotations
import base64, collections, gzip, hashlib, importlib.util, json, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
COLS = 'id | site | profile | op | inputs | output | type | effects | caps | after | budget | evidence'
MAX, MIN = 2**63-1, -(2**63)
PROFILES = {'const':'lcuf.scalar','add':'lcuf.scalar','mul':'lcuf.scalar',
            'copy':'lcuf.fabric','assert_eq':'lcuf.test','emit':'lcuf.evidence'}
POSITIVE_VARIANTS, NEGATIVE_VARIANTS, METAMORPHIC_VARIANTS = 128, 48, 96

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def equal_json(a,b): return canonical(a)==canonical(b)
def digest(raw): return hashlib.sha256(raw).hexdigest()
def dump(p,x): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def literal(x): return json.dumps(x,ensure_ascii=False,allow_nan=False).replace('|','\\u007c')

def row(rid,site,op,inputs,out,typ='i64',after='-',budget=1,evidence='none',effects=None,caps=None):
    effects = ('fabric.transfer' if op=='copy' else 'evidence.emit' if op=='emit' else '-') if effects is None else effects
    caps = ('fabric.receive' if op=='copy' else 'evidence.write' if op=='emit' else '-') if caps is None else caps
    return ' | '.join(map(str,(rid,site,PROFILES[op],op,inputs,out,typ,effects,caps,after,budget,evidence)))

def program(name,rows,sites=None,grants=(),links=()):
    sites = sites or [('s','owner',4096,4096)]
    lines=['LCUF/0.1','module '+name]
    lines += [f'site {s} trust={t} memory={m} steps={b}' for s,t,m,b in sites]
    lines += [f'grant {s} caps={c}' for s,c in grants]
    lines += [f'link {a} {b} transfer=copy' for a,b in links]
    return '\n'.join(lines+[COLS]+rows+['end',''])

def base(n=0):
    x,y=n+3,2*n+5
    return program(f'case_{n}',[
        row('a','s','const',literal(x),'x'),row('b','s','const',literal(y),'y'),
        row('c','s','add','x,y','sum',evidence='receipt')])

def remote(n=0,typ='i64',value=None):
    value=n+7 if value is None else value
    return program(f'remote_{n}',[row('a','a','const',literal(value),'origin',typ),
        row('b','b','copy','origin','received',typ,evidence='receipt')],
        [('a','owner_a',4096,4096),('b','owner_b',4096,4096)],
        [('a','fabric.send'),('b','fabric.receive')],[('a','b')])

def positive(family,n):
    x,y=n+3,2*n+5; name=f'{family}_{n}'; requirements=['LCUF-SEM-001']
    rows=[]; sites=None; grants=(); links=(); expected={}; order=None
    if family=='signed_constant':
        v=(-1 if n%2 else 1)*(n+1); rows=[row('a','s','const',literal(v),'value')]; expected={'value':v}
    elif family=='boolean_constant':
        v=bool(n%2); rows=[row('a','s','const',literal(v),'value','bool')]; expected={'value':v}
    elif family=='unicode_text':
        v=f'JA λ 数学 {n} \u2028end\u0085\u2029'; rows=[row('a','s','const',literal(v),'value','text')]; expected={'value':v}; requirements+=['LCUF-LEX-008','LCUF-RES-003']
    elif family=='escaped_delimiter':
        v=f'left|right:{n}'; rows=[row('a','s','const',literal(v),'value','text')]; expected={'value':v}; requirements+=['LCUF-LEX-005','LCUF-LEX-007']
    elif family in ('signed_add','signed_multiply','additive_identity','zero_multiply','repeated_operand'):
        a,b=(-x,y) if family in ('signed_add','signed_multiply') else (x,0)
        op='mul' if family in ('signed_multiply','zero_multiply') else 'add'
        operand='x,x' if family=='repeated_operand' else 'x,y'
        z=a*a if family=='repeated_operand' and op=='mul' else 2*a if family=='repeated_operand' else a*b if op=='mul' else a+b
        rows=[row('a','s','const',literal(a),'x'),row('b','s','const',literal(b),'y'),row('c','s',op,operand,'result')]; expected={'x':a,'y':b,'result':z}; requirements+=['LCUF-TYPE-005','LCUF-TYPE-006']
    elif family in ('minimum_i64','maximum_i64'):
        v=MIN+n if family=='minimum_i64' else MAX-n; rows=[row('a','s','const',literal(v),'value')]; expected={'value':v}; requirements+=['LCUF-TYPE-001','LCUF-TYPE-006']
    elif family=='exact_resource_boundary':
        rows=[row('a','s','const',literal(x),'x',budget=n+1),row('b','s','const',literal(y),'y'),row('c','s','add','x,y','result')]; expected={'x':x,'y':y,'result':x+y}; sites=[('s','owner',24,n+3)]; requirements+=['LCUF-RES-001','LCUF-RES-002','LCUF-RES-003']
    elif family=='explicit_local_order':
        rows=[row('z','s','const',literal(x),'x'),row('a','s','const',literal(y),'y',after='z'),row('b','s','add','x,y','result')]; expected={'x':x,'y':y,'result':x+y}; order=['z','a','b']; requirements+=['LCUF-GRAPH-003','LCUF-GRAPH-005']
    elif family=='forward_operand_reference':
        rows=[row('a','s','add','x,y','result'),row('c','s','const',literal(y),'y'),row('b','s','const',literal(x),'x')]; expected={'x':x,'y':y,'result':x+y}; order=['b','c','a']; requirements+=['LCUF-GRAPH-002','LCUF-GRAPH-005']
    elif family=='newly_ready_precedence':
        rows=[row('z','s','const',literal(y),'y'),row('b','s','const',literal(x+1),'next',after='a'),row('a','s','const',literal(x),'x')]; expected={'x':x,'next':x+1,'y':y}; order=['a','b','z']; requirements+=['LCUF-GRAPH-005']
    elif family=='diamond_dag':
        rows=[row('a','s','const',literal(x),'x'),row('b','s','add','x,x','twice'),row('c','s','mul','x,x','square'),row('d','s','add','twice,square','result')]; expected={'x':x,'twice':2*x,'square':x*x,'result':x*x+2*x}; requirements+=['LCUF-GRAPH-004','LCUF-GRAPH-005']
    elif family=='long_arithmetic_chain':
        rows=[row('a','s','const',literal(x),'x'),row('b','s','const','1','one')]; expected={'x':x,'one':1}; prev='x'
        for k in range(3+n%17):
            out=f'value_{k}'; rows.append(row(f'r{k:02d}','s','add',prev+',one',out)); expected[out]=x+k+1; prev=out
        requirements+=['LCUF-GRAPH-002','LCUF-RES-002']
    elif family=='fanout_dag':
        rows=[row('a','s','const',literal(x),'x')]; expected={'x':x}
        for k in range(2+n%11): rows.append(row(f'r{k:02d}','s','add','x,x',f'v{k}')); expected[f'v{k}']=2*x
        requirements+=['LCUF-GRAPH-001','LCUF-RES-003']
    elif family in ('copy_integer','copy_boolean','copy_text'):
        typ='i64' if family=='copy_integer' else 'bool' if family=='copy_boolean' else 'text'; v=x if typ=='i64' else bool(n%2) if typ=='bool' else f'copy λ|{n}'
        return remote(n,typ,v),{'values':{'origin':v,'received':v}},['LCUF-SEM-002','LCUF-CAP-001','LCUF-CAP-002','LCUF-CAP-003','LCUF-CAP-004','LCUF-TYPE-005']
    elif family=='reverse_directed_transfer':
        rows=[row('a','b','const',literal(x),'origin'),row('b','a','copy','origin','received')]; sites=[('a','a_owner',4096,4096),('b','b_owner',4096,4096)]; grants=[('b','fabric.send'),('a','fabric.receive')]; links=[('b','a')]; expected={'origin':x,'received':x}; requirements+=['LCUF-SEM-002','LCUF-CAP-004']
    elif family=='three_site_route':
        rows=[row('a','s0','const',literal(x),'origin'),row('b','s1','copy','origin','middle'),row('c','s2','copy','middle','received')]; sites=[(f's{k}',f'owner_{k}',4096,4096) for k in range(3)]; grants=[('s0','fabric.send'),('s1','fabric.send,fabric.receive'),('s2','fabric.receive')]; links=[('s0','s1'),('s1','s2')]; expected={'origin':x,'middle':x,'received':x}; requirements+=['LCUF-SEM-002','LCUF-CAP-003','LCUF-CAP-004']
    elif family=='site_cycle_acyclic_program':
        rows=[row('a','s0','const',literal(x),'origin'),row('b','s1','copy','origin','middle'),row('c','s0','copy','middle','returned')]; sites=[('s0','owner0',4096,4096),('s1','owner1',4096,4096)]; grants=[('s0','fabric.receive,fabric.send'),('s1','fabric.receive,fabric.send')]; links=[('s0','s1'),('s1','s0')]; expected={'origin':x,'middle':x,'returned':x}; requirements+=['LCUF-GRAPH-004','LCUF-SEM-002']
    elif family=='local_receipt_without_grant':
        rows=[row('a','s','const',literal(x),'value',evidence='receipt')]; expected={'value':x}; requirements+=['LCUF-SEM-005','LCUF-CAP-001']
    elif family=='explicit_evidence_emit':
        rows=[row('a','s','const',literal(x),'value'),row('b','s','emit','value','-','unit',evidence='receipt')]; grants=[('s','evidence.write')]; expected={'value':x}; requirements+=['LCUF-SEM-004','LCUF-SEM-005','LCUF-CAP-002']
    elif family in ('integer_assertion','boolean_assertion','text_assertion'):
        typ='i64' if family=='integer_assertion' else 'bool' if family=='boolean_assertion' else 'text'; v=x if typ=='i64' else bool(n%2) if typ=='bool' else f'equality_{n}'
        rows=[row('a','s','const',literal(v),'x',typ),row('b','s','const',literal(v),'y',typ),row('c','s','assert_eq','x,y','-','unit',evidence='receipt')]; expected={'x':v,'y':v}; requirements+=['LCUF-SEM-003','LCUF-TYPE-004','LCUF-TYPE-005']
    elif family=='empty_text_zero_payload':
        rows=[row('a','s','const','""','empty','text',budget=n+1)]; sites=[('s','owner',1,n+1)]; expected={'empty':''}; requirements+=['LCUF-RES-003']
    elif family=='unused_grants_preserved':
        rows=[row('a','s','const',literal(x),'value')]; grants=[('s','declared.future_cap')]; expected={'value':x}; requirements+=['LCUF-ID-001','LCUF-ID-004']
    elif family=='remote_after_local_copy':
        rows=[row('a','a','const',literal(x),'origin'),row('b','b','copy','origin','received'),row('c','b','const',literal(y),'other',after='b'),row('d','b','add','received,other','result')]; sites=[('a','ownera',4096,4096),('b','ownerb',4096,4096)]; grants=[('a','fabric.send'),('b','fabric.receive')]; links=[('a','b')]; expected={'origin':x,'received':x,'other':y,'result':x+y}; requirements+=['LCUF-GRAPH-003','LCUF-SEM-002']
    else: raise KeyError(family)
    oracle={'values':expected}
    if order is not None: oracle['row_order']=order
    return program(name,rows,sites,grants,links),oracle,requirements

POSITIVE_FAMILIES=['signed_constant','boolean_constant','unicode_text','escaped_delimiter','signed_add','signed_multiply','additive_identity','zero_multiply','repeated_operand','minimum_i64','maximum_i64','exact_resource_boundary','explicit_local_order','forward_operand_reference','newly_ready_precedence','diamond_dag','long_arithmetic_chain','fanout_dag','copy_integer','copy_boolean','copy_text','reverse_directed_transfer','three_site_route','site_cycle_acyclic_program','local_receipt_without_grant','explicit_evidence_emit','integer_assertion','boolean_assertion','text_assertion','empty_text_zero_payload','unused_grants_preserved','remote_after_local_copy']

NEGATIVES={}
def negative(name,needle,rule,fn): NEGATIVES[name]=(needle,rule,fn)

negative('wrong_version','required header','LCUF-LEX-001',lambda s,n:s.replace('LCUF/0.1','LCUF/0.2'))
negative('missing_header','required header','LCUF-LEX-001',lambda s,n:s.split('\n',1)[1])
negative('module_not_first','first declaration','LCUF-LEX-002',lambda s,n:s.replace(f'module case_{n}\n','').replace('site s',f'module case_{n}\nsite s') .replace(f'LCUF/0.1\nmodule case_{n}\nsite s',f'LCUF/0.1\nsite s'))
negative('duplicate_module','duplicate module','LCUF-LEX-003',lambda s,n:s.replace('module ', 'module duplicate\nmodule ',1))
negative('invalid_module_id','invalid identifier','LCUF-LEX-004',lambda s,n:s.replace(f'module case_{n}','module 7invalid'))
negative('module_extra_operand','one identifier','LCUF-LEX-003',lambda s,n:s.replace(f'module case_{n}',f'module case_{n} extra'))
negative('duplicate_site','duplicate site','LCUF-LEX-003',lambda s,n:s.replace(COLS,'site s trust=owner memory=64 steps=8\n'+COLS))
negative('site_field_order','site requires','LCUF-LEX-003',lambda s,n:s.replace('trust=owner memory=4096','memory=4096 trust=owner'))
negative('invalid_trust_label','invalid identifier','LCUF-LEX-004',lambda s,n:s.replace('trust=owner','trust=9owner'))
negative('zero_site_memory','resource integer','LCUF-RES-001',lambda s,n:s.replace('memory=4096','memory=0'))
negative('zero_site_steps','resource integer','LCUF-RES-001',lambda s,n:s.replace('steps=4096','steps=0'))
negative('leading_zero_resource','resource integer','LCUF-RES-001',lambda s,n:s.replace('memory=4096','memory=04096'))
negative('negative_site_resource','site requires','LCUF-RES-001',lambda s,n:s.replace('memory=4096','memory=-1'))
negative('oversized_site_resource','signed 64 bit','LCUF-RES-001',lambda s,n:s.replace('memory=4096',f'memory={MAX+n+1}'))
negative('unicode_resource_digits','site requires','LCUF-RES-001',lambda s,n:s.replace('steps=4096','steps=٤٠٩٦'))
negative('resource_digit_exhaustion','resource integer','LCUF-RES-001',lambda s,n:s.replace('memory=4096','memory='+'9'*(100+n)))
negative('duplicate_grant','duplicate grant','LCUF-LEX-003',lambda s,n:s.replace(COLS,'grant s caps=-\ngrant s caps=-\n'+COLS))
negative('unknown_grant_site','grant names an unknown','LCUF-LEX-003',lambda s,n:s.replace(COLS,'grant ghost caps=-\n'+COLS))
negative('duplicate_grant_cap','duplicate list item','LCUF-LEX-006',lambda s,n:s.replace(COLS,'grant s caps=evidence.write,evidence.write\n'+COLS))
negative('malformed_grant','invalid grant','LCUF-LEX-003',lambda s,n:s.replace(COLS,'grant s cap=evidence.write\n'+COLS))
negative('invalid_cap_identifier','invalid identifier','LCUF-LEX-004',lambda s,n:s.replace(COLS,'grant s caps=7invalid\n'+COLS))
negative('self_link','distinct sites','LCUF-CAP-004',lambda s,n:s.replace(COLS,'link s s transfer=copy\n'+COLS))
negative('unsupported_transfer','transfer=copy','LCUF-CAP-004',lambda s,n:s.replace(COLS,'link s other transfer=share\n'+COLS))
negative('unknown_link_site','link names an unknown','LCUF-CAP-004',lambda s,n:s.replace(COLS,'link s ghost transfer=copy\n'+COLS))
negative('unknown_declaration','unknown declaration','LCUF-LEX-003',lambda s,n:s.replace(COLS,'ambient allow_all\n'+COLS))
negative('column_order','invalid column header','LCUF-LEX-005',lambda s,n:s.replace('id | site | profile','profile | site | id',1))
negative('column_missing','invalid column header','LCUF-LEX-005',lambda s,n:s.replace(COLS,COLS.rsplit(' | ',1)[0]))
negative('column_extra','invalid column header','LCUF-LEX-005',lambda s,n:s.replace(COLS,COLS+' | driver'))
negative('row_missing_cell','expected 12 cells','LCUF-LEX-005',lambda s,n:s.replace(' | 1 | none',' | 1',1))
negative('row_extra_cell','expected 12 cells','LCUF-LEX-005',lambda s,n:s.replace(' | 1 | none',' | 1 | none | extra',1))
negative('invalid_row_identity','invalid identifier','LCUF-LEX-004',lambda s,n:s.replace('\na | s','\n9a | s',1))
negative('invalid_row_site','invalid identifier','LCUF-LEX-004',lambda s,n:s.replace('\na | s','\na | 9s',1))
negative('invalid_profile_identity','invalid identifier','LCUF-LEX-004',lambda s,n:s.replace('lcuf.scalar','9profile',1))
negative('unknown_operation','unsupported operation','LCUF-TYPE-002',lambda s,n:s.replace('| add |','| execute |'))
negative('wrong_profile_owner','does not belong','LCUF-TYPE-002',lambda s,n:s.replace('lcuf.scalar | add','lcuf.fabric | add'))
negative('duplicate_row_identity','duplicate row id','LCUF-GRAPH-001',lambda s,n:s.replace('\nb | s','\na | s',1))
negative('duplicate_output_writer','multiple writers','LCUF-GRAPH-001',lambda s,n:s.replace(f'{2*n+5} | y |',f'{2*n+5} | x |'))
negative('unknown_row_site','unknown site','LCUF-LEX-003',lambda s,n:s.replace('\na | s','\na | ghost',1))
negative('arity_one','wrong operation arity','LCUF-TYPE-003',lambda s,n:s.replace('x,y | sum','x | sum'))
negative('arity_three','wrong operation arity','LCUF-TYPE-003',lambda s,n:s.replace('x,y | sum','x,y,x | sum'))
negative('unknown_type','unsupported type','LCUF-TYPE-001',lambda s,n:s.replace(' | i64 |',' | tensor |',1))
negative('value_unit_type','value operation requires','LCUF-TYPE-004',lambda s,n:s.replace(' | i64 |',' | unit |',1))
negative('missing_value_output','value operation requires','LCUF-TYPE-004',lambda s,n:s.replace(f'{n+3} | x |',f'{n+3} | - |'))
negative('boolean_as_integer','value violates type','LCUF-TYPE-001',lambda s,n:s.replace(f'{n+3} | x |','true | x |'))
negative('integer_as_boolean','value violates type','LCUF-TYPE-001',lambda s,n:s.replace(f'{n+3} | x | i64',f'{n+3} | x | bool'))
negative('floating_constant','value violates type','LCUF-TYPE-001',lambda s,n:s.replace(f'{n+3} | x |',f'{n+3}.5 | x |'))
negative('null_constant','value violates type','LCUF-TYPE-001',lambda s,n:s.replace(f'{n+3} | x |','null | x |'))
negative('array_constant','JSON scalar','LCUF-LEX-007',lambda s,n:s.replace(f'{n+3} | x |',f'[{n}] | x |'))
negative('object_constant','JSON scalar','LCUF-LEX-007',lambda s,n:s.replace(f'{n+3} | x |','{"a":1} | x |'))
negative('nonfinite_constant','nonfinite','LCUF-LEX-007',lambda s,n:s.replace(f'{n+3} | x |','NaN | x |'))
negative('constant_above_i64','value violates type','LCUF-TYPE-001',lambda s,n:s.replace(f'{n+3} | x |',f'{MAX+n+1} | x |'))
negative('constant_below_i64','value violates type','LCUF-TYPE-001',lambda s,n:s.replace(f'{n+3} | x |',f'{MIN-n-1} | x |'))
negative('malformed_json_constant','bounded JSON scalar','LCUF-LEX-007',lambda s,n:s.replace(f'{n+3} | x |','"unclosed | x |'))
negative('deep_nested_constant','JSON scalar','LCUF-LEX-007',lambda s,n:s.replace(f'{n+3} | x |','['*(100+n)+'0'+']'*(100+n)+' | x |'))
negative('unpaired_unicode_surrogate','unpaired Unicode','LCUF-LEX-008',lambda s,n:s.replace(f'{n+3} | x | i64','"\\ud800" | x | text'))
negative('raw_delimiter_in_literal','expected 12 cells','LCUF-LEX-005',lambda s,n:s.replace(f'{n+3} | x | i64',f'"part|{n}" | x | text'))
negative('invalid_utf8_source','not UTF 8','LCUF-LEX-008',lambda s,n:s.encode('utf-8')+b'\xff')
negative('missing_end','missing end','LCUF-LEX-009',lambda s,n:s.rsplit('end',1)[0])
negative('content_after_end','content after end','LCUF-LEX-009',lambda s,n:s+'module forbidden\n')
negative('missing_site','module, sites','LCUF-LEX-003',lambda s,n:s.replace('site s trust=owner memory=4096 steps=4096\n',''))
negative('missing_rows','rows are required','LCUF-LEX-005',lambda s,n:s.split(COLS)[0]+COLS+'\nend\n')
negative('undefined_operand','undefined input','LCUF-GRAPH-002',lambda s,n:s.replace('x,y | sum','x,ghost | sum'))
negative('undefined_after','undefined dependency','LCUF-GRAPH-002',lambda s,n:s.replace(' | - | - | - | 1 | none',' | - | - | ghost | 1 | none',1))
negative('self_dependency','dependency cycle','LCUF-GRAPH-004',lambda s,n:s.replace(' | - | - | - | 1 | none',' | - | - | a | 1 | none',1))
negative('two_row_cycle','dependency cycle','LCUF-GRAPH-004',lambda s,n:s.replace(f'{n+3} | x | i64 | - | - | -',f'{n+3} | x | i64 | - | - | b').replace(f'{2*n+5} | y | i64 | - | - | -',f'{2*n+5} | y | i64 | - | - | a'))
negative('operand_type_mismatch','input type mismatch','LCUF-TYPE-005',lambda s,n:s.replace(f'{n+3} | x | i64','true | x | bool'))
negative('extra_pure_effect','operation contract','LCUF-CAP-001',lambda s,n:s.replace(' | i64 | - | - | -',' | i64 | evidence.emit | - | -',1))
negative('extra_pure_capability','operation contract','LCUF-CAP-001',lambda s,n:s.replace(' | i64 | - | - | -',' | i64 | - | evidence.write | -',1))
negative('duplicate_effect','duplicate list item','LCUF-LEX-006',lambda s,n:s.replace(' | i64 | - | - | -',' | i64 | evidence.emit,evidence.emit | - | -',1))
negative('duplicate_after','duplicate list item','LCUF-LEX-006',lambda s,n:s.replace(' | - | - | - | 1 | receipt',' | - | - | a,a | 1 | receipt'))
negative('operand_internal_space','invalid identifier','LCUF-LEX-006',lambda s,n:s.replace('x,y | sum','x, y | sum'))
negative('wrong_evidence_mode','evidence must','LCUF-SEM-005',lambda s,n:s.replace(' | 1 | receipt',' | 1 | attestation'))
negative('zero_row_budget','resource integer','LCUF-RES-001',lambda s,n:s.replace(' | 1 | none',' | 0 | none',1))
negative('negative_row_budget','resource integer','LCUF-RES-001',lambda s,n:s.replace(' | 1 | none',' | -1 | none',1))
negative('leading_zero_row_budget','resource integer','LCUF-RES-001',lambda s,n:s.replace(' | 1 | none',' | 01 | none',1))
negative('unicode_row_budget','resource integer','LCUF-RES-001',lambda s,n:s.replace(' | 1 | none',' | ١ | none',1))
negative('oversized_row_budget','resource integer','LCUF-RES-001',lambda s,n:s.replace(' | 1 | none',f' | {MAX+n+1} | none',1))
negative('step_reservation_exceeded','step admission','LCUF-RES-002',lambda s,n:s.replace('steps=4096','steps=2'))
negative('payload_memory_exceeded','memory admission','LCUF-RES-003',lambda s,n:s.replace('memory=4096','memory=23'))
negative('integer_add_overflow','value violates type','LCUF-TYPE-006',lambda s,n:s.replace(f'{n+3} | x |',f'{MAX} | x |'))
negative('integer_mul_overflow','value violates type','LCUF-TYPE-006',lambda s,n:s.replace(f'{n+3} | x |',f'{MAX} | x |').replace('| add |','| mul |'))

def custom_negative(family,n):
    s=remote(n); rule='LCUF-CAP-004'
    if family=='missing_directed_link': return s.replace('link a b transfer=copy\n',''),'no directed',rule
    if family=='reversed_directed_link': return s.replace('link a b','link b a'),'no directed',rule
    if family=='duplicate_directed_link': return s.replace('link a b transfer=copy','link a b transfer=copy\nlink a b transfer=copy'),'duplicate link',rule
    if family=='sender_grant_denied': return s.replace('caps=fabric.send','caps=-'),'sender lacks','LCUF-CAP-003'
    if family=='receiver_grant_denied': return s.replace('caps=fabric.receive','caps=-'),'capability denied','LCUF-CAP-002'
    if family=='copy_effect_erasure': return s.replace('fabric.transfer | fabric.receive','- | fabric.receive'),'operation contract','LCUF-CAP-001'
    if family=='copy_capability_erasure': return s.replace('fabric.transfer | fabric.receive','fabric.transfer | -'),'operation contract','LCUF-CAP-001'
    if family=='copy_type_mismatch': return s.replace('received | i64','received | bool'),'input type mismatch','LCUF-TYPE-005'
    if family=='implicit_remote_arithmetic':
        return s.replace(row('b','b','copy','origin','received',evidence='receipt'),row('b','b','add','origin,origin','received',evidence='receipt')),'cross-site input','LCUF-SEM-002'
    if family=='same_site_copy': return s.replace('b | b | lcuf.fabric','b | a | lcuf.fabric').replace('grant a caps=fabric.send','grant a caps=fabric.send,fabric.receive'),'different source site','LCUF-SEM-002'
    if family=='cross_site_after': return s.replace(' | fabric.transfer | fabric.receive | -',' | fabric.transfer | fabric.receive | a'),'cross-site after','LCUF-GRAPH-003'
    if family in ('failed_assertion','assertion_type_mismatch','terminal_wrong_type','terminal_has_output'):
        second_value=n+2 if family=='failed_assertion' else n+1
        text=program(family+str(n),[row('a','s','const',literal(n+1),'x'),row('b','s','const',literal(second_value),'y'),row('c','s','assert_eq','x,y','-','unit')])
        if family=='failed_assertion': return text,'constant assertion fails','LCUF-SEM-003'
        if family=='assertion_type_mismatch': return text.replace(f'{second_value} | y | i64','true | y | bool'),'different types','LCUF-TYPE-005'
        if family=='terminal_wrong_type': return text.replace('- | unit','- | i64'),'terminal operation','LCUF-TYPE-004'
        return text.replace('x,y | - | unit','x,y | invalid | unit'),'terminal operation','LCUF-TYPE-004'
    if family in ('emit_grant_denied','emit_without_receipt'):
        text=program(family+str(n),[row('a','s','const',literal(n+1),'x'),row('b','s','emit','x','-','unit',evidence='receipt')],grants=[('s','evidence.write')])
        if family=='emit_grant_denied': return text.replace('caps=evidence.write','caps=-'),'capability denied','LCUF-CAP-002'
        return text.replace(' | 1 | receipt',' | 1 | none'),'emit requires receipt','LCUF-SEM-004'
    raise KeyError(family)

CUSTOM_NEGATIVES=['missing_directed_link','reversed_directed_link','duplicate_directed_link','sender_grant_denied','receiver_grant_denied','copy_effect_erasure','copy_capability_erasure','copy_type_mismatch','implicit_remote_arithmetic','same_site_copy','cross_site_after','failed_assertion','assertion_type_mismatch','terminal_wrong_type','terminal_has_output','emit_grant_denied','emit_without_receipt']
METAMORPHIC_FAMILIES=['comment_invariance','blank_line_invariance','cell_spacing_invariance','crlf_invariance','bom_invariance','source_row_permutation','grant_order_invariance','link_order_invariance','trust_identity_change','memory_identity_change','step_identity_change','budget_identity_change','evidence_identity_change','module_identity_change']

def metamorphic(family,n):
    a=base(n).replace(f'module case_{n}',f'module {family}.case_{n}'); same=True; rule='LCUF-ID-003'
    if family=='comment_invariance': b='# ignored comment '+str(n)+'\n'+a
    elif family=='blank_line_invariance': b=a.replace('\n','\n\n')
    elif family=='cell_spacing_invariance': b=a.replace(' | ','|')
    elif family=='crlf_invariance': b=a.replace('\n','\r\n').encode('utf-8')
    elif family=='bom_invariance': b=b'\xef\xbb\xbf'+a.encode('utf-8')
    elif family=='source_row_permutation':
        lines=a.splitlines(); at=lines.index(COLS); b='\n'.join(lines[:at+1]+list(reversed(lines[at+1:-1]))+['end',''])
    elif family=='grant_order_invariance':
        a=a.replace(COLS,'grant s caps=cap.a,cap.b\n'+COLS); b=a.replace('caps=cap.a,cap.b','caps=cap.b,cap.a')
    elif family=='link_order_invariance':
        a=positive('site_cycle_acyclic_program',n)[0].replace('module site_cycle_acyclic_program_', 'module link_order_'); b=a.replace('link s0 s1 transfer=copy\nlink s1 s0 transfer=copy','link s1 s0 transfer=copy\nlink s0 s1 transfer=copy')
    elif family=='trust_identity_change': b=a.replace('trust=owner','trust=other_owner'); same=False; rule='LCUF-ID-004'
    elif family=='memory_identity_change': b=a.replace('memory=4096','memory=4097'); same=False; rule='LCUF-ID-004'
    elif family=='step_identity_change': b=a.replace('steps=4096','steps=4097'); same=False; rule='LCUF-ID-004'
    elif family=='budget_identity_change': b=a.replace(' | 1 | none',' | 2 | none',1); same=False; rule='LCUF-ID-004'
    elif family=='evidence_identity_change': b=a.replace(' | 1 | none',' | 1 | receipt',1); same=False; rule='LCUF-ID-004'
    elif family=='module_identity_change': b=a.replace('module ','module alternate.',1); same=False; rule='LCUF-ID-001'
    else: raise KeyError(family)
    return a,b,same,rule

def load_runtime(root=ROOT):
    spec=importlib.util.spec_from_file_location('lcuf_research_reference',pathlib.Path(root)/'runtime/lcuf.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def source_record(source):
    raw=source if isinstance(source,bytes) else source.encode('utf-8')
    try: text=raw.decode('utf-8')
    except UnicodeError: text=None
    return {'encoding':'base64','bytes_base64':base64.b64encode(raw).decode('ascii'),'utf8_text':text,'sha256':digest(raw)}

def evaluate(runtime,source):
    raw=source if isinstance(source,bytes) else source.encode('utf-8')
    try: c=runtime.compile_source(raw)
    except runtime.Diagnostic as e: return {'admission':'reject','diagnostic':str(e),'native_execution':False}
    simulation=runtime.simulate(c); replay=runtime.simulate(c)
    if not equal_json(simulation,replay): raise AssertionError('reference replay is not deterministic')
    if c['source_sha256']!=digest(raw) or c['semantic_sha256']!=digest(canonical(c['ir']).encode('utf-8')): raise AssertionError('source/IR identity mismatch')
    previous='0'*64
    selected=[r for r in c['ir']['rows'] if r['evidence']=='receipt']
    if len(simulation['receipts'])!=len(selected): raise AssertionError('receipt-selected row coverage mismatch')
    for receipt,r in zip(simulation['receipts'],selected):
        body={k:v for k,v in receipt.items() if k!='sha256'}
        result=None if r['op']=='assert_eq' else simulation['values'][r['inputs'][0]] if r['op']=='emit' else simulation['values'][r['output']]
        expected_body={'kind':'LCUF_LOCAL_SIMULATION','execution_scope':'single_process_model','row':r['id'],'site':r['site'],'profile':r['profile'],'semantic_sha256':c['semantic_sha256'],'previous_sha256':previous,'result_sha256':digest(canonical(result).encode('utf-8'))}
        if not equal_json(body,expected_body): raise AssertionError('receipt result/row/policy binding mismatch')
        if receipt['previous_sha256']!=previous or digest(canonical(body).encode('utf-8'))!=receipt['sha256']: raise AssertionError('receipt integrity mismatch')
        previous=receipt['sha256']
    if previous!=simulation['receipt_chain_head']: raise AssertionError('receipt head mismatch')
    plan=runtime.target_plan(c)
    if plan['status']!='design_plan_only' or any(s['bootable_image'] is not None for s in plan['sites'].values()): raise AssertionError('native plan overclaim')
    # Independent retained payload size calculation from admitted values and row owners.
    expected_memory={s:0 for s in c['ir']['sites']}
    expected_steps={s:0 for s in c['ir']['sites']}
    for r in c['ir']['rows']:
        expected_steps[r['site']]+=r['budget']
        if r['output']=='-': continue
        v=simulation['values'][r['output']]
        size=len(v.encode('utf-8')) if isinstance(v,str) else 1 if isinstance(v,bool) else 8
        expected_memory[r['site']]+=size
    if c['ir']['admission']!={'reserved_steps':expected_steps,'retained_output_bytes':expected_memory}: raise AssertionError('resource accounting mismatch')
    return {'admission':'accept','semantic_sha256':c['semantic_sha256'],'source_sha256':c['source_sha256'],
            'values':simulation['values'],'row_order':[r['id'] for r in c['ir']['rows']],
            'resources':c['ir']['admission'],'receipt_count':len(simulation['receipts']),
            'receipt_chain_head':simulation['receipt_chain_head'],'native_execution':False,'execution_scope':'single_process_model'}

def partition(family):
    # Family-disjoint partitioning prevents parameter variants crossing partitions.
    bucket=int(digest(family.encode('ascii'))[:8],16)%10
    return 'challenge' if bucket<2 else 'development' if bucket<4 else 'reference'

def generate():
    runtime=load_runtime(); records=[]; sample_paths=[]; seen=set(); failures=[]
    for polarity,families,count in [('accept',POSITIVE_FAMILIES,POSITIVE_VARIANTS),('reject',list(NEGATIVES)+CUSTOM_NEGATIVES,NEGATIVE_VARIANTS),('metamorphic',METAMORPHIC_FAMILIES,METAMORPHIC_VARIANTS)]:
        for family in families:
            for n in range(count):
                rec={'schema_version':'lcuf.core.record.0.1','record_id':f'LCUF-{len(records)+1:06d}','corpus_version':'0.1.0','language':'LCUF/0.1','reference_version':runtime.VERSION,'family':family,'variant':n,'partition':partition(family),'construction':'deterministic_synthetic','execution_authority':'host_reference_only','native_execution_eligible':False}
                if polarity=='accept':
                    source,oracle,rules=positive(family,n); observation=evaluate(runtime,source)
                    expected={'admission':'accept','oracle_kind':'construction_analytic_scalar','values':oracle['values']}
                    if 'row_order' in oracle: expected['row_order']=oracle['row_order']
                    matched=observation['admission']=='accept' and equal_json(observation['values'],oracle['values']) and ('row_order' not in oracle or observation['row_order']==oracle['row_order'])
                elif polarity=='reject':
                    if family in NEGATIVES:
                        needle,rule,fn=NEGATIVES[family]; source=fn(base(n),n)
                    else: source,needle,rule=custom_negative(family,n)
                    observation=evaluate(runtime,source); rules=[rule]
                    expected={'admission':'reject','oracle_kind':'isolated_contract_mutation','diagnostic_contains':needle}
                    matched=observation['admission']=='reject' and needle in observation['diagnostic']
                else:
                    source,second,same,rule=metamorphic(family,n); first=evaluate(runtime,source); second_observed=evaluate(runtime,second); rules=[rule,'LCUF-ID-002']
                    expected={'admission':'metamorphic','oracle_kind':'specified_identity_relation','same_semantic_identity':same,'different_source_identity':True}
                    matched=first['admission']=='accept' and second_observed['admission']=='accept' and (first['semantic_sha256']==second_observed['semantic_sha256'])==same and source_record(source)['sha256']!=source_record(second)['sha256']
                    observation={'admission':'metamorphic','first':first,'second':second_observed,'native_execution':False}
                    rec['paired_source']=source_record(second)
                rec.update(source=source_record(source),requirement_ids=rules,expected=expected,observed=observation,verification='PASS' if matched else 'FAIL')
                if not matched: failures.append({'record_id':rec['record_id'],'family':family,'variant':n,'expected':expected,'observed':observation})
                if rec['source']['sha256'] in seen: failures.append({'record_id':rec['record_id'],'error':'duplicate primary source bytes'})
                seen.add(rec['source']['sha256']); records.append(rec)
                if n==0:
                    path=ROOT/'examples'/polarity/(family+'.lcuf' if rec['source']['utf8_text'] is not None else family+'.invalid-utf8.bin')
                    path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(base64.b64decode(rec['source']['bytes_base64'])); sample_paths.append(path.relative_to(ROOT).as_posix())
    if failures:
        dump(ROOT/'validation/BUILD_FAILURES.json',failures); raise RuntimeError(f'{len(failures)} core construction checks failed')
    master=ROOT/'datasets/core_conformance.jsonl.gz'; master.parent.mkdir(parents=True,exist_ok=True)
    def write_gz(path,rows):
        with path.open('wb') as raw:
            with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as zipped:
                for record in rows: zipped.write((canonical(record)+'\n').encode('utf-8'))
    write_gz(master,records)
    for part in ('reference','development','challenge'): write_gz(ROOT/f'datasets/core_{part}.jsonl.gz',[r for r in records if r['partition']==part])
    family_counts=collections.Counter(r['family'] for r in records)
    summary={'status':'PASS','records':len(records),'positive_records':sum(r['expected']['admission']=='accept' for r in records),'negative_records':sum(r['expected']['admission']=='reject' for r in records),'metamorphic_pairs':sum(r['expected']['admission']=='metamorphic' for r in records),'source_program_evaluations':len(records)+sum('paired_source' in r for r in records),'unique_primary_source_bytes':len(seen),'family_count':len(family_counts),'positive_families':len(POSITIVE_FAMILIES),'negative_families':len(NEGATIVES)+len(CUSTOM_NEGATIVES),'metamorphic_families':len(METAMORPHIC_FAMILIES),'family_counts':dict(sorted(family_counts.items())),'partitions':dict(collections.Counter(r['partition'] for r in records)),'family_partition_isolation':True,'runtime_sha256':digest((ROOT/'runtime/lcuf.py').read_bytes()),'master_sha256':digest(master.read_bytes()),'representative_examples':len(sample_paths),'scope':'Synthetic conformance families with parameter variation; stored records are not independent designs, formal proofs, native runs or training generalization evidence.'}
    dump(ROOT/'validation/CORE_BUILD.json',summary)
    dump(ROOT/'datasets/CORE_FAMILY_REGISTRY.json',[{'family':f,'polarity':'accept' if f in POSITIVE_FAMILIES else 'metamorphic' if f in METAMORPHIC_FAMILIES else 'reject','partition':partition(f),'variants':family_counts[f]} for f in family_counts])
    dump(ROOT/'examples/INDEX.json',sample_paths)
    print(json.dumps({k:v for k,v in summary.items() if k not in ('family_counts',)},indent=2))

if __name__=='__main__': generate()
