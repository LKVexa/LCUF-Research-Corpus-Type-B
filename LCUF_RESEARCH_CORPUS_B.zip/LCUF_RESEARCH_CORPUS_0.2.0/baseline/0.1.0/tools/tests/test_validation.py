import copy, gzip, json, pathlib, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import build_core, validate_core

class CorpusValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        schema=json.loads((ROOT/'schemas/core_record.schema.json').read_text(encoding='utf-8'))
        cls.validator=validate_core.Draft202012Validator(schema); cls.runtime=build_core.load_runtime(); cls.samples={}
        with gzip.open(ROOT/'datasets/core_conformance.jsonl.gz','rt',encoding='utf-8') as stream:
            for raw in stream:
                r=json.loads(raw); cls.samples.setdefault(r['expected']['admission'],r)
                if r['family']=='boolean_constant' and r['variant']==1: cls.boolean=r
                if len(cls.samples)==3 and hasattr(cls,'boolean'): break
    def test_three_record_classes(self):
        for r in self.samples.values(): self.assertEqual(validate_core.check_record(r,self.validator,self.runtime),[])
    def test_source_bytes_corruption(self):
        r=copy.deepcopy(self.samples['accept']); r['source']['bytes_base64']='QQ=='
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_utf8_projection_corruption(self):
        r=copy.deepcopy(self.samples['accept']); r['source']['utf8_text']+=' '
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_false_native_claim(self):
        r=copy.deepcopy(self.samples['accept']); r['native_execution_eligible']=True
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_expected_value_corruption(self):
        r=copy.deepcopy(self.samples['accept']); r['expected']['values']['value']+=1
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_observed_value_corruption(self):
        r=copy.deepcopy(self.samples['accept']); r['observed']['values']['value']+=1
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_diagnostic_oracle_corruption(self):
        r=copy.deepcopy(self.samples['reject']); r['expected']['diagnostic_contains']='unrelated denial'
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_semantic_relation_corruption(self):
        r=copy.deepcopy(self.samples['metamorphic']); r['expected']['same_semantic_identity']=not r['expected']['same_semantic_identity']
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_paired_source_corruption(self):
        r=copy.deepcopy(self.samples['metamorphic']); r['paired_source']['sha256']='0'*64
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_unknown_field(self):
        r=copy.deepcopy(self.samples['accept']); r['certified']=True
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_partition_corruption(self):
        r=copy.deepcopy(self.samples['accept']); r['partition']='challenge' if r['partition']!='challenge' else 'reference'
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_observation_source_binding_in_metadata_mode(self):
        r=copy.deepcopy(self.samples['accept']); r['observed']['source_sha256']='0'*64
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime,replay=False))
    def test_remote_schema_refusal(self):
        with self.assertRaisesRegex(ValueError,'remote schema'): validate_core.refuse_remote({'$ref':'https://invalid.example/schema'})
    def test_base64_malformed(self):
        r=copy.deepcopy(self.samples['accept']); r['source']['bytes_base64']='?invalid!'
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_boolean_expected_is_not_integer(self):
        r=copy.deepcopy(self.boolean); r['expected']['values']['value']=1
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_boolean_observation_is_not_integer(self):
        r=copy.deepcopy(self.boolean); r['observed']['values']['value']=1
        self.assertTrue(validate_core.check_record(r,self.validator,self.runtime))
    def test_empty_population_rejected(self):
        registry=json.loads((ROOT/'datasets/CORE_FAMILY_REGISTRY.json').read_text(encoding='utf-8'))
        receipt=json.loads((ROOT/'validation/CORE_BUILD.json').read_text(encoding='utf-8'))
        self.assertTrue(validate_core.population_errors({},registry,receipt,receipt['master_sha256']))
    def test_truncated_family_rejected(self):
        registry=json.loads((ROOT/'datasets/CORE_FAMILY_REGISTRY.json').read_text(encoding='utf-8'))
        receipt=json.loads((ROOT/'validation/CORE_BUILD.json').read_text(encoding='utf-8'))
        r=self.samples['accept']; self.assertTrue(validate_core.population_errors({r['record_id']:r},registry,receipt,receipt['master_sha256']))
    def test_alternate_root_loader_uses_that_root(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'validation') as temp:
            root=pathlib.Path(temp); (root/'runtime').mkdir(); (root/'runtime/lcuf.py').write_text('VERSION="alternate-root-marker"\n',encoding='utf-8')
            self.assertEqual(build_core.load_runtime(root).VERSION,'alternate-root-marker')
    def test_terminal_mutation_ancestor_is_admitted(self):
        for family in ('assertion_type_mismatch','terminal_wrong_type','terminal_has_output'):
            src,needle,rule=build_core.custom_negative(family,0)
            if family=='assertion_type_mismatch': src=src.replace('true | y | bool','1 | y | i64')
            elif family=='terminal_wrong_type': src=src.replace('- | i64 | - | - | - | 1 | none','- | unit | - | - | - | 1 | none')
            else: src=src.replace('x,y | invalid | unit','x,y | - | unit')
            self.assertEqual(build_core.evaluate(self.runtime,src)['admission'],'accept')
    def test_duplicate_json_key_rejected(self):
        with self.assertRaisesRegex(ValueError,'duplicate JSON'): validate_core.strict_json('{"status":"PASS","status":"FAIL"}')
    def test_bare_nonfinite_json_rejected(self):
        with self.assertRaisesRegex(ValueError,'nonfinite'): validate_core.strict_json('{"value":NaN}')

if __name__=='__main__': unittest.main(verbosity=2)
