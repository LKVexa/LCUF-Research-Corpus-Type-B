# Reproducibility and evidence interpretation

Run commands from the extracted `LCUF_RESEARCH_CORPUS_0.1.0` directory. Preserve an untouched extraction before regenerating data or reports. Python commands below use your local interpreter. The recorded host was CPython 3.12.14 on Windows AMD64; the mathematics stdlib tools support Python 3.10 or later.

## 1. Verify delivered byte identity

```text
python -B tools/verify_release.py --deep
```

The release manifest enumerates delivered files and their SHA-256/byte counts. The verifier checks the exact population under its declared exclusions, path containment, hashes and totals. `--deep` also parses JSON/JSONL and Python syntax. This read-only operation leaves the manifest intact. It establishes consistency against the delivered manifest; obtain a trusted package digest through a separately trusted channel if authenticity is required.

`validation/RELEASE_VERIFICATION.json` is excluded from its own manifest to avoid self-reference. The package ZIP has a separate sibling package receipt with its SHA-256, byte count and CRC check. Subcollection manifests additionally bind the frozen mathematics files, formal content, research registries and selected upstream evidence.

## 2. Use the local reference

```text
python -B runtime/lcuf.py check runtime/examples/federated_sum.lcuf
python -B runtime/lcuf.py compile runtime/examples/federated_sum.lcuf
python -B runtime/lcuf.py simulate runtime/examples/federated_sum.lcuf
python -B runtime/lcuf.py plan runtime/examples/federated_sum.lcuf
```

The example computes and copies 42 across declared model sites. Simulation is one host process. The target plan contains null bootable images. Runtime source identity is pinned in `provenance/UPSTREAM_SOURCES.json`; replacing it invalidates that identity and requires a separately versioned experiment.

## 3. Rerun core conformance and fault sensitivity

```text
python -B tools/validate_core.py
python -B -m unittest discover -s runtime/tests -v
python -B -m unittest discover -s tools/tests -v
python -B tools/check_oracle_sensitivity.py
```

The validator requires JSON Schema Draft 2020-12 support. A compatible offline dependency tree is supplied under `tools/vendor`: its native `rpds-py` component is for CPython 3.12 Windows AMD64. The tools select it only on that compatible platform. On another platform, install `tools/requirements-lock.txt` in an isolated environment using your own dependency access. NumPy is optional and is not part of this core vendor tree. Package license metadata is preserved.

`validate_core.py` reruns every source slot in the 10,144-record master, checks independently constructed scalar oracles or specified rejection/identity predicates, and validates source binding, schemas, typed JSON equality, population completeness and partition copies. It writes a fresh `validation/CORE_VALIDATION.json`. `--metadata-only` checks stored evidence without fresh host execution and is therefore a weaker operation.

The oracle sensitivity tool modifies an in-memory reference for ten specified faults. It neither patches the delivered runtime nor runs a native target. Its 1,300 fixture evaluations establish detection of the listed faults rather than exhaustive fault coverage. The two core unit suites contain 22 tests each.

To materialize the authoritative bytes of one case into a new file:

```text
python -B tools/materialize_case.py LCUF-000001 --out extracted_case.lcuf
```

Use an actual ID from the master; `--paired` selects the second source of a metamorphic case. Extraction refuses to overwrite an existing target. Representative examples are already available under `examples/`, with their paths listed in `examples/INDEX.json`. Some are deliberate rejected or invalid-encoding sources.

## 4. Regenerate deterministic core data

```text
python -B tools/build_core.py
python -B tools/validate_core.py
```

The builder reconstructs the complete master, partitions, representative examples, registry and build receipt. Source values and independent expectations are parameterized in the generator. Gzip headers have a fixed timestamp. [The deterministic-build receipt](validation/DETERMINISTIC_BUILD.json) compares delivered dataset hashes before and after regeneration on the recorded host. Runtime, generator or serialization changes require new identities and updated validation, rather than a claim of the same artifact.

## 5. Rerun mathematics

Change into `mathematics/`:

```text
python -B tools/validate.py
python -B -m unittest discover -s tests -v
python -B -m unittest discover -s frozen/coupling8s/tests -v
```

The first command uses the standard library to verify frozen identities, 1,619 analytical/domain oracles, and separate frozen/reference-policy host outputs. It also checks the stored 500-case numerical snapshot and reruns those stored inputs through the research host; that snapshot check does not invoke fresh NumPy. The mathematical suites contain 28 research and 20 frozen tests.

With compatible installed optional dependencies from `mathematics/requirements-optional.txt`:

```text
python -B tools/validate.py --json-schema
python -B tools/numpy_differential.py
```

The first adds strict full-record schema validation. The second performs fresh NumPy comparisons with the recorded seed and tolerances. The bundled CPython 3.12 Windows schema dependencies can also be selected by adding the release's `tools/vendor` directory to `PYTHONPATH`; avoid using that platform-specific tree with incompatible interpreters. NumPy 2.3.5 and jsonschema 4.25.1 were used for the recorded optional checks.

`tools/build_dataset.py` regenerates mathematical records. `tools/validate.py --write-report` replaces the mathematical validation receipt; the default validator does not write a report. Numerical comparisons are tolerance-qualified and environment-recorded. A different numerical backend may legitimately change output bytes while retaining agreement within the stated domains. Neither numerical agreement nor a local gate acceptance supplies an empirical `Score` interpretation or a physical theorem.

## 6. Interpret proposed systems experiments

`research/SCENARIOS.json` contains specified oracles and unperformed observations. It is not an executable test receipt. `research/REQUIREMENT_TRACEABILITY.json` links proposed obligations to those scenarios. Registry/integrity receipts establish internal consistency and evidence-path identity. Native build, boot, authenticated transport, revocation, durable transaction and crash tests must be implemented and observed before promoting these contracts to implementation claims.

The [validation summary](validation/VALIDATION_SUMMARY.json) distinguishes these evidence classes. No aggregate score combines passed host tests with unperformed native/network scenarios. No synthetic challenge partition is represented as a blind external evaluation.
