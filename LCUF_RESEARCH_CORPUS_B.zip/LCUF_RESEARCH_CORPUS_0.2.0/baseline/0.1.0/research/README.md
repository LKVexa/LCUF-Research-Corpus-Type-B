# LCUF institutional research volumes

Version 0.1.0, prepared 2026-10-09. This folder contains nine detailed volumes, a mapping of all 25 audited inputs, 66 proposed requirements, 72 acceptance scenarios, 12 bounded claims and 22 primary references. The contracts are research proposals; the frozen six-operation runtime is a local model. No native image, authenticated federation, external review or institutional certification is asserted by these volumes.

Start with [the charter](00_RESEARCH_CHARTER.md), then read [architecture and adapters](01_ARCHITECTURE_AND_ADAPTERS.md), [native contracts](02_NATIVE_UNIKERNEL_CONTRACTS.md), [federation protocol](03_FEDERATION_PROTOCOL.md), [security](04_THREAT_MODEL_AND_SECURITY.md), [evaluation and data governance](05_EVALUATION_AND_DATA_GOVERNANCE.md), [assurance and roadmap](06_ASSURANCE_RELEASE_AND_ROADMAP.md), [scenarios](07_SCENARIO_CATALOG.md), and [primary references](08_PRIMARY_SOURCE_BIBLIOGRAPHY.md).

The 8S Penteract–S³ foundation is preserved. Scalar i64 and bounded Count examples do not complete JA semantics. The package's 10,144-record synthetic local-model dataset is parameterized: family-label partitioning does not establish graph-template isolation, independent designs, blind evaluation or ML generalization.

Local source references resolve within this package to `../provenance/upstream_snapshot/` relative to this folder. The bundled snapshot is **selected evidence**, preserving referenced audits/specifications and baseline files with original structure and hashes; it does not include the full prior collection or all corpus payloads. Historical original locations remain provenance metadata and are not required to resolve the portable references.

## Machine-readable records

| File | Contents and authority |
|---|---|
| `PROFILE_ADAPTER_REGISTRY.json` | 25 candidate profiles, exact frozen audit/specification references and hashes, reuse boundaries, required identity fields, implementation and eligibility qualifications |
| `SCENARIOS.json` | 72 specified experiments, each with setup, stimulus, required oracle and observer; all observations remain null |
| `REQUIREMENT_TRACEABILITY.json` | 66 proposed obligations and scenario references; specification coverage does not imply executed coverage |
| `CLAIM_REGISTRY.json` | 12 scoped propositions, statuses, limits and artifact links; reviewer and certification fields unfilled |
| `BIBLIOGRAPHY.json` | 22 verified primary-source references, dates, direct URLs, mutable-source cautions and bounded uses |
| `BASELINE_PROVENANCE.json` | Read-only frozen baseline and arithmetic-image content hashes, selected-snapshot portable paths, historical original location and current package count-reference snapshots |
| `REGISTRY_CHECKS.json` | Registry construction/consistency checks, including all 25 evidence-path groups |
| `RESEARCH_INTEGRITY_CHECKS.json` | Separate artifact consistency checks of registry counts, null future results, requirement links and frozen-reference hashes |
| `PORTABILITY_CHECKS.json` | Package-contained evidence paths and Markdown links, all selected-snapshot byte hashes, and scoped review of root documentation |
| `RESEARCH_FILE_MANIFEST.json` | Content inventory and SHA-256 digests; content integrity only, not author authentication or external certification |

The registry builder and integrity checker ran successfully. Every requirement has at least one proposed scenario, all adapter evidence files exist, and the frozen reference hashes match. Portability checks verified 149 registry evidence references, 24 local Markdown links and all 203 selected-snapshot files against their content hashes. These checks validate the research artifacts' internal organization; they do not run the proposed native/network experiments. Current runtime, dataset and mathematical test results belong to the package's separate validation reports.

## Important unresolved work

Complete authoritative per-profile grammars and operator semantics are needed before native imports. Native target selection, ABI layouts, image builds, drivers and full resource enforcement need implementations and actual boot evidence. Authenticated transport, durable effect transactions, revocation freshness and nested membership need fault-tested services. The FOUNDATION-01 migration, numerical domains and Score interpretation need explicit semantic decisions. Independent blind cases, actual reviewers, operational authorities and applicable data rights remain to be established by real participants. The volumes provide contracts, scenario oracles and release gates for that work.
