# Proposed authenticated and nested federation protocol

Document ID: LCUF-R-03. Revision: 0.1.0. Status: proposed transport profile LCFP/0.1; not implemented by frozen LCUF/0.1. Companion: `SCENARIOS.json`.

## Identities, membership and route authority

A site identity is a verified key principal associated with a deployment image/policy, not the source's arbitrary trust label. A membership certificate binds federation ID, subject site/federation ID, issuer, parent membership, allowed actions/resources, profile set, route constraints, epoch, validity interval and delegation depth. Trust anchors are provisioned out of band under a documented governance action. FED-01 requires explicit algorithm/key identities and verification of issuer authority, audience, version, expiry/freshness and chain depth. No certificate field becomes true merely because it is hashed.

Nested membership is represented by an acyclic directed hierarchy H of exact federation identities. Membership can have multiple parents only with explicit conflict semantics; the first candidate profile restricts a route to one selected, authenticated parent chain. A route `[site_a, federation_x, federation_y, site_b]` names every administrative hop. Authorization at a hop is independently recomputed and can only shrink:

`A_effective = A_sender ∩ A_link ∩ A_receiver ∩ (∩ A_membership_hop) ∩ A_current_policy`.

An ancestor supplies a ceiling, never a right denied by a child. Revoked, expired, unknown or ambiguous chains reject; default is deny. Constraints include operation, data label, profile, destination, resource ceiling and delegation depth. A relay may route encrypted data while lacking plaintext rights, but still needs route and traffic-resource authority. Transfer permissions do not imply permission to execute a new operation at the destination.

## Transport choice and message authentication

Candidate bindings are mutually authenticated TLS over a reliable stream or QUIC with an explicit identity binding. Selection needs interoperable implementation evidence; neither exists in the baseline. TLS 1.3 is currently specified by RFC 9846 (July 2026), which obsoletes RFC 8446. Its early-data replay considerations motivate disabling 0-RTT for LCFP admission and effect-bearing requests. QUIC defines a transport with streams; stream delivery does not implement application idempotency or authorization. [RFC 9846](https://www.rfc-editor.org/info/rfc9846/), [RFC 9000](https://www.rfc-editor.org/info/rfc9000/).

FED-02 binds a transport peer to a site principal and validates the chain, rather than trusting a server certificate's existence. Federation policy supplies acceptable anchors, names, algorithms, key rotation and profile negotiation. A session ID must not substitute for durable effect identity. Optional end-to-end object signatures use a selected standard format and exact context binding. COSE defines signed/encrypted object structures; EdDSA specifies signature algorithms. Neither establishes LCUF application policy, key security or certification. [RFC 9052](https://www.rfc-editor.org/info/rfc9052/), [RFC 8032](https://www.rfc-editor.org/info/rfc8032/).

## Proposed bounded envelope

The envelope schema is separate from the baseline's local canonical JSON. FED-03 requires maximum frame length, nesting depth, object count, value size, chain length, causal-parent count and total transfer quota checked before allocation. Unknown critical fields/versions, duplicate keys and mismatched declared/actual lengths reject. The chosen encoding version and test vectors are part of protocol identity.

| Field group | Required fields | Semantic requirement |
|---|---|---|
| Protocol | protocol_id, envelope_schema, encoding_id, message_kind | Exact supported versions; no downgrade to opaque execution |
| Principals | issuer, sender, destination, audience, route, membership_chain | Endpoint and every hop independently authorized |
| Artifact | source_digest, module_digest, row_id, profile_identity, image_digest | Scope tied to actual admitted operation and backend |
| Values | schema_digest, ordered input_digests, payload_digest, payload_length | Source order and types preserved; content validated before use |
| Effects | operation, inferred_effects, requested_caps, effect_id, attempt_id | No undeclared effect; attempts do not create new effect identity |
| Policy | policy_epoch, membership_epoch, key_epoch, delegation_depth | Monotonic state checked against receiver's current view |
| Causality | causal_parent_receipts, sender_sequence, boot_id | Causal references validated; sequence alone insufficient after reboot |
| Time | issued_at, deadline, freshness_mode, clock_uncertainty | Defined trusted-time/nonce mode; no sender-only freshness authority |
| Resources | reservation_class, byte_limit, work_limit, reply_limit | Receiver may lower ceilings; admission reserves locally |
| Authenticity | key_id, algorithm_id, signature/context_binding | Covers protected fields and domain-separated message identity |

`effect_id` identifies one logical external effect; `attempt_id` identifies one transport attempt. Proposed immutable binding is `payload_binding = H(domain || sender || destination || module || row || profile || ordered_inputs || operation || effect_parameters)`. A caller-chosen effect ID is accepted only with this binding, durable uniqueness scope and issuer authority. A retry retains effect ID and payload binding while refreshing its attempt, current authorization evidence and deadline according to policy. A policy-epoch change must not create a new effect identity that bypasses deduplication. Same effect ID with different payload is a terminal conflict.

## Receiver state machine and durable acceptance

The receiver's durable table key is `(issuer_principal, destination_effect_scope, effect_id)`. Each row binds immutable payload digest, state, admitted policy epoch, result/receipt digest, external transaction reference and recovery metadata. A duplicate request with the same payload returns the existing state/result after current disclosure authorization; it must not execute a second external action. A duplicate may be denied access to a prior result after revocation while the ledger still retains deduplication identity.

```mermaid
stateDiagram-v2
  [*] --> Received
  Received --> Rejected: syntax/auth/profile/policy failure
  Received --> Reserved: authorized and quota available
  Reserved --> Accepted: atomic durable inbox and reservation
  Reserved --> Rejected: persistence failure
  Accepted --> Running: current policy recheck
  Accepted --> Cancelled: revoked before activation
  Running --> Committed: outcome and outbox durable together
  Running --> Failed: confirmed no effect or typed failure
  Running --> Uncertain: effect may have escaped transaction
  Uncertain --> Committed: independent reconciliation confirms effect
  Uncertain --> Failed: independent reconciliation confirms absence
  Committed --> [*]
  Failed --> [*]
  Cancelled --> [*]
  Rejected --> [*]
```

FED-04 requires a durable acceptance boundary. Sending `Accepted` before a recoverable inbox/reservation record is committed is forbidden. Reservation and inbox identity must be transactionally consistent or recoverably compensated, with a proven recovery procedure. The receiver can be a single durable authority for its scope; replicated authorities need a selected consistency protocol. Raft is a reference for crash-tolerant replicated logs, not Byzantine agreement and not a supplied LCFP implementation. [Ongaro and Ousterhout, extended Raft paper](https://raft.github.io/raft.pdf).

FED-05 distinguishes delivery from effect commit. At-least-once attempts plus durable deduplication can provide at-most-once activation in a defined durable scope under stated recovery assumptions. They do not generally provide exactly-once external effects. A transactional store can atomically commit its own effect and ledger; a remote actuator lacking such a transaction may leave `Uncertain`. Claiming exactly-once requires the specific effect boundary, isolation/durability premises, fault model and crash proof. Timeout is an observation of missing response, not evidence that an effect did not occur.

```mermaid
sequenceDiagram
  participant S as Sender
  participant R as Receiver policy
  participant L as Durable inbox and ledger
  participant X as Effect backend
  S->>R: Authenticated offer(effect_id, payload, route)
  R->>R: Validate identity, versions, epochs, limits
  R->>L: Atomic reserve and accept immutable binding
  L-->>R: Durable accepted record
  R-->>S: Accepted with ledger reference
  R->>R: Recheck activation policy
  R->>X: Execute under effect contract
  X-->>R: Confirmed result or uncertain outcome
  R->>L: Commit result and bounded outbox
  L-->>R: Durable result
  R-->>S: Committed receipt
  S->>R: Status/retry same effect_id after lost reply
  R->>L: Read existing outcome
  R-->>S: Existing outcome; no second activation
```

## Sender states, retries and deadlines

Sender states are `Prepared`, `Offered`, `AcceptedKnown`, `OutcomeKnown`, `Uncertain`, and `Closed`. A lost offer/acknowledgement leads to status reconciliation using the same effect identity. Retries are bounded by attempt count, remaining deadline, resource ceiling and current authorization. Jitter/backoff choices are recorded; they cannot introduce unbounded outstanding requests. Rejection codes distinguish permanently unsupported schema, revoked authorization, conflicting identity, unavailable quota, transient transport failure and uncertain backend outcome. A retryable transport error is not automatically a retryable operation.

Deadlines name elapsed-time and expiry semantics. A receiver uses a trusted local monotonic timer for remaining execution duration and a configured freshness mechanism for external timestamps. Clock uncertainty beyond the policy bound causes reject/defer. After reboot, monotonic readings from a prior boot are incomparable; boot ID and persisted policy determine recovery. Cancellation before activation can prevent the effect. Cancellation after activation requests cessation but cannot promise rollback. A committed effect remains committed after its deadline; subsequent result disclosure still obeys current policy.

## Revocation, key rotation and partition behavior

FED-06 requires epochs monotonic in durable local policy state. A site may refuse admission while disconnected from required policy freshness; it cannot silently claim immediate global revocation under partition. The deployment chooses a documented revocation model: online current-state check, short-lived lease with maximum stale interval, or local preauthorized offline scope. Maximum stale-authority exposure is a measurable claim, not zero by default.

At admission and activation, current authority is checked. Revocation before activation cancels accepted work without execution. Revocation during an external effect enters its defined cancellation/uncertainty behavior; erasing the deduplication row is forbidden. Already committed results may be retained for audit subject to rights, but future disclosure is reauthorized. Key rotation changes authenticated principal bindings only through authorized continuity records; old signatures remain evaluable against their historical key status and trusted observation time. Compromised-key revocation changes trust in prior receipts according to incident scope and independent evidence.

Parent/child federation detach makes routes through that membership invalid for new work. Child-local work can continue only within independently authorized local scope. A replacement parent does not inherit old grants. Membership cycles, depth overflow and ambiguous multiple-parent chains reject. A parent outage may affect availability but cannot justify using a broader alternative grant without a new signed/authorized route.

## Causality and replay

FED-07 requires each consumed external value to cite an authenticated receipt or input authority and an exact value digest. The event relation is a partial order from local progression and send/receive edges. A logical clock can encode order constraints; it does not imply synchronized physical time or that two unrelated events have a meaningful causal order. [Lamport, 1978](https://lamport.azurewebsites.net/pubs/time-clocks.pdf).

Replay means reconstructing a declared observation record, not silently reperforming physical effects. A replay run uses a separate mode/identity, recorded external observations, numerical environment, seeds and scheduling inputs. It cannot send an actuator command under the original production effect ID. Missing observation, unknown driver version or incompatible numerical tolerance yields incomplete replay. Ledger hash chains need authenticated/trusted checkpoints to expose truncation; independent witness or quorum protocols are future choices, not inferred from a local hash.

## Crash and recovery obligations

| Crash point | Recovery action | Forbidden inference |
|---|---|---|
| Before durable acceptance | Reauthorize and accept same binding if absent | Lost response proves rejection |
| After acceptance before activation | Recover reservation; recheck current policy | Old admission bypasses revocation |
| During pure compute | Deterministic recomputation under same version if safe | New compiler is equivalent without evidence |
| After external effect before ledger commit | Query transactional backend or mark uncertain | Blind retry is harmless |
| After durable result before reply | Return existing committed outcome if disclosure allowed | Lost reply requires a new effect |
| After result before outbox send | Recover bounded durable outbox | Receipt delivery is the effect commit |
| Disk full | Refuse new durable work and preserve accepted records | Volatile acceptance can be called durable |
| Ledger lost/rolled back | Quarantine effect scope; restore from trusted checkpoint or require reconciliation | New empty ledger proves effect never occurred |
| Replicated split authority | Apply selected quorum/consistency rule; suspend if unresolved | Two active leaders can safely dedupe independently |

The state model assumes honest policy enforcement and recoverable storage. Malicious sites, Byzantine storage or compromised signing keys require stronger evidence and a separately specified protocol. Crash/replay/revocation scenarios FED-CASE-01 through FED-CASE-24 in the catalog are proposed acceptance experiments; none is reported as a native network result here.
