# Proposed native unikernel ABI, build, image and driver contracts

Document ID: LCUF-R-02. Revision: 0.1.0. Status: proposed; no bootable image, native compiler backend or driver implementation is supplied by the frozen six-operation prototype.

## Target selection and protection domain

The first native experiment should target one pinned CPU architecture, one hypervisor interface, one boot mechanism, and the base scalar profile. Unikraft and MirageOS are comparison candidates, not selected dependencies or proven LCUF backends. Unikraft describes a modular, statically linked design with no protection between its components. Consequently, an LCUF capability check inside a single image is an application policy mechanism, not hardware isolation against a compromised co-linked driver. MirageOS illustrates specializing library-OS components with an application; its older overview does not establish present platform compatibility or LCUF support. [Unikraft architecture](https://unikraft.org/docs/internals/architecture), [MirageOS overview, 2013-10-15](https://mirage.io/docs/overview-of-mirage).

NAT-01 defines a site as an execution and policy boundary. A native site is one measured image instance and its external supervisor, not a process name. Components sharing writable memory belong to the same compromise domain. Untrusted tenants require separately isolated images or a demonstrated stronger mechanism. The trusted computing base must enumerate compiler, runtime checks, bootloader, included libraries, drivers, hypervisor, supervisor, identity/key provisioning, policy and durable ledger. Hardware/firmware assumptions are recorded separately.

## Draft ABI LCABI/0.1

This section proposes a logical ABI, not executable C definitions. Binary layouts, alignment, calling convention, endianness and platform binding require a separately approved target supplement. No ABI name here implies an existing exported symbol.

`ExecutionContext = {abi_id, image_digest, instance_id, boot_id, module_digest, row_id, profile_identity, policy_epoch, capability_table_digest, resource_account_id, cancellation_generation}`. Context is minted by the trusted runtime at row admission. Source code cannot select its own context, mutate an epoch, or acquire a raw driver reference.

`ValueRef = {table_index:u32, generation:u32, schema_id, owner_instance, length:u64}`. References are image-local handles; foreign references are serialized values. A stale generation or wrong owner returns a typed error. Generation reuse must not wrap into a previously valid handle: retire a slot before generation exhaustion, and bind handles to the image instance/boot lifetime. Serialization never leaks a pointer, allocator metadata or physical address. A handle is not a transferable capability. Independent runtime schemas validate before allocation and again before a profile consumer sees the value.

| Proposed ABI service | Input and result | Mandatory boundary behavior |
|---|---|---|
| `context_current` | Read-only execution context | Context belongs to active row; unavailable outside admitted execution |
| `value_read` | Handle, offset, requested length → bounded read | Validate owner/generation; test `offset ≤ length` and `count ≤ length-offset` before address arithmetic |
| `value_publish` | Schema, payload → immutable handle | Validate schema and Unicode/range; reserve payload and runtime metadata; single writer; partial allocation invisible |
| `quota_reserve` / `quota_release` | Account, class, amount → reservation token | Checked arithmetic, atomic accounting, no negative/repeated release; tokens bound to context |
| `driver_submit` | Driver ID, operation, bounded buffers, request ID → completion handle | Exact grant/effect/device allowlist; validated DMA-safe region; reserve in-flight quota before submission |
| `clock_observe` | Clock kind → value plus uncertainty/source | Monotonic clock for elapsed deadlines; external time explicitly nondeterministic |
| `evidence_append` | Typed event, causal parents → local append result | Bounded/redacted payload; append failure typed; this call does not imply a remote signature |
| `cancel_observe` | Context generation → cancellation state | Cooperative only unless external supervisor can preempt; cannot promise effect rollback |
| `effect_commit` | Effect identity, result digest, durable token → outcome | Defined transaction boundary; reject unsupported atomicity rather than claim exactly-once |

NAT-02 requires the integer ABI to represent signed i64 exactly and distinguish Boolean from integer. `add`/`mul` are checked; machine wraparound, saturating arithmetic and undefined signed overflow cannot replace baseline rejection. Text is a sequence of Unicode scalar values encoded as UTF-8 at the boundary. Unpaired surrogates, overlong/invalid UTF-8 and buffer overflow reject. No floating type is admitted by the base ABI. A numerical profile names representation, rounding, NaN policy, accumulation order and accepted error separately.

NAT-03 requires failure atomicity for value publication and quota reservation. A failed row produces a terminal typed error and cannot publish a partially initialized output. An effect can have partial external consequences; its result must express `uncertain` when the platform cannot establish whether it occurred. Exceptions, traps, cancellation and budget exhaustion are observable outcomes in the profile contract. A supervisor timeout cannot be reported as a source assertion failure.

## Resource accounting

The local prototype's memory measure counts retained semantic payloads: 8 bytes per i64, 1 per Boolean, UTF-8 length for text. It deliberately excludes Python objects, runtime metadata, receipt storage, compiler heap and drivers. Those exclusions cannot be carried into a native memory-safety claim.

The proposed image envelope is `R_total = R_static + R_stack + R_runtime + R_values + R_ledger + R_driver + R_transport + R_emergency`, each with a platform-tested maximum. NAT-04 requires `Σ reservations[class] ≤ limit[class]` for RAM, retained values, ledger bytes, buffer counts, queue entries, CPU work/fuel, transfer bytes and external service credits. Compilation, boot and admitted execution have separate accounts. Fuel is an abstract work counter, not a physical CPU-time promise; wall-clock watchdogs and scheduler limits need external enforcement.

| Resource class | Reservation point | Enforcement and failure | Required measurement |
|---|---|---|---|
| Semantic values | Before publish/copy allocation | Deny allocation; preserve no partial value | Peak retained bytes, allocator overhead separately |
| Stack and runtime heap | Build-time static bounds plus runtime allocator limits | Trap/isolate on exhaustion | High-water mark with worst-case call depth |
| Driver buffers | Before queue submission | Bounded queue/backpressure | Queue occupancy, DMA pinned bytes, reset leaks |
| Ledger/storage | Before accepting durable work | Stop accepting if no durable capacity | Bytes per event, reserve threshold, disk-full behavior |
| CPU/fuel | Row activation | Checked decrement; supervisor handles noncooperative code | Consumed fuel and CPU cycles, deadline misses |
| Network | Before framing and send | Rate/byte limits, bounded fragments | Wire bytes/retries per effect identity |
| Emergency path | Boot provisioned | Minimal terminal event and shutdown | Error path remains executable under low memory |

A nested site cannot spend ancestor credit to enlarge its own hard limit without a separately authorized policy update. Reservations may be reclaimed only after durable lifecycle transition or verified cancellation, avoiding double accounting after restart. Deliberate memory exhaustion is a required negative test. Real-time claims require a target-specific scheduling analysis; deterministic DAG order alone supplies no deadline guarantee.

## Driver contract

Every proposed driver manifest names implementation revision, device/interface version, operations, MMIO/DMA regions, interrupts, buffer alignment, maximum queue depth, reset behavior, required capabilities, threat assumptions and test artifacts. Driver allowlisting occurs at link/build time and runtime. A network capability does not authorize arbitrary physical devices; a render service grant does not authorize a local GPU driver. All buffer lengths and descriptor chains are validated against the actual allocated region with checked arithmetic.

Virtio is a candidate virtual-device interface, not an LCUF transport. This corpus pins **Virtio 1.2 Committee Specification 01, 2022-07-01** as a reference for feature negotiation, queues, initialization and reset. The browsed Virtio 1.3 page is **Committee Specification Draft 01, 2023-10-06** and must be treated as a distinct draft if selected. Feature negotiation, malicious descriptors, device reset and DMA confinement remain implementation tests. [Virtio 1.2](https://docs.oasis-open.org/virtio/virtio/v1.2/cs01/virtio-v1.2-cs01.html), [Virtio 1.3 draft](https://docs.oasis-open.org/virtio/virtio/v1.3/csd01/virtio-v1.3-csd01.html).

NAT-05 requires a driver to fail closed on unknown required features, bound device-controlled lengths, handle queue-full without unbounded allocation, and clean up cancellation/reset. If platform DMA isolation is absent, that limitation is stated and the device is trusted within the site. Driver success does not establish race freedom of a DeepML kernel. GPU/NPU/physical animation or quantum execution remains a remote service until the corresponding target profile passes its own evidence gates.

## Image and build manifest

The proposed immutable image manifest includes: source-byte digests; admitted-module digest; source authority; exact profile/adapter/schema identities; target triple; ABI identity; compiler/linker revisions and flags; dependency lock with content hashes; runtime/driver closure; allowed device inventory; memory layout; boot arguments; supervisor contract; declared nondeterministic inputs; policy baseline; SBOM/reference notices; and output image digest. Secrets are provisioned after build, not embedded in the reproducible image. Configuration that changes authority or numeric behavior changes deployment identity.

NAT-06 proposes a hermetic build: no undeclared network dependency, pinned toolchain artifacts, explicit locale/time/path controls, deterministic archive ordering, recorded random seeds where used, clean workspace and inspectable build log. A second isolated build compares image bytes. This follows the reproducible-build distinction between fixed source/environment and byte-identical artifacts; it does not prove those artifacts correct. SLSA provenance provides a reference model for tracing how an artifact was produced; recording such fields does not establish a SLSA level. [Reproducible Builds definition](https://reproducible-builds.org/docs/definition/), [SLSA v1.2 provenance](https://slsa.dev/spec/v1.2/provenance).

NAT-07 requires independent image admission: supervisor verifies manifest/image digests, compatible ABI, target platform, permitted driver closure and resource limits before boot. Boot evidence includes image digest, instance/boot identities, supervisor configuration, observed initialization, native test input/output digests, consumed resources and termination. A text `plan` command result cannot occupy these evidence fields.

## Image lifecycle and updates

```mermaid
stateDiagram-v2
  [*] --> Built
  Built --> Verified: manifest and reproduction checks
  Verified --> Booting: authorized deployment
  Booting --> Ready: observed ABI self-test
  Booting --> Failed: initialization or policy mismatch
  Ready --> Draining: update or revocation
  Draining --> Checkpointed: effects reconciled
  Checkpointed --> Retired: successor admitted
  Ready --> Failed: trap or supervisor fault
  Failed --> Quarantined: preserve crash evidence
```

An update cannot reuse prior execution receipts as proof for new compiler/runtime/driver bytes. State migration names old/new schemas and transaction behavior, validates checksums, and keeps a recovery copy according to actual rights. Rollback of executable bytes must not roll back revocation, membership or durable deduplication state. A degraded old image may boot only under current policy with explicit authorization. Update metadata protection can use an established framework with key roles, version and expiry checks; this proposal does not implement TUF. [The Update Framework specification](https://theupdateframework.github.io/specification/latest/).

## Native acceptance experiments

NAT-A compares independent scalar fixtures against the admitted IR on actual target hardware/hypervisor: i64 extrema, overflow, Boolean/text distinction, Unicode boundaries, assertion rejection and exact copy results. NAT-B demonstrates denial of an unlinked or ungranted driver and bounds invalid-buffer submissions. NAT-C measures the full resource envelope under adversarial allocation, queue pressure and disk-full conditions. NAT-D injects traps and reset during publication and proves no partial visible value and no double quota release. NAT-E reproduces an image from pinned inputs and distinguishes bit reproducibility from execution correctness. NAT-F performs update/rollback with a revocation and outstanding effect. No gate is marked met merely by writing this contract.
