# Operational, adversarial and recovery scenario catalog

Document ID: LCUF-R-07. Revision: 0.1.0. Status: proposed acceptance catalog. The entries below are experiment specifications, not test-run records. `SCENARIOS.json` encodes these exact rows with `execution_status=not_run_in_this_research_volume` and `observed_result=null`.

Each run binds case ID, requirement, artifact/version/target/policy manifests, fault schedule, input digests, independent oracle version, actual observations and evidence category. The setup is part of the oracle's premises. Implementations must additionally test combinations and extended state spaces; enumerating this catalog does not prove complete coverage. Native/federation cases require real candidate implementations. Local/model versions can explore the state machines but must keep their evidence category.

## Source, profile and adapter cases

| Case ID | Requirement | Setup | Stimulus | Required oracle outcome | Observer/evidence |
|---|---|---|---|---|---|
| ADP-CASE-01 | ADP-01 | Source declares one exact grammar version | Add unknown syntax after valid module terminator | Complete-consumption diagnostic; no admitted IR | Parser diagnostic and source byte span |
| ADP-CASE-02 | ADP-01, SEC-09 | Comment and string contain grant/action text | Compile without real declaration outside inert text | No capability inferred from inert text; missing real declaration rejected where required | Parsed AST and inferred-cap trace |
| ADP-CASE-03 | ADP-02, SEC-01 | Agent source requests a tool cap absent modeled metadata | Infer from source and lower | Tool right appears as obligation; omission from historical metadata cannot authorize execution | Independent source/AST comparison |
| ADP-CASE-04 | ADP-02, SEC-04 | Feature atlas labels source as join, source has no join operator | Build feature-coverage report | Case does not cover executable join; report flags label/source mismatch | Syntax-derived feature map and qualification |
| ADP-CASE-05 | ADP-03, ARC-03 | Authoritative eighteen-cell LCTL row contains policy outside proposed mapping | Convert to twelve-column LCUF subset | Lossless mapping supplied or conversion rejected; no silent policy drop | Before/after cell and policy digests |
| ADP-CASE-06 | ADP-05 | Tensor service expects rank/layout/dtype and numeric policy | Offer same bytes with changed layout or schema digest | Mismatch rejected before native service sees payload | Bridge validation and service activation count |
| ADP-CASE-07 | ADP-05 | Scene bridge uses meters and one handedness | Send centimeters/opposite handedness without conversion contract | Reject; checked explicit conversion variant gets independent transform oracle | Units/frame metadata and reference transform |
| ADP-CASE-08 | ADP-04, SEC-20 | Valid scalar program and independent literal fixture | Mutate lowered add to multiply or expected literal | Oracle rejects mutant even if compiler returns success | Independent expected value and mutant result |
| ADP-CASE-09 | ARC-03, SEC-02 | Two source texts differ only in whitespace/comments | Compile both, then separately alter cap or budget | Formatting variants share semantic identity, source hashes differ; policy variants change semantic identity | Digest tuples and admitted policy |
| ADP-CASE-10 | ADP-06 | Native-profile label exists but parser implementation absent | Request that profile at admission | Unsupported-profile diagnostic, no fallback execution | Version negotiation and activation count |
| ADP-CASE-11 | ADP-01 | Original and reconstructed grammar have conflicting productions | Resolve source authority | Explicit precedence/interpretation decision or unresolved rejection; reconstruction remains qualified | Authority graph and decision record |
| ADP-CASE-12 | ADP-05, SEC-04 | Proof payload names logic and proposition digest | Replace proposition or supply modeled pass label without proof | Check fails or evidence remains modeled; no theorem/native-certification promotion | Proof checker identity and claim record |
| ADP-CASE-13 | ARC-01, ARC-02 | Immutable base value has one writer and dependency-only authority | Add second writer, mutate published value, or infer a grant from after-edge | Reject unsupported mutation/second writer; dependency does not grant authority | Writer map, admitted effects and value visibility |
| ADP-CASE-14 | ARC-04, SEC-11 | Source site has a convincing trust label but no verified credential | Present label as principal at receiver | Authentication rejects; source label cannot mint a site identity | Credential decision and backend zero count |

## Native image, ABI and resource cases

| Case ID | Requirement | Setup | Stimulus | Required oracle outcome | Observer/evidence |
|---|---|---|---|---|---|
| NAT-CASE-01 | NAT-02 | Actual scalar image with signed i64 ABI | Execute max+1 and min*(-1), then valid extrema | Overflow rejected with no value publication; valid extrema exact | Target/image IDs, native outputs and publish trace |
| NAT-CASE-02 | NAT-02 | Text ABI and Unicode scalar policy | Invalid UTF-8, unpaired surrogate input, embedded encoded pipe, non-ASCII valid text | Invalid encodings reject; valid text preserved and byte-accounted | Input bytes, error/value digests and allocations |
| NAT-CASE-03 | NAT-03 | Handle table has released/reused slot | Read stale generation, wrong owner, wraparound offset/count; exhaust generation counter | Typed errors; no out-of-bounds read/foreign disclosure; exhausted slot retired rather than reused | ABI status, guards and memory observer |
| NAT-CASE-04 | NAT-04 | Full RAM envelope includes metadata/ledger/drivers | Allocate semantic values to limit plus queue/receipt pressure | Bound enforced across classes; deterministic exhaustion, no unaccounted growth | Peak RAM and per-class reservation ledger |
| NAT-CASE-05 | NAT-03, NAT-04 | Publication and reservation instrumented | Inject allocation failure/trap at each intermediate step | No partial output, reservation recovered exactly once | Visibility check, quota before/after and fault cuts |
| NAT-CASE-06 | NAT-05, SEC-15 | Driver queue accepts bounded buffer descriptors | Oversized chained descriptors and device-controlled returned length | Reject/contain; no unsafe DMA or unbounded allocation | Queue trace, DMA/guard observer and driver reset |
| NAT-CASE-07 | NAT-01, NAT-05 | Image manifest excludes a device and has no grant | Attempt device operation via ABI and direct available service path | Denied; no device action; same-image compromise limitations recorded | Device observer and image closure |
| NAT-CASE-08 | NAT-05 | In-flight driver request reserves pinned buffers | Reset/cancel device during request and repeat | Defined terminal/uncertain result; buffers/queue reclaimed without reuse race | Completion lifecycle and pinned-byte counters |
| NAT-CASE-09 | NAT-06 | Two isolated builders with pinned source/toolchain/env | Build independently with controlled path/time variance | Exact image byte comparison; mismatch investigated, no reproducibility assertion if unequal | Build logs/manifests and image digests |
| NAT-CASE-10 | NAT-07 | Supervisor expects exact manifest ABI/driver closure | Boot altered image or incompatible ABI supplement | Preboot or startup rejection; no ready state | Supervisor decision and boot event ledger |
| NAT-CASE-11 | NAT-04 | Workload contains noncooperative loop/native fault | Exceed fuel/time limit and suppress cooperative cancel | External limit/isolation demonstrated or target fails gate; no false hard-time guarantee | Supervisor timing, termination and resource trace |
| NAT-CASE-12 | NAT-07, SEC-17 | New policy revoked right; previous image still available | Roll back executable and try old policy/dedupe checkpoint | Current revocation remains; old policy/ledger rollback rejected or quarantined | Deployment/policy epochs and durable effect state |
| NAT-CASE-13 | SEC-16, NAT-06 | Known provisioning test secret held outside build workspace | Build image, inspect image/manifest/logs, then provision instance | Test secret absent from reproducible artifacts; secret delivery separate from image identity | Secret-pattern scan and provisioning record |

## Authenticated federation and nested recovery cases

| Case ID | Requirement | Setup | Stimulus | Required oracle outcome | Observer/evidence |
|---|---|---|---|---|---|
| FED-CASE-01 | FED-02, SEC-11 | Receiver has trusted site anchors and exact audience | Untrusted key, wrong audience, tampered policy field | Authentication/admission rejects; no activation | Peer/verification decision and backend count |
| FED-CASE-02 | FED-02 | Candidate transport supports TLS early data | Send effect-bearing offer in 0-RTT | Early effect request refused/deferred to allowed authenticated phase | Transport phase and activation timestamp |
| FED-CASE-03 | FED-03, SEC-10 | Receiver frame/chain/payload limits configured | Huge length, duplicate key, unknown critical field, depth overflow | Bounded early rejection before expensive allocation | Allocations/CPU/reply bytes and diagnostic |
| FED-CASE-04 | FED-04, SEC-14 | Durable table already has committed effect/payload | Retry same effect ID with new attempt after lost reply | Existing authorized result/state returned; one external activation | Ledger row and independent backend count |
| FED-CASE-05 | FED-04, SEC-03 | Effect ID already binds payload A | Offer payload B with same ID and valid sender auth | Terminal conflict; neither replacement nor second activation | Payload binding and conflict record |
| FED-CASE-06 | FED-04 | Offer received but durable accept transaction not committed | Crash before commit; resend same binding | No accepted claim before durability; recovery can accept once under current policy | WAL/accept response ordering and activation count |
| FED-CASE-07 | FED-04, FED-06 | Durable accepted work has not activated | Crash; revoke right; recover worker | Cancel/deny before activation despite previous acceptance | Epochs, recovered state and backend zero count |
| FED-CASE-08 | FED-05, SEC-19 | External backend cannot atomically bind effect and ledger | Crash after external action before result record | Uncertain outcome; reconciliation rather than blind retry | External activation, crash cut, uncertain ledger |
| FED-CASE-09 | FED-05 | Backend transaction atomically binds effect/result identity | Crash immediately after commit before acknowledgement | Recovery confirms existing commit; duplicate cannot repeat action | Transaction reference and activation count |
| FED-CASE-10 | FED-04 | Result/outbox durable, response not delivered | Lose reply then reboot and query status | Recover committed result/outbox; disclosure reauthorized | Durable records, query response and current policy |
| FED-CASE-11 | FED-04, SEC-05 | Storage and reserve thresholds configured | Fill disk before and after accepting work | Refuse new durable work; preserve accepted records; no volatile durable-success claim | Disk/WAL status and accepted inventory |
| FED-CASE-12 | FED-04, SEC-19 | Deduplication ledger has previously committed effects | Restore older checkpoint or erase ledger | Quarantine affected scope/reconcile; no empty-ledger absence inference | Checkpoint anchors and backend state comparison |
| FED-CASE-13 | FED-06, SEC-12 | Revocation lease allows bounded disconnected operation | Partition, revoke authority, advance beyond stale bound | Explicit bounded window then reject; no immediate-global-revocation assertion | Lease expiry/uncertainty and denied activation |
| FED-CASE-14 | FED-06 | Long-running external operation already activated | Revoke/cancel during action | Defined backend cancel or uncertain/committed outcome; dedupe retained | Effect lifecycle and cancellation observations |
| FED-CASE-15 | FED-01, SEC-13 | Parent allows action; child local policy denies | Present valid parent membership and offer to child | Child denies; parent right cannot broaden policy | Hop-by-hop intersection and zero activation |
| FED-CASE-16 | FED-01 | Route validator knows bounded parent chain | Cyclic chain, excessive depth, ambiguous parents, detached membership | Reject new work through invalid chain; independently authorized local work unaffected | Route graph, current memberships and decisions |
| FED-CASE-17 | FED-06 | Principal key rotates with continuity policy | Old key submits new request; old receipt queried; compromised key revoked | New admission obeys current key policy; historical evidence status separately evaluated | Key epochs, continuity and claim decisions |
| FED-CASE-18 | FED-07 | Receipts declare required causal parents | Missing parent, wrong value digest, reordered unrelated arrivals | Missing/mismatched causal evidence rejected/deferred; no invented total causality | Parent graph and value binding |
| FED-CASE-19 | FED-07 | Replay mode has recorded external observations | Replay production module with physical actuator endpoint configured | Recorded observations used or run refused; no production side effect | Replay identity, backend count and observation manifest |
| FED-CASE-20 | FED-04 | Replicated dedupe authority uses selected quorum rule | Partition leaders then send same effect to both sides | Defined consistency rule prevents conflicting active commitments or system suspends | Term/quorum/ledger and backend counts |
| FED-CASE-21 | FED-06 | Receiver reboot resets monotonic clock | Reuse old-boot duration/lease metadata | Reconcile boot/freshness state; no comparison across incompatible monotonic origins | Boot IDs, persisted expiry and decision |
| FED-CASE-22 | FED-03, SEC-22 | Separate pre-auth CPU/memory/egress budgets | Invalid signature/status flood with maximum allowed chains | Bounded amplification and work; authorized path remains within declared availability goal | Rate limits, reply bytes and resource counters |
| FED-CASE-23 | FED-05 | Deadline passes after confirmed commit | Query/retry expired committed effect | Commit stays committed; status disclosure authorized; no new execution or fictional rollback | Deadline, result ledger and activation count |
| FED-CASE-24 | FED-04, FED-06 | Commit retained but caller access now revoked | Retry/query same effect under revoked right | Deduplication retained; protected result not disclosed; no second activation | Disclosure decision and durable binding |

## Data, evidence and release governance cases

| Case ID | Requirement | Setup | Stimulus | Required oracle outcome | Observer/evidence |
|---|---|---|---|---|---|
| GOV-CASE-01 | DATA-01, GOV-01, SEC-06 | Historical record says pass with modeled-only qualifier | Export dataset and request native claim | Historical label preserved but observation null/native eligibility false | Export schema and claim ledger |
| GOV-CASE-02 | DATA-02 | Programming document wrapper and Service metadata preamble | Count/import executable cases | Documents/preamble separated; no artificial program count | Counts by record kind and import report |
| GOV-CASE-03 | DATA-04, DATA-05 | Renamed/numeral-varied template appears across shards/corpora | Produce random line split then governed grouped split | Leakage discovered; governed split keeps family together and reports heuristic limits | Similarity groups/split hashes |
| GOV-CASE-04 | EVAL-02, EVAL-03 | Preregistered campaign includes expected failures/timeouts | Remove failed run or alter threshold after outputs | Completeness check flags omission; revised protocol and original results retained | Scheduled-versus-observed ledger |
| GOV-CASE-05 | EVAL-01, SEC-20 | Oracle independently authored for fixture and invariant | Mutate multiplier, cap intersection or crash commit order | Oracle detects relevant mutant; weak self-comparison cannot certify case | Mutation matrix and independent expected relations |
| GOV-CASE-06 | GOV-02 | A passing run binds compiler/profile/policy/image A | Claim identical pass for modified image/profile B | Claim remains incomplete until equivalence/retest evidence exists | Artifact diff and evidence binding |
| GOV-CASE-07 | SEC-21, GOV-03 | Receipt chain with and without external trusted head | Alter link, truncate suffix, present forked heads | Link alteration detected; truncation/fork guarantees qualified by anchor/witness assumptions | Verifier results and trusted checkpoint identity |
| GOV-CASE-08 | GOV-04 | Review field currently null/unassigned | Publish independently reviewed or institutional certification label | Label rejected; only actual review scope/identity can populate field | Release text and actual decision records |
| GOV-CASE-09 | DATA-05, DATA-07, EVAL-04 | Previously blind cases disclosed to developer/model training | Reuse them as hidden evaluation | Cases marked exposed; fresh blind families or qualified known-benchmark claim | Exposure lineage and split revision |
| GOV-CASE-10 | DATA-01, DATA-06 | Source corrected but historical AST/proof metadata unchanged | Package derived artifacts with original metadata | Requires-revalidation qualifier persists; hashes/source map updated; no false fresh AST claim | Transformation manifest and per-record qualifiers |
| GOV-CASE-11 | SEC-18, SEC-07, DATA-07 | Secret field denied in normal result | Trigger parse/runtime/driver/crash errors and receipt emission | Secret absent from all unauthorized channels or explicit approved declassification | Error/evidence payload comparison and policy |
| GOV-CASE-12 | GOV-07, GOV-08 | Content manifest generated for research corpus | Market integrity hash as MSSL reseal or external certificate | Claim rejected; integrity and certification authorities remain distinct | Manifest, notices and release claim registry |
| GOV-CASE-13 | DATA-03, GOV-05 | Release schema requires case lineage, limits and failed-gate disclosures | Remove generator/rights unknown state, evidence category, limitation or failure summary | Schema/release review rejects incomplete presentation; unknown remains unknown | Required-field validation and release diff |
| GOV-CASE-14 | EVAL-05 | Positive and deliberate negative classes both scheduled | Aggregate compiler successes as all passes or expected rejections as defects | Correct class-relative outcomes reported; incorrect accepts/rejects/crashes separate | Confusion categories and independently expected classes |
| GOV-CASE-15 | GOV-06 | Policy/target selection has unassigned actual decision authority | Record unsigned fictional committee approval or omit alternatives/dissent | Decision remains pending until actual scoped authority records it; no invented reviewer | Decision schema and authentic author record |

## Arithmetic foundation and numerical profile cases

| Case ID | Requirement | Setup | Stimulus | Required oracle outcome | Observer/evidence |
|---|---|---|---|---|---|
| FOU-CASE-01 | SEC-08, ARC-03 | Preserved 8S law uses coordinate index set 4 through 8 | Lower to four-coordinate legacy d4 record without explicit migration | Reject/unresolved migration; no silent dimensional collapse | Source-image reference, schema and FOUNDATION-01 decision |
| FOU-CASE-02 | ADP-05, SEC-08 | JA Count fixture has bounded integer interpretation | Advertise scalar mul as complete JA arithmetic | Claim rejected; fixture and coupled profile scopes remain distinct | Arithmetic profile and claim scope |
| FOU-CASE-03 | ADP-02, ADP-05 | Independence expression includes C4 pseudoinverse and denominator regularizer | Zero e, rank-deficient/near-singular C4, unknown threshold or width | Declared solver/domain policy exercised; missing assumptions reject/incomplete | Numerical environment, premises and sensitivity outputs |
| FOU-CASE-04 | ADP-05 | Support product and cube-root radius have declared factor domains | Negative/unbounded factors, zero support and boundary coordinates | Invalid domains reject or follow explicitly approved extension; valid boundaries match independent relation | Factor constraints, finite-output and radius checks |
| FOU-CASE-05 | EVAL-01, GOV-03 | Admission compares independence threshold and Score(M8)-Score(M7) | Provide only one passing condition or undefined Score | Both predicates required; undefined Score remains missing input/obligation | Predicate values and score provenance |
| FOU-CASE-06 | EVAL-02, DATA-01 | Proposed empirical score study and preserved law reference | Tune threshold on holdout then assert law-provided validation | Protocol revision/exposure flagged; law does not supply invented observations | Data split, preregistration and threshold history |

## Combination campaigns

The basic catalog has 72 cases: 14 adapter, 13 native, 24 federation, 15 governance and 6 foundation cases. Additional campaigns combine crash cuts with revocation, key rotation with status disclosure, quota exhaustion with recovery, multi-hop delegation with schema mismatch, and numerical tolerance with replay. Schedule generation must identify explored and unexamined interleavings. An actual test result appends observations to a separate evidence object; it must not edit this specification to make an unexpected result disappear.
