# LCUF Research Corpus 0.1.0

**Columned Unikernel and Hyperfederated Fabric Language — formal core, mathematical foundation, systems contracts, and reproducible evidence.** Prepared 9 October 2026.

This corpus develops LCUF from the audited LKVexa language collection into a technically explicit research program. It contains eight formal language volumes, nine systems and institutional research volumes, a mathematical volume preserving the author's JA 8S foundation, executable source examples, independently constructed conformance expectations, machine-readable requirements and scenario registries, and recorded host validation. The accompanying adapter draft specifies how the arithmetic could enter a future typed fabric without silently replacing its meaning.

The implemented release is the finite `LCUF/0.1` column language and its pinned Python 0.1.0 host reference. Native unikernel construction and authenticated hyperfederation are specified development contracts. Their experiments have not been executed; scenario observations are deliberately unfilled. “Institutional” describes the rigor of the governance, evidence, review and release structures supplied here. No external institutional affiliation, approval, certification or completed peer review is claimed.

## Reading and review sequence

| Stage | Entry point | Review objective |
|---|---|---|
| 1 | [Research charter](research/00_RESEARCH_CHARTER.md) | Determine scope, authorities, evidence classes, decisions and exclusions |
| 2 | [Formal specification index](specification/README.md) | Review the exact accepted language and implemented rules |
| 3 | [Mathematics volume](mathematics/MATHEMATICS_VOLUME.md) | Review the preserved 8S law, derivations, domains, numerical policy and unknown semantics |
| 4 | [Architecture and adapter analysis](research/01_ARCHITECTURE_AND_ADAPTERS.md) | Trace all 25 original inputs into candidate LCUF roles and admission gates |
| 5 | [Native unikernel contracts](research/02_NATIVE_UNIKERNEL_CONTRACTS.md) | Review target ABI, dependency closure, drivers, boot and resource obligations |
| 6 | [Federation protocol](research/03_FEDERATION_PROTOCOL.md) | Review nested membership, delegated authority, routing, durability and recovery |
| 7 | [Threat model](research/04_THREAT_MODEL_AND_SECURITY.md) | Inspect trust boundaries, attack cases and required controls |
| 8 | [Evaluation and data governance](research/05_EVALUATION_AND_DATA_GOVERNANCE.md) | Review oracle independence, partition leakage, experiments and data rights |
| 9 | [Assurance, release and roadmap](research/06_ASSURANCE_RELEASE_AND_ROADMAP.md) | Inspect review roles, release gates and implementation milestones |
| 10 | [Reproducibility instructions](REPRODUCIBILITY.md) | Verify integrity, rerun host checks and interpret their limits |

The [catalog](CORPUS_CATALOG.json) enumerates the curated documents and their word counts. [Corpus metadata](CORPUS_METADATA.json) records population and evidence status. [Release notes](RELEASE_NOTES.md) explain the relationship to the frozen predecessor. The machine-readable [validation summary](validation/VALIDATION_SUMMARY.json) points to the actual receipts.

## Formal language and implemented semantics

The source uses twelve columns with explicit identity, ownership, type, operation, input, output, effects, capabilities, ordering, budget and evidence information. Its exact cells and declaration forms are defined by [the lexical grammar](specification/01_LEXICAL_GRAMMAR.md) and [EBNF](specification/LCUF_0_1.ebnf). Mathematical judgment notation in the volumes is explanatory metalanguage.

The closed operation set is `const`, `add`, `mul`, `copy`, `assert_eq`, and `emit`. Value types are `i64`, `bool`, and `text`; `unit` describes terminal results and admits no constant. The reference checks declared ownership, output types, arity, effect/capability agreement, directed copy authority, single writers, defined references, local ordering constraints, graph acyclicity, signed integer bounds, reserved steps and retained model payload. It uses a deterministic lexical choice among ready rows. Normalized IR hashes and local receipt chains preserve the explicit policy and source relationship.

Eight volumes cover grammar; static types, effects and capabilities; dependency and operational semantics; retained-payload resource calculus; canonical identity and receipts; propositions and proof sketches; diagnostics and traceability; and extension contracts. The [rule registry](specification/RULES.json) contains 48 stable requirement IDs. Twelve scoped proof sketches are human arguments about the finite model under stated assumptions. Thirty executed focused probes support boundary interpretation. The diagnostic registry traces every explicit fail call site in the reference.

The reference's `simulate` API assumes compiler-produced, unmodified admitted IR. A recomputed hash alone does not validate externally supplied IR. The CLI compiles source before simulation. The current `plan` output is a design plan with null bootable images. Retained payload and steps are model measures rather than measurements of total host or native memory, time, driver buffers or network resources.

## JA 8S foundation

The mathematical collection preserves the **8S Penteract–S³ Master Coupled Mechanics Law**, including the five base coordinates indexed **4 through 8** and the coupled acceptance gate:

`eta_ind >= epsilon_ind AND Delta8S > epsilon_gain`.

The supplied figure and the nine frozen reference files remain byte-exact. [Provenance](mathematics/PROVENANCE.json) binds their identities. The volume distinguishes finite matrix geometry, the local S³/projector representation and author-defined coupling from any global topology or physical theorem. `Classify` and `Score` interpretations are explicitly unresolved where the supplied authority does not determine them. Conventional LCUF `i64` behavior supplies a compiler subset; it does not complete JA semantics.

The separately versioned host research wrapper adds finite-value, domain, shape and output checks, and a tolerance ceiling of `1e-6`. This ceiling is a disclosed engineering admission policy. The frozen reference is preserved, including its documented loose-tolerance and roundoff qualifications. The [typed adapter contract](mathematics/ADAPTER_CONTRACT_DRAFT.md) remains a draft with no new implemented core operation.

## Populations and observed evidence

| Collection | Publication population | Observed checks and limits |
|---|---:|---|
| Core conformance master | 10,144 records in 144 construction families | 4,096 accepted constructions, 4,704 rejection mutations, 1,344 metamorphic pairs; 11,488 source evaluation slots |
| Core partition copies | 5,872 reference; 1,728 development; 2,544 challenge | Collectively reproduce the master once; these copies are not additional independent cases |
| Mathematical master | 1,619 unique operation/input pairs; 19 families; 66 family/template combinations | Independent analytical/domain expectations; frozen and research-policy observations checked separately |
| Numerical differential layer | 500 cases | NumPy comparisons for PSD, projector and projection methods; recorded floating-point tolerances and environment |
| Unit suites | 92 tests across four suites | 22 baseline core, 22 corpus-validator, 28 mathematical research-policy, 20 frozen arithmetic tests |
| Focused formal probes | 30 observations | Grammar and semantic boundary examples against the pinned reference |
| Oracle sensitivity | 10 specified in-memory faults; 1,300 fixture runs | All ten faults detected; selected fault coverage only |
| Proposed systems research | 66 requirements and 72 scenarios | Scenario oracles specified; future native/network observations remain null |

Core validation rechecks exact source bytes, strict schemas, expected values and diagnostics, deterministic execution, source and semantic hashes, retained payload, reserved steps, receipt bodies and hash chains, partition identity, and complete expected family populations. Thirty-six formal IDs have primary dataset labels; universal acceptance checks add the non-bootable-plan contract and repeat identity/resource/receipt requirements. Additional refinements have focused specification probes. These observations do not constitute exhaustive coverage of all possible source programs.

The core cases are deterministic synthetic constructions. Parameter variations and module identities produce distinct sources while sharing graph patterns, types and formulas. Family labels are isolated across partitions, but graph-template isolation, blind evaluation and machine-learning generalization are not established. The [data card](datasets/CORE_DATA_CARD.md) explains that distinction. Negative examples are intentional and remain part of the corpus.

## Institutional research and implementation obligations

The nine research volumes supply 25 source-to-profile mappings, separate source and target identity fields, capability attenuation requirements, ABI and image manifests, dependency and driver closure, membership and revocation contracts, nested federation routing, authenticated envelopes, durable inbox/outbox states, idempotency and replay rules, fault scenarios, threat analysis, evidence governance, reviewer responsibilities and release gates. Their [scenario catalog](research/07_SCENARIO_CATALOG.md) specifies setup, stimulus, oracle and observer for each proposed experiment. Twenty-two narrowly attributed [primary references](research/08_PRIMARY_SOURCE_BIBLIOGRAPHY.md) support external methods and protocol context.

Native milestones require an actual toolchain, generated images, boot receipts, qualified drivers and full resource enforcement. Federation milestones require authenticated services, durable effect transactions and crash/replay tests. Profile imports require authoritative per-profile grammar and operator semantics with versioned adapters. Those obligations are traceable design work rather than inferred completion from the local model.

## Package structure and evidence preservation

| Directory | Contents |
|---|---|
| `specification/` | Eight formal volumes, EBNF, stable rules, diagnostics, traceability and focused observations |
| `research/` | Nine systems/governance volumes and adapter, scenario, claim, requirement and bibliography registries |
| `mathematics/` | Mathematical volume, adapter draft, frozen figure/reference, host policy, datasets and numerical receipts |
| `runtime/` | Byte-exact core reference, original regression tests and example |
| `datasets/`, `examples/`, `schemas/` | Core master and partitions, 144 representative cases, strict record schema and data card |
| `tools/` | Deterministic construction, full validation, oracle fault probes, exact case extraction and integrity verification |
| `validation/` | Executed host receipts and package consistency review |
| `provenance/` | Upstream identities and selected byte-exact audit/specification evidence |

The selected upstream snapshot contains the source files cited by the adapter registries and the collection-level audit/fabric artifacts. It is not a duplicate of all original corpus payloads. Links inside preserved upstream documents may refer to unselected material; their original bytes are retained. [The evidence manifest](provenance/SELECTED_EVIDENCE_MANIFEST.json) states the selection explicitly. Curated LCUF volumes and registry evidence paths are packaged locally.

SHA-256 manifests support byte-integrity comparison against a trusted copy. They are not signatures, author authentication or execution attestations. Copied source materials and bundled dependencies retain their original ownership and license terms; this release does not supply an umbrella relicensing grant. Verification and reproduction details are in [REPRODUCIBILITY.md](REPRODUCIBILITY.md).
