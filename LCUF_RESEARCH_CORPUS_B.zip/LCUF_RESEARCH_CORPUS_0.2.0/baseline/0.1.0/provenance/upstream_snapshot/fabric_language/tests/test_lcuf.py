import hashlib, importlib.util, pathlib, sys, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('lcuf',ROOT/'lcuf.py'); lcuf=importlib.util.module_from_spec(spec); spec.loader.exec_module(lcuf)
SOURCE=(ROOT/'examples/federated_sum.lcuf').read_text(encoding='utf-8')

class Conformance(unittest.TestCase):
    def reject(self,text,expected):
        with self.assertRaisesRegex(lcuf.Diagnostic,expected): lcuf.compile_source(text)
    def test_positive_and_replay(self):
        compiled=lcuf.compile_source(SOURCE); a=lcuf.simulate(compiled); b=lcuf.simulate(compiled)
        self.assertEqual(a,b); self.assertEqual(a['values']['received'],42)
        self.assertEqual(len(a['receipts']),4)
    def test_missing_header_and_end(self):
        self.reject(SOURCE.replace('LCUF/0.1','LCUF/9.0'),'required header'); self.reject(SOURCE.rsplit('end',1)[0],'missing end')
    def test_duplicate_and_unknown_directive(self):
        self.reject(SOURCE.replace('module demo.federated_sum','module demo.federated_sum\nmodule x'),'duplicate module')
        self.reject(SOURCE.replace('module demo.federated_sum','module demo.federated_sum\nambient allow_all'),'unknown declaration')
    def test_denied_caps(self):
        self.reject(SOURCE.replace('caps=fabric.receive,evidence.write','caps=evidence.write'),'capability denied')
        self.reject(SOURCE.replace('caps=fabric.send','caps=-'),'sender lacks')
    def test_missing_link_and_implicit_remote(self):
        self.reject(SOURCE.replace('link edge cloud transfer=copy\n',''),'no directed')
        self.reject(SOURCE.replace('c | edge','c | cloud'),'cross-site input')
    def test_duplicate_writer_and_type(self):
        self.reject(SOURCE.replace('22 | right','22 | left'),'multiple writers')
        self.reject(SOURCE.replace('42 | expected | i64','true | expected | bool'),'different types')
    def test_cycle_and_undefined(self):
        self.reject(SOURCE.replace('20 | left | i64 | - | - | -','20 | left | i64 | - | - | c'),'dependency cycle')
        self.reject(SOURCE.replace('left,right','left,missing'),'undefined input')
    def test_budgets_and_memory(self):
        self.reject(SOURCE.replace('memory=64 steps=8','memory=64 steps=2'),'step admission')
        self.reject(SOURCE.replace('memory=64 steps=8','memory=1 steps=8'),'memory admission')
    def test_overflow_and_nonfinite(self):
        self.reject(SOURCE.replace('20 | left','9223372036854775807 | left'),'i64 bounds')
        self.reject(SOURCE.replace('20 | left','NaN | left'),'nonfinite')
    def test_effects_and_unknown_op(self):
        self.reject(SOURCE.replace('fabric.transfer | fabric.receive','- | fabric.receive'),'operation contract')
        self.reject(SOURCE.replace('| add |','| network_eval |'),'unsupported operation')
    def test_semantics_preserves_policy(self):
        a=lcuf.compile_source(SOURCE)['semantic_sha256']
        self.assertNotEqual(a,lcuf.compile_source(SOURCE.replace('trust=remote','trust=remote2'))['semantic_sha256'])
        self.assertNotEqual(a,lcuf.compile_source(SOURCE.replace('steps=8','steps=9'))['semantic_sha256'])
        self.assertEqual(a,lcuf.compile_source('# formatting\n'+SOURCE)['semantic_sha256'])
    def test_assertion_failure(self): self.reject(SOURCE.replace('42 | expected','43 | expected'),'assertion fails')
    def test_receipt_hash_chain(self):
        receipts=lcuf.simulate(lcuf.compile_source(SOURCE))['receipts']; previous='0'*64
        for r in receipts:
            self.assertEqual(r['previous_sha256'],previous)
            body={k:v for k,v in r.items() if k!='sha256'}
            self.assertEqual(lcuf.hash_value(body),r['sha256']); previous=r['sha256']
    def test_plan_cannot_claim_native_build(self):
        plan=lcuf.target_plan(lcuf.compile_source(SOURCE)); self.assertEqual(plan['status'],'design_plan_only')
        self.assertTrue(all(s['bootable_image'] is None for s in plan['sites'].values()))
    def test_repeated_operand_is_valid(self):
        text=SOURCE.replace('left,right','left,left').replace('42 | expected','40 | expected')
        self.assertEqual(lcuf.simulate(lcuf.compile_source(text))['values']['received'],40)
    def test_mutated_ir_cannot_be_simulated(self):
        c=lcuf.compile_source(SOURCE); c['ir']['sites']['edge']['trust']='changed'
        with self.assertRaisesRegex(lcuf.Diagnostic,'IR hash mismatch'): lcuf.simulate(c)
    def test_resource_integer_limits(self):
        self.reject(SOURCE.replace('memory=64','memory='+'9'*5000),'resource integer')
        self.reject(SOURCE.replace('steps=8','steps=\u0668'),'site requires')
        self.reject(SOURCE.replace('| 1 | none','| 9223372036854775808 | none'),'resource integer')
    def test_nested_literal_rejected(self):
        self.reject(SOURCE.replace('20 | left','['*2000+'0'+']'*2000+' | left'),'JSON scalar')
    def test_unicode_text(self):
        text='LCUF/0.1\nmodule unicode\nsite a trust=owner memory=64 steps=2\nid | site | profile | op | inputs | output | type | effects | caps | after | budget | evidence\nx | a | lcuf.scalar | const | "a\u2028b\u0085c\u2029d" | value | text | - | - | - | 1 | none\nend\n'
        self.assertEqual(lcuf.simulate(lcuf.compile_source(text))['values']['value'],'a\u2028b\u0085c\u2029d')
        self.reject(text.replace('"a\u2028b\u0085c\u2029d"','"\\ud800"'),'unpaired Unicode')
    def test_source_byte_identity(self):
        raw=b'\xef\xbb\xbf'+SOURCE.replace('\n','\r\n').encode('utf-8')
        c=lcuf.compile_source(raw)
        self.assertEqual(c['source_sha256'],hashlib.sha256(raw).hexdigest())
        self.assertEqual(c['semantic_sha256'],lcuf.compile_source(SOURCE)['semantic_sha256'])
    def test_scheduler_chooses_one_ready_row_at_a_time(self):
        source=SOURCE.replace('22 | right | i64 | - | - | -','22 | right | i64 | - | - | a')
        source=source.replace('\nend\n','\nz | edge | lcuf.scalar | const | 0 | extra | i64 | - | - | - | 1 | none\nend\n')
        ids=[r['id'] for r in lcuf.compile_source(source)['ir']['rows']]
        self.assertEqual(ids[:2],['a','b'])
    def test_prelude_and_remote_control_dependency(self):
        self.reject(SOURCE.replace('module demo.federated_sum\n','').replace('site edge','module demo.federated_sum\nsite edge',1).replace('module demo.federated_sum\nsite edge','site edge',1),'first declaration')
        self.reject(SOURCE.replace('42 | expected | i64 | - | - | -','42 | expected | i64 | - | - | a'),'cross-site after')

if __name__=='__main__': unittest.main(verbosity=2)
