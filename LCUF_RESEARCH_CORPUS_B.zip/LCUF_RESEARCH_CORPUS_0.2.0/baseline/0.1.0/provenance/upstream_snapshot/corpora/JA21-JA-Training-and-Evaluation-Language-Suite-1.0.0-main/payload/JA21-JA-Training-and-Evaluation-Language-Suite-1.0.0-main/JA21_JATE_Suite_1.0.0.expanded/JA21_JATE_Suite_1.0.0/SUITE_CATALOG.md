# Suite Catalog

## Core products

| Product | Location | Quantity |
|---|---|---:|
| Technical corpus | `corpus/technical/JA21_JATE_TECHNICAL_CORPUS_10000.jsonl.gz` | 10,000 records |
| Research shards | `corpus/technical/shards/` | 20 |
| Script pack | `scripts/` | 1,000 `.jate` programs |
| Textbook | `textbook/JA21_JA_TRAINING_EVALUATION_LANGUAGE_TEXTBOOK.md` | 22 chapters |
| Curriculum | `education/12_WEEK_CURRICULUM.md` | 12 weeks |

## Corpus distribution

| Validation class | Records | Script pack |
|---|---|---|
| positive | 4000 | 400 |
| negative | 1500 | 150 |
| boundary | 1000 | 100 |
| integration | 1000 | 100 |
| security | 750 | 75 |
| performance | 500 | 50 |
| determinism | 500 | 50 |
| interoperability | 250 | 25 |
| recovery | 250 | 25 |
| certification | 250 | 25 |

## Proficiency levels

| Level | Corpus | Script pack |
|---|---|---|
| beginner | 1000 | 100 |
| intermediate | 1000 | 100 |
| advanced | 1000 | 100 |
| expert | 1000 | 100 |
| compiler | 1000 | 100 |
| runtime | 1000 | 100 |
| optimization | 1000 | 100 |
| validation | 1000 | 100 |
| certification | 1000 | 100 |
| deployment | 1000 | 100 |

## Navigation

- `catalogs/FEATURE_ATLAS.md`
- `catalogs/TRAINING_EVALUATION_ARCHITECTURE.md`
- `catalogs/DIAGNOSTIC_CATALOG.md`
- `catalogs/ROLE_BASED_READING_PATHS.md`
- `specification/`
- `conformance/`
- `source/`
- `tools/`
