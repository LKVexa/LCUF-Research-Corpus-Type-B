# JA21 JA Security Policy Language Suite Catalog

| Product | Location | Scale |
|---|---|---:|
| Technical corpus | `corpus/technical/JA21_JASEC_TECHNICAL_CORPUS_10000.jsonl.gz` | 10,000 records |
| Corpus shards | `corpus/technical/shards/` | 20 × 500 |
| Script pack | `scripts/` | 1,000 programs |
| Script catalog | `catalogs/SCRIPT_CATALOG.csv` | 1,000 rows |
| Textbook | `textbook/JA21_JA_SECURITY_POLICY_LANGUAGE_TEXTBOOK.md` | 22 chapters |

Additional layers include catalogs, education, specification, contracts, conformance, starter, tools, design, preserved source, and integrity evidence.
