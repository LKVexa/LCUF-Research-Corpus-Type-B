# Suite Catalog

## Primary products

1. **Technical corpus** — `corpus/technical/JA21_JASP_TECHNICAL_CORPUS_10000.jsonl.gz`
2. **1,000-program pack** — `examples/scripts_1000/`
3. **Textbook** — `textbook/JA21_JA_SERVICE_PROTOCOL_LANGUAGE_TEXTBOOK.md`

## Supporting collections

- `catalogs/` — script, feature, diagnostic, architecture, and reading-path indexes
- `education/` — curriculum, workbook, and instructor guide
- `specification/` — grammar, language, compiler, runtime, semantic, and evidence contracts
- `conformance/` — cases, coverage, and certification guidance
- `starter_project/` — minimal local service
- `design/` — Protocol Weave publication system and local cover
- `source_original/` — exact upload and reconstructed source documents
- `tools/` — offline inspection and validation utilities
