# MSSL_WRITERS_CORPUS_1.0.0

This package is a comprehensive MSSL writing course and study corpus derived
from the attached BASIC MSSL 3.1.2 operational-readiness example. It contains a
25-lesson handbook, 25 exercises, sealed answer documents, ten reusable
authoring templates, annotated examples, grammar and field references, κ
sealing instructions, a common-error laboratory, and all 1,683 observed MSSL
sources for comparison. Normalized indexes and practice data support deeper
study without replacing the human-facing curriculum.

Start with `COURSE_MAP.md`, `QUICK_USE.md`, and Lesson 01.

The key honesty boundary is simple: the package is complete for the supplied
example, while constructs not demonstrated by that example remain unspecified.

## Audit upgrade 2026-10-09

Run `python tools/VERIFY_MSSL.py` (Python 3.9+) for exact integrity, seal, source-projection, dataset-reference and negative-fixture validation. The existing `.mssl` authorities are preserved byte for byte. Their claims are corpus observations, including any PASS or maturity statements; the validator does not turn those statements into execution evidence.
