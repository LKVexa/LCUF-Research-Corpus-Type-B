# Observed MSSL 0.1–0.3 concrete grammar

This EBNF describes every `.mssl` document in the supplied BASIC MSSL example.
It is an observed-subset grammar, not a claim about constructs absent from the
example. `json-object`, `json-array`, `json-string`, and `json-number` use RFC
8259 JSON syntax. Field order is invariant in all 1,683 observed documents.

```ebnf
document       = "MSSL{" alpha "," iota "," lambda "," rules "," placements
                 "," delta "," tau "," memory "," results "," diagnostics
                 "," execution "," extensions "," kappa "}⇒⊤" ;
alpha          = "α≡" json-object ;
iota           = "ι≡" json-string ;
lambda         = "λ≡" json-string ;
rules          = "ℛ≡" "{" [ rule { "," rule } ] "}" ;
rule           = rule-id ":" json-string ;
rule-id        = json-string-four-decimal-digits ;
placements     = "π≡" json-array ;
delta          = "δ≡" json-number ;
tau            = "τ≡" json-number ;
memory         = "μ≡" json-object ;
results        = "ρ≡" json-object ;
diagnostics    = "χ≡" json-array ;
execution      = "η≡" json-object ;
extensions     = "ν≡" json-object ;
kappa          = "κ≡" json-string ;

observed-call  = module-call | learn-call ;
module-call    = "module(" json-string ")" ;
learn-call     = "learn(" json-string ",literal(" json-string "))" ;
```

The rule values are JSON strings whose decoded contents conform to
`observed-call`. In a `learn` call, the `literal` argument is itself a JSON
string. Its text may be plain text, compact JSON, a relaxed bracket/comma list,
or a relaxed object spelling. The `μ` field is the authoritative typed
projection under `learn.<key>`; generic JSON decoding of literal text alone does
not reproduce every source document.
