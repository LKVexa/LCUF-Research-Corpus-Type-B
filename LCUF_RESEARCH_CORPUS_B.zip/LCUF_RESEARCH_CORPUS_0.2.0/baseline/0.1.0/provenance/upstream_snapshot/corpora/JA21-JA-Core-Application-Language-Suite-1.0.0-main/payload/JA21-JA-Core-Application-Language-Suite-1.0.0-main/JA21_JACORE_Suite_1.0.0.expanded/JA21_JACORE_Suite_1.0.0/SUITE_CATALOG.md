# Suite Catalog

## Identity

- Product: **JA21 JA Core Application Language Suite**
- Version: **1.0.0**
- Profile: `ja.core`
- Extension: `.ja`
- Publication mode: standalone, air-gap-safe
- Evidence status: source-faithful corpus publication; modeled compiler/runtime outcomes

## Deliverables

| Area | Location | Contents |
|---|---|---|
| Technical corpus | `corpus/technical/` | 10,000 records, 20 shards, schema, index, guide |
| Script pack | `scripts/` | 1,000 exact `.ja` programs in five tracks |
| Catalogs | `catalogs/` | script catalog, feature atlas/matrix, diagnostics, architecture, reading paths |
| Textbook | `textbook/` | 22-chapter technical textbook |
| Education | `education/` | curriculum, workbook, instructor guide |
| Specifications | `spec/` | EBNF, language, compiler/runtime, semantics, R12/MCRT, conformance |
| Starter | `starter/` | starter application |
| Design | `design/` | publication system, tokens, local SVG cover |
| Tools | `tools/` | offline inspector and validator |
| Source | `source/` | preserved wrapper and reconstructed source documents |
| Manifest | `manifest/` | machine-readable release inventory and SHA-256 sums |

## Script-pack distribution

- 100 scripts per proficiency level.
- Validation classes: 400 positive, 150 negative, 100 boundary, 100 integration, 75 security, 50 performance, 50 determinism, 25 interoperability, 25 recovery, and 25 certification.
- All 31 source features represented.

## Review model

SOPHIA, CHARLOTTE, LANDON, Professor, and Podium provide semantic, structural, executable, educational, and publication review lenses.
