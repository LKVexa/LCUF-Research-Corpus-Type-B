# LKVEXA LANGUAGE AUDIT AND USAGE GUIDE Updated Corpus Audit

This updated copy supplies selection, artifact ownership, maturity and cross-family navigation. Its import boundary is: Use this updated audit and evidence qualifications as current release authority.

## Source and coverage

Original input: `LKVEXA_LANGUAGE_AUDIT_AND_USAGE_GUIDE.md`. Source SHA 256: `8f30dba7f92f66c77d7ed7f4e6388a590e334560865a35155417879a31a06cf9`. The source archive is preserved in the parent folder. All 1 original leaf files were read and hashed; 0 stored JSONL rows were structurally parsed, including historical/reconstructed copies. Nested ZIPs are materialized in `.expanded` directories. Dataset row counts include duplicate representations and metadata headers; they are not unique executable programs.

Original checks and locations are in [the source manifest](audit/source_manifest.json). Current payload bytes are in [the updated manifest](audit/updated_manifest.json), and changes are in [the ledger](audit/change_ledger.json). Embedded source layers have [separate coverage](audit/embedded_layer_coverage.json). Historical hashes and modeled labels retain their historical meaning. The updated manifest and qualification sidecars govern this release.

## Upgrades and open implementation work

### BASE-24 Medium priority

Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries.

Status: **APPLIED**. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role.

Evidence: `audit/source_manifest.json | audit/updated_manifest.json | audit/dataset_qualification.json`.

Remaining gate: Use this updated audit and evidence qualifications as current release authority.

## Contribution to the new fabric language

Profile owner: `collection.guide`. Selection, artifact ownership, maturity and cross-family navigation. Use this updated audit and evidence qualifications as current release authority.

The [adapter contract](audit/fabric_adapter_contract.json) is a proposed interface with executable_adapter_implemented=false. It preserves source authority rather than using a feature label as inferred semantics. See [the collection architecture](../../fabric_language/ARCHITECTURE.md) and the [8S foundation](../../fabric_language/profiles/coupling8s/PROFILE.md).

## Qualification and verification

Use [dataset qualifications](audit/dataset_qualification.json) before training, importing or treating a record as evidence. A modeled pass or a structural validator pass is not native execution, authenticated federation, race proof, or physical device evidence. Current JA and DeepML technical records carry additional qualifications; deliberate negative examples remain negative examples.

The release provides an offline integrity checker: run `python tools/verify_release.py --deep` from the collection root. Per-profile test reports and validators qualify the exact behavior they checked. Complete grammars, native adapters, authenticated transports and a bootable unikernel remain separately tracked implementation gates.
