# JA Portal Scene Language — Standalone Profile 1.0

## Scope

JA Portal Scene is a deterministic, policy-governed JA21 language for declaring scenes, entities, components, resources, prefabs, events, systems, animation bindings, UI, physics, portals, terrain, serialization, snapshots, save/load packages, and evidence receipts.

## Core invariants

- Stable IDs are mandatory for persistent and cross-referenced state.
- Parent and dependency graphs must be acyclic unless a future profile defines a typed cycle.
- Every resource reference resolves to a declared, hashed, policy-admitted origin.
- Network and unknown-code execution are forbidden by the corpus profile.
- Units and component schemas are checked before runtime admission.
- Runtime mutations are deterministic and replayable.
- Serialization preserves semantic identity and graph topology.
- Optimization preserves source identity, semantic hash, R12 relation, MCRT provenance, and replay behavior.

## Evidence model

An admitted source produces a typed AST, semantic judgment, normalized graph, R12 record, modeled or native runtime trace, MCRT receipt, and certification decision. Rejected source produces a stable diagnostic and no downstream admission evidence. Modeled and native evidence are separate namespaces.
