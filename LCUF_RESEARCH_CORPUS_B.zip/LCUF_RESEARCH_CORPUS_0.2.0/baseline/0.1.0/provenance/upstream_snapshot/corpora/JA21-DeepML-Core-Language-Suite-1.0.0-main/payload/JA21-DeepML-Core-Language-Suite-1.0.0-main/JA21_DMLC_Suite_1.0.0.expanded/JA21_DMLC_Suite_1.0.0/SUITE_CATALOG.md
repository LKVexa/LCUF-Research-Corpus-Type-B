
# JA21 DeepML Core Suite Catalog

## 1. Technical corpus

- `corpus/technical/deepml_core_technical_corpus_10000.jsonl.gz`
- `corpus/technical/core_01.jsonl.gz` … `core_20.jsonl.gz`
- `corpus/technical/technical_record.schema.json`
- `corpus/technical/corpus_index.csv`
- `corpus/technical/TECHNICAL_CORPUS_GUIDE.md`

## 2. One-thousand-script pack

- `script_pack_1000/`
- `catalogs/SCRIPT_CATALOG.csv`
- `catalogs/SCRIPT_CATALOG.jsonl`
- Composition: 720 positive, 141 negative, 139 certification.

## 3. Textbook and education

- `textbook/JA21_DEEPML_CORE_LANGUAGE_TEXTBOOK.md`
- `textbook/TABLE_OF_CONTENTS.md`
- `education/12_WEEK_CURRICULUM.md`
- `education/STUDENT_WORKBOOK.md`
- `education/INSTRUCTOR_GUIDE.md`
- `education/learning_modules.json`

## 4. Language and implementation specifications

- DeepML Core EBNF and grammar specification
- Language suite specification
- Compiler and runtime contracts in JSON and explanatory Markdown
- Semantic operator registry and reference
- R12/MCRT profile schema
- Conformance and certification guide

## 5. Testing and tools

- Corpus-derived conformance cases and coverage expectations
- Topic matrix and diagnostic catalog
- Offline corpus inspector
- Full suite validator
- Starter project

## 6. Provenance and integrity

- Reconstructed source tree under `reference_source/deepml_core_0.3/`
- Preserved uploaded coupling-mechanics corpus wrapper
- Governance charter, release notes, validation report, manifest, and SHA-256 checksums
