# Suite Catalog

| Surface | Contents |
|---|---|
| `corpus/technical` | 10,000 normalized records, twenty shards, schema, index, and guide |
| `scripts` | 1,000 source-faithful `.jxd` programs across five tracks |
| `catalogs` | Script catalog, feature atlas, architecture, diagnostics, roles, compiler audit |
| `textbook` | 22-chapter JAXD textbook (17,687 words) |
| `education` | Twelve-week curriculum, workbook, instructor guide, modules |
| `specification` | Grammar, canonical specification, standalone profile, contracts, operators, evidence schema |
| `conformance` | 120 feature/class cases, coverage expectations, certification guide |
| `starter` | Minimal offline JAXD workbench |
| `tools` | Corpus inspector, structural validator, preserved bootstrap compiler |
| `design` | Experience Observatory publication system, tokens, SVG cover |
| `source_preservation` | Extracted canonical original package; original-upload hash retained |

## Script pack composition

- Positive: 400
- Negative: 150
- Boundary: 100
- Integration: 100
- Security: 75
- Performance: 50
- Determinism: 50
- Interoperability: 25
- Recovery: 25
- Certification: 25

Every proficiency level contributes exactly 100 programs.
