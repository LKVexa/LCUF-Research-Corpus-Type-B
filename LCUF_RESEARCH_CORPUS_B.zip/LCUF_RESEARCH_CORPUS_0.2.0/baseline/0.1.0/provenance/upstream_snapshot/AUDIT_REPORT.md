# LKVexa Collection Audit and Upgrade Report

All 24 requested archives and the supplied language guide have updated materialized copies. The structural audit read **29,780 original leaf files** and parsed **670,337 stored JSONL rows**. It also checked **171,327 embedded JSONL rows** within rewritten source wrappers; these overlap reconstructed data and are additional coverage, not unique examples. Original archives and the guide remain untouched in the source parent.

The release applies evidence-backed tool and source repairs, qualifies modeled outcomes, preserves provenance, and starts the proposed LKVexa Columned Unikernel Fabric Language. JA's intended mathematical foundation is the user-supplied 8S Penteract–S³ Master Coupled Mechanics Law; [the mathematical profile](fabric_language/profiles/coupling8s/PROFILE.md) and [reference image](fabric_language/profiles/coupling8s/ARITHMETIC_REFERENCE.png) preserve it.

## Audit scope and claim boundaries

Every source byte was read and hashed through nested ZIP and gzip layers. JSON/JSONL and embedded data were parsed, Python syntax checked, and local Markdown file targets checked. Semantic review followed each profile's specifications, grammars, feature atlas, records, starter examples, validators and repeated source templates. Focused execution checked the repaired local tools and reference interpreters. This is full structural coverage with profile-specific semantic review and scoped regression evidence. It does not certify every language's runtime or every modeled record as semantically correct.

The original collection contains specifications, generated example families, provisional grammars, reference simulators and modeled records. Counts measure stored rows; master/shard, historical and reconstructed copies must not be counted as independent training or conformance cases. Claims of native execution, physical adapters, proofs or authentication require evidence beyond a catalog label or a boolean field.

## Applied repairs

LCTL column lowering and roundtrip fingerprints now retain complete bundle and frame policy. Compact parsers reject malformed structure and unknown or duplicate keys, selftests report actual coverage, and updated Java artifacts are rebuilt. Fabric wrappers no longer equate descriptor counts, endpoint text, checkpoint inspection or CRDT booleans with execution, authentication, restored state or merge-law proof.

JAXD's bootstrap requires action capabilities, enforces supported syntax/version boundaries, rejects stale projections after failure, and labels projection/evidence outputs as structural and illustrative. The Certifier inspector's syntax error is repaired. JA Test/Proof fixture/property examples and JA Security no-leak polarity receive exact-source corrections and regenerated source hashes; inferred AST/runtime/proof labels remain modeled and require revalidation.

All current JA and DeepML technical copies are explicitly qualified. Six DeepML suites have actual Draft 2020-12 validators, exact source/profile/policy checks and master/shard comparison. Kernel's 5,231 source-target/device metadata conflicts are quarantined while deliberate expected failures remain identified. Grammar gaps are indexed instead of filled with unsupported catch-all rules. MSSL has portable validation, seal/static-semantic checks and helper repairs. Programming's embedded reference documents have readable views and complete logical-record indexes.

Specific source assertions were inconsistent with their own fixture or no-leak intent. That finding is separate from the attached 8S coupled mechanics law. Count-profile numerical probes have explicit scope and do not establish or override JA's entire arithmetic semantics.

## Corpus coverage and updated copies

| Input and individual audit | Original leaf files | Stored source JSONL rows | Changed or added payload files |
|---|---:|---:|---:|
| [COLUMNED_LCTL_CORPUS_1.0.0](corpora/COLUMNED_LCTL_CORPUS_1.0.0/AUDIT_AND_UPGRADES.md) | 226 | 2,768 | 8 |
| [JA21-DeepML-Animation-VFX-Language-Suite-1.0.0-main](corpora/JA21-DeepML-Animation-VFX-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,156 | 31,391 | 35 |
| [JA21-DeepML-Core-Language-Suite-1.0.0-main](corpora/JA21-DeepML-Core-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,166 | 31,393 | 35 |
| [JA21-DeepML-Kernel-Language-Suite-1.0.0-main](corpora/JA21-DeepML-Kernel-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,042 | 21,008 | 15 |
| [JA21-DeepML-Logic-Functional-Language-Suite-1.0.0-main](corpora/JA21-DeepML-Logic-Functional-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,171 | 31,391 | 15 |
| [JA21-DeepML-Motion-Animation-Language-Suite-1.0.0-main](corpora/JA21-DeepML-Motion-Animation-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,167 | 31,390 | 35 |
| [JA21-DeepML-Specialized-Language-Suite-1.0.0-main](corpora/JA21-DeepML-Specialized-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,172 | 31,387 | 35 |
| [JA21-JA-Agent-Language-Suite-1.0.0-main](corpora/JA21-JA-Agent-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,068 | 31,008 | 21 |
| [JA21-JA-Certifier-Grammar-Suite-1.0.0-main](corpora/JA21-JA-Certifier-Grammar-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,173 | 31,392 | 22 |
| [JA21-JA-Core-Application-Language-Suite-1.0.0-main](corpora/JA21-JA-Core-Application-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,066 | 31,008 | 21 |
| [JA21-JA-Data-Language-Suite-1.0.0-main](corpora/JA21-JA-Data-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,077 | 31,008 | 21 |
| [JA21-JA-Interface-Language-Suite-1.0.0-main](corpora/JA21-JA-Interface-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,069 | 31,108 | 21 |
| [JA21-JA-Operations-Language-Suite-1.0.0-main](corpora/JA21-JA-Operations-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,071 | 31,072 | 21 |
| [JA21-JA-Portal-Scene-Language-Suite-1.0.0-main](corpora/JA21-JA-Portal-Scene-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,173 | 31,394 | 21 |
| [JA21-JA-Programming-Language-Suite-1.0.0-main](corpora/JA21-JA-Programming-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 2 | 2 | 9 |
| [JA21-JA-Security-Policy-Language-Suite-1.0.0-main](corpora/JA21-JA-Security-Policy-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,070 | 31,072 | 1,030 |
| [JA21-JA-Service-and-Protocol-Language-Suite-1.0.0-main](corpora/JA21-JA-Service-and-Protocol-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,071 | 31,009 | 21 |
| [JA21-JA-Test-Simulation-and-Proof-Language-Suite-1.0.0-main](corpora/JA21-JA-Test-Simulation-and-Proof-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,071 | 31,008 | 778 |
| [JA21-JA-Training-and-Evaluation-Language-Suite-1.0.0-main](corpora/JA21-JA-Training-and-Evaluation-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,068 | 31,008 | 21 |
| [JA21-JAXD-UI-UX-Experience-Design-Language-Suite-1.0.0-main](corpora/JA21-JAXD-UI-UX-Experience-Design-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,119 | 41,120 | 26 |
| [JA21-MCRT-Portal-Timeline-Language-Suite-1.0.0-main](corpora/JA21-MCRT-Portal-Timeline-Language-Suite-1.0.0-main/AUDIT_AND_UPGRADES.md) | 1,124 | 21,414 | 21 |
| [LCTL_1.6.0_RC1_HYPERFEDERATED_EXECUTION_FABRIC](corpora/LCTL_1.6.0_RC1_HYPERFEDERATED_EXECUTION_FABRIC/AUDIT_AND_UPGRADES.md) | 3,271 | 3,630 | 140 |
| [LCTL_1.6.1_RC1_COLUMNED_HYPERFEDERATED_EXECUTION_LANGUAGE](corpora/LCTL_1.6.1_RC1_COLUMNED_HYPERFEDERATED_EXECUTION_LANGUAGE/AUDIT_AND_UPGRADES.md) | 3,346 | 3,630 | 150 |
| [LKVEXA_LANGUAGE_AUDIT_AND_USAGE_GUIDE](corpora/LKVEXA_LANGUAGE_AUDIT_AND_USAGE_GUIDE/AUDIT_AND_UPGRADES.md) | 1 | 0 | 1 |
| [MSSL_WRITERS_CORPUS_1.0.0](corpora/MSSL_WRITERS_CORPUS_1.0.0/AUDIT_AND_UPGRADES.md) | 1,840 | 77,726 | 13 |

## Upgrade register and remaining work

[UPGRADES.csv](UPGRADES.csv) and [UPGRADES.json](UPGRADES.json) contain 90 corpus-specific register entries with evidence paths and status. Applied repairs, evidence qualifications and open implementation are distinguished. [Payload changes](audit/payload_changes.json) records before and after hashes for every changed source path and added payload artifact. Historical authority bytes, manifests and certification claims retain their historical role; the updated manifests identify current bytes.

Open work includes complete JA/DeepML grammars and semantic frontends, genuine CRDT/recovery/adapter proofs, native device backends, independent execution/attestation, nested federation authority and a bootable unikernel. These are new implementation projects; adding a document cannot satisfy those gates.

## Initiated language creation

[LCUF Draft 0.1](fabric_language/LCUF_SPEC.md) includes a strict twelve-column parser, closed scalar reference operations, exact effect/capability checks, explicit directed copies, dependency admission, bounds and canonical policy-preserving IR. It includes a local two-site simulation and integrity-linked receipts. Its operation profiles are experimental LCUF contracts rather than claims of a completed JA or LCTL frontend.

The [architecture](fabric_language/ARCHITECTURE.md) and [all-input contribution matrix](fabric_language/CORPUS_CONTRIBUTIONS.csv) analyze every updated corpus as a proposed owner of a domain boundary. The separate 8S profile preserves the mathematical foundation and makes independence, coupling, geometry, projection and efficacy admission explicit. Its reference evaluator supplies scoped mathematical computation, not physical-system evidence.

The sample and `plan` command emit a design plan with no bootable image. Actual unikernel generation and authenticated federation remain explicit acceptance gates.

## Verification and reuse

Read the profile reports in `audit/` and the per-suite upgrade directories for exact tested counts and limits. Run `python tools/verify_release.py --deep` for current byte, JSON/JSONL and Python syntax integrity. Run `python tools/validate_ja.py` for JA dataset qualifications, source hashes and available publication schemas. DeepML upgraded validators require the locked JSON Schema dependencies, included once under `tools/vendor` for this Windows Python 3.12 environment; other platforms should install the locked dependencies for their interpreter.

The release checksum manifest is an integrity record relative to a trusted copy. It is not a cryptographic signature or an execution attestation.
