# LKVexa Corpus Upgrade Register

Applied repairs and evidence qualifications are listed with their remaining implementation gates. A scope correction prevents a false success claim; it does not implement the missing runtime. The [machine register](UPGRADES.csv) contains exact evidence paths for every entry.

## COLUMNED LCTL CORPUS 1 0 0

- **LCTL-001 — APPLIED.** Roundtrip could certify loss of bundle or frame policy. Serialize every bundle and frame field, preserve exact row confidence spelling, quote/unescape exactly, and fingerprint length-delimited complete arrays.

- **LCTL-002 — APPLIED.** Malformed compact source silently accepted. Reject unknown/duplicate keys and semantic alias collisions, malformed quotes, wrong directive order, unfinished frames, duplicate headers/IDs, and empty frames. Invalid commands and failed roundtrips now return a failure exit.

- **LCTL-003 — APPLIED.** Column selftest counts exceeded executed cases. Report 1 positive and 1 distinct negative case, add 120-check semantic-policy regression including all 53 roundtrips and 14 malformed variants, retain historical artifacts as source evidence.

- **LCTL-004 — APPLIED.** Grammar referenced undefined terminals. Complete lexical definitions and explain accepted forms, restricted key sets, required structure and uniqueness constraints.

- **LCTL-009 — APPLIED.** Corpus verifier did not validate compiler behavior or linked targets. Check exact source/target projections and training targets, run all53 compiler verifications/full-field roundtrips/current canonical lowerings, execute8 distinct negative fixtures, expose records vs uniqueness, support explicit static scope.

- **BASE-01 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Require a checked profile adapter before mapping existing LCTL rows into LCUF.

## JA21 DeepML Animation VFX Language Suite 1 0 0 main

- **deepml.vfx-GRAMMAR-001 — qualified; full domain grammar remains implementation backlog.** Published EBNF is not complete. Undefined domain/lexical references prevent complete source parsing. Precise per-profile grammar errata, machine-readable reference-gap index, draft lexical appendix and README link. Existing source grammar remains historical/provisional rather than being filled with permissive catch-all rules. Remaining: Full domain grammar remains open.

- **deepml.vfx-EVIDENCE-001 — applied.** Generated pass/runtime/AST labels are expected modeled evidence; no native compiler/runtime binary is supplied. Every current published corpus/technical gzip record gains explicit _deepml_audit: modeled_not_executed, observed_result null, native_execution_eligible false, exact source SHA evidence and conflict quarantine.

- **deepml.vfx-VALIDATOR-001 — applied and independently verified: Draft202012 full dataset validation and focused authority/corruption tests PASS.** Inherited structural validator does not apply the published JSON Schema or demonstrate lexical, type, proof or runtime conformance. New offline Draft202012 schema validator additionally enforces source/profile/policy consistency, independently recomputes audit qualification and checks master/shard equality. Publication schema requires the new audit extension; tests exercise source corruption, policy removal, forged execution flags and external references.

- **deepml.vfx-EXTENSION-001 — qualified.** Editorial couplingMechanics8SRecord rule is not reachable from program, and conceptual annotations do not supply executable mathematical/numerical evidence. Grammar index explicitly records disconnected extension and errata qualifies it as a separately adopted, independently evidenced experimental extension.

- **BASE-02 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Native GPU/device backend, bounds and numerical evidence required.

## JA21 DeepML Core Language Suite 1 0 0 main

- **deepml.core-GRAMMAR-001 — qualified; full domain grammar remains implementation backlog.** Published EBNF is not complete. Undefined domain/lexical references prevent complete source parsing. Precise per-profile grammar errata, machine-readable reference-gap index, draft lexical appendix and README link. Existing source grammar remains historical/provisional rather than being filled with permissive catch-all rules. Remaining: Full domain grammar remains open.

- **deepml.core-EVIDENCE-001 — applied.** Generated pass/runtime/AST labels are expected modeled evidence; no native compiler/runtime binary is supplied. Every current published corpus/technical gzip record gains explicit _deepml_audit: modeled_not_executed, observed_result null, native_execution_eligible false, exact source SHA evidence and conflict quarantine.

- **deepml.core-VALIDATOR-001 — applied and independently verified: Draft202012 full dataset validation and focused authority/corruption tests PASS.** Inherited structural validator does not apply the published JSON Schema or demonstrate lexical, type, proof or runtime conformance. New offline Draft202012 schema validator additionally enforces source/profile/policy consistency, independently recomputes audit qualification and checks master/shard equality. Publication schema requires the new audit extension; tests exercise source corruption, policy removal, forged execution flags and external references.

- **deepml.core-EXTENSION-001 — qualified.** Editorial couplingMechanics8SRecord rule is not reachable from program, and conceptual annotations do not supply executable mathematical/numerical evidence. Grammar index explicitly records disconnected extension and errata qualifies it as a separately adopted, independently evidenced experimental extension.

- **BASE-03 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Require profile parser, shape inference and model runtime evidence.

## JA21 DeepML Kernel Language Suite 1 0 0 main

- **deepml.kernel-GRAMMAR-001 — qualified; full domain grammar remains implementation backlog.** Published EBNF is not complete. Undefined domain/lexical references prevent complete source parsing. Precise per-profile grammar errata, machine-readable reference-gap index, draft lexical appendix and README link. Existing source grammar remains historical/provisional rather than being filled with permissive catch-all rules. Remaining: Full domain grammar remains open.

- **deepml.kernel-EVIDENCE-001 — applied.** Generated pass/runtime/AST labels are expected modeled evidence; no native compiler/runtime binary is supplied. Every current published corpus/technical gzip record gains explicit _deepml_audit: modeled_not_executed, observed_result null, native_execution_eligible false, exact source SHA evidence and conflict quarantine.

- **deepml.kernel-VALIDATOR-001 — applied and independently verified: Draft202012 full dataset validation and focused authority/corruption tests PASS.** Inherited structural validator does not apply the published JSON Schema or demonstrate lexical, type, proof or runtime conformance. New offline Draft202012 schema validator additionally enforces source/profile/policy consistency, independently recomputes audit qualification and checks master/shard equality. Publication schema requires the new audit extension; tests exercise source corruption, policy removal, forged execution flags and external references.

- **deepml.kernel-DEVICE-001 — applied.** DMK-00001 source target gpu disagrees with reported device.npu effects and device.cpu capabilities. Across the master, 5231 records have at least one source-target conflict, including 3930 expected pass records and 1301 expected-failure records. Preserve all original fields and expected outcomes; record exact warning paths/devices, quarantine conflicting metadata and deny native execution eligibility. No target is guessed.

- **deepml.kernel-UNIKERNEL-001 — design initiation prerequisite recorded.** Tensor/device kernels do not implement operating-system unikernel boot, image, linker, ABI, syscall/driver, memory isolation or lifecycle contracts. Per-profile fabric readiness errata makes the distinction explicit and specifies a separate image/runtime contract milestone.

- **BASE-04 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Rederive device metadata through a native frontend and require verified target authority and execution evidence.

## JA21 DeepML Logic Functional Language Suite 1 0 0 main

- **deepml.logic-GRAMMAR-001 — qualified; full domain grammar remains implementation backlog.** Published EBNF is not complete. Undefined domain/lexical references prevent complete source parsing. Precise per-profile grammar errata, machine-readable reference-gap index, draft lexical appendix and README link. Existing source grammar remains historical/provisional rather than being filled with permissive catch-all rules. Remaining: Full domain grammar remains open.

- **deepml.logic-EVIDENCE-001 — applied.** Generated pass/runtime/AST labels are expected modeled evidence; no native compiler/runtime binary is supplied. Every current published corpus/technical gzip record gains explicit _deepml_audit: modeled_not_executed, observed_result null, native_execution_eligible false, exact source SHA evidence and conflict quarantine.

- **deepml.logic-VALIDATOR-001 — applied and independently verified: Draft202012 full dataset validation and focused authority/corruption tests PASS.** Inherited structural validator does not apply the published JSON Schema or demonstrate lexical, type, proof or runtime conformance. New offline Draft202012 schema validator additionally enforces source/profile/policy consistency, independently recomputes audit qualification and checks master/shard equality. Publication schema requires the new audit extension; tests exercise source corruption, policy removal, forged execution flags and external references.

- **deepml.logic-EXTENSION-001 — qualified.** Editorial couplingMechanics8SRecord rule is not reachable from program, and conceptual annotations do not supply executable mathematical/numerical evidence. Grammar index explicitly records disconnected extension and errata qualifies it as a separately adopted, independently evidenced experimental extension.

- **BASE-05 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Check actual inference and proof obligations; labels are modeled.

## JA21 DeepML Motion Animation Language Suite 1 0 0 main

- **deepml.motion-GRAMMAR-001 — qualified; full domain grammar remains implementation backlog.** Published EBNF is not complete. Undefined domain/lexical references prevent complete source parsing. Precise per-profile grammar errata, machine-readable reference-gap index, draft lexical appendix and README link. Existing source grammar remains historical/provisional rather than being filled with permissive catch-all rules. Remaining: Full domain grammar remains open.

- **deepml.motion-EVIDENCE-001 — applied.** Generated pass/runtime/AST labels are expected modeled evidence; no native compiler/runtime binary is supplied. Every current published corpus/technical gzip record gains explicit _deepml_audit: modeled_not_executed, observed_result null, native_execution_eligible false, exact source SHA evidence and conflict quarantine.

- **deepml.motion-VALIDATOR-001 — applied and independently verified: Draft202012 full dataset validation and focused authority/corruption tests PASS.** Inherited structural validator does not apply the published JSON Schema or demonstrate lexical, type, proof or runtime conformance. New offline Draft202012 schema validator additionally enforces source/profile/policy consistency, independently recomputes audit qualification and checks master/shard equality. Publication schema requires the new audit extension; tests exercise source corruption, policy removal, forged execution flags and external references.

- **deepml.motion-EXTENSION-001 — qualified.** Editorial couplingMechanics8SRecord rule is not reachable from program, and conceptual annotations do not supply executable mathematical/numerical evidence. Grammar index explicitly records disconnected extension and errata qualifies it as a separately adopted, independently evidenced experimental extension.

- **BASE-06 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Keep simulation and physical/display execution evidence distinct.

## JA21 DeepML Specialized Language Suite 1 0 0 main

- **deepml.specialized-GRAMMAR-001 — qualified; full domain grammar remains implementation backlog.** Published EBNF is not complete. Undefined domain/lexical references prevent complete source parsing. Precise per-profile grammar errata, machine-readable reference-gap index, draft lexical appendix and README link. Existing source grammar remains historical/provisional rather than being filled with permissive catch-all rules. Remaining: Full domain grammar remains open.

- **deepml.specialized-EVIDENCE-001 — applied.** Generated pass/runtime/AST labels are expected modeled evidence; no native compiler/runtime binary is supplied. Every current published corpus/technical gzip record gains explicit _deepml_audit: modeled_not_executed, observed_result null, native_execution_eligible false, exact source SHA evidence and conflict quarantine.

- **deepml.specialized-VALIDATOR-001 — applied and independently verified: Draft202012 full dataset validation and focused authority/corruption tests PASS.** Inherited structural validator does not apply the published JSON Schema or demonstrate lexical, type, proof or runtime conformance. New offline Draft202012 schema validator additionally enforces source/profile/policy consistency, independently recomputes audit qualification and checks master/shard equality. Publication schema requires the new audit extension; tests exercise source corruption, policy removal, forged execution flags and external references.

- **deepml.specialized-EXTENSION-001 — qualified.** Editorial couplingMechanics8SRecord rule is not reachable from program, and conceptual annotations do not supply executable mathematical/numerical evidence. Grammar index explicitly records disconnected extension and errata qualifies it as a separately adopted, independently evidenced experimental extension.

- **BASE-07 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Units and precision must extend a checked base profile.

## JA21 JA Agent Language Suite 1 0 0 main

- **JA-01 — mitigated_by_explicit_evidence_qualification.** JAA-00001 declares tool.invoke:approved while modeled capability metadata lists model.infer. 8,750 source records have a lexical requirement absent from modeled capability metadata. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-08 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Reinfer capabilities from actual source; prevent delegated privilege amplification.

## JA21 JA Certifier Grammar Suite 1 0 0 main

- **JA-02 — applied_source_or_tool_repair_and_qualified.** The shipped inspector has an unterminated string at line 23. The provisional grammar references 10 external or undefined symbols and omits a start declaration alternative used by starter/hello_certifier.ebnf. JCG inspector syntax repair Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-09 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Complete grammar and run actual parser/type/proof checks.

## JA21 JA Core Application Language Suite 1 0 0 main

- **JA-03 — mitigated_by_explicit_evidence_qualification.** JACORE-00001 has a pure record transformation and JSON emission, while modeled effect metadata says file.read and semantic operator match. The metadata must be rederived from a real profile frontend. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-10 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Preserve intended 8S foundation; define typed scalar and coupled operators separately.

## JA21 JA Data Language Suite 1 0 0 main

- **JA-04 — mitigated_by_explicit_evidence_qualification.** JAD-00001 is labeled join but contains a schema, single dataset and filtered projection without a join construct. Four numeral-normalized source templates cover 32 labeled features; label coverage is not syntactic implementation coverage. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-11 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Do not equate join feature labels with executable join syntax.

## JA21 JA Interface Language Suite 1 0 0 main

- **JA-05 — mitigated_by_explicit_evidence_qualification.** JAUI-00001 action requires admin.action:approved but modeled capability metadata lists only ui.render. 8,755 source records have lexical requirements absent from modeled capability metadata. A keyboard completeness assertion is not traversal evidence. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-12 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: UI capability labels require source inference; keep client outside kernel authority.

## JA21 JA Operations Language Suite 1 0 0 main

- **JA-06 — mitigated_by_explicit_evidence_qualification.** Two numeral-normalized source templates cover 32 labeled features. The runtime contract describes deployment effects but supplies structural tooling rather than an executor; deployment.reproducible assertions are expected obligations. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-13 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Require dependency closure, actual boot and rollback receipts.

## JA21 JA Portal Scene Language Suite 1 0 0 main

- **JA-07 — mitigated_by_explicit_evidence_qualification.** validation_result.result=pass and stage=runtime are modeled expectations. The standalone grammar uses undefined lexical and statement productions; .ja extension overlaps Core and historical SOPHIA. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-14 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Separate spatial semantics from timing and runtime device drivers.

## JA21 JA Programming Language Suite 1 0 0 main

- **JA-08 — applied_source_or_tool_repair_and_qualified.** The archive is two rewritten document wrappers, not a ready suite tree. The reduced text merges declaration line breaks; its lossless-regeneration promise lacks a shipped generator or an original byte baseline. Embedded source hashes refer to older documents. Programming readable views and logical record indexing Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-15 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Reference text only until a versioned parser and runtime are implemented.

## JA21 JA Security Policy Language Suite 1 0 0 main

- **JA-09 — applied_source_or_tool_repair_and_qualified.** Passing examples asserted secret_leak=true while intended failure examples asserted false. All 10,000 current assertions now use the corrected polarity, with hashes and qualifications refreshed. Security leak assertion polarity repair Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-16 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Use corrected no-leak invariant; execute policy engine denial tests before admission.

## JA21 JA Service and Protocol Language Suite 1 0 0 main

- **JA-10 — mitigated_by_explicit_evidence_qualification.** The original master contains 10,001 JSON lines: 10,000 source examples and a document coupling preamble. Preamble metadata must not enter example-schema validation or source compilation. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-17 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Metadata header is not an extra program; prove actual transport failure behavior.

## JA21 JA Test Simulation and Proof Language Suite 1 0 0 main

- **JA-11 — applied_source_or_tool_repair_and_qualified.** 7,500 expected-pass source examples mixed a fixed fixture result with a universally quantified range. Updated source preserves the original literal fixture input/expected in an independent unit test and retains the bounded nondecrease property. The attached 8S JA arithmetic foundation is preserved; operator and Count semantics require native validation. JATP independent fixture oracle and bounded invariant separation with source/hash/span/qualification propagation; 2,500 deliberate failure sources unchanged. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **FOUNDATION-01 — QUALIFIED; VERSIONED_MIGRATION_OPEN.** Legacy record coupling annotations retain d4/g4 and TRUE_4D strings while the attached foundational law uses five-coordinate centers and g5/delta8/g3/gJ. Preserve image and document foundation as current reference; isolate historical annotations through dataset qualifications and an explicit profile boundary. Remaining: Version and rederive legacy annotation fields through a checked coupling8s adapter before executable import.

- **BASE-18 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Keep independent fixture oracles; current checks do not certify a native JA proof runtime.

## JA21 JA Training and Evaluation Language Suite 1 0 0 main

- **JA-12 — mitigated_by_explicit_evidence_qualification.** Two numeral-normalized source templates cover 32 labeled features. Declared seed and mixed precision do not establish hardware-independent replay; experiment.reproducible remains an obligation until environment and numerical profiles are executed. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-19 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Require actual training evidence and measured acceptance; labels are expected.

## JA21 JAXD UI UX Experience Design Language Suite 1 0 0 main

- **JA-13 — applied_source_or_tool_repair_and_qualified.** The bootstrap action regex could not detect actions lacking requires, accepted arbitrary versions and labeled regex acceptance certified pass. Revised checks fix these defects and emit structural-only evidence with illustrative projections. JAXD bootstrap hardening Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-20 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Bootstrap supports a checked subset; illustrative projections are not certified.

## JA21 MCRT Portal Timeline Language Suite 1 0 0 main

- **JA-14 — mitigated_by_explicit_evidence_qualification.** The canonical grammar references undefined event/key/marker/branch/checkpoint/sync/transition/playback productions; modeled receipts do not establish a distributed clock or causal consensus implementation. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded. Remaining: A complete versioned profile parser, semantic inference and target/runtime conformance are needed before native admission.

- **BASE-21 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Timeline descriptions and executed event ledgers have different authority.

## LCTL 1 6 0 RC1 HYPERFEDERATED EXECUTION FABRIC

- **LCTL-005 — APPLIED_SCOPE_CORRECTION_WITH_OPEN_IMPLEMENTATION.** 1.6 descriptor counts were presented as semantic conformance. Add descriptor schema/identity validation; report PASS_WITH_SCOPE, descriptor_execution=false, actual repeated selftest coverage, and full_conformance_verified=false. Building executable inputs for every named group remains open.

- **LCTL-006 — APPLIED.** 1.5 runner ignored individual descriptor data. Read and validate all 512 descriptors, pass exact inputs to a batched Java runner, execute 768 underlying reference calls/package, enforce invalid-type error specificity. Results remain scoped because CRDT algebra is not implemented.

- **LCTL-007 — APPLIED_FAIL_CLOSED_WITH_OPEN_AUTHENTICATION.** Unsigned adapter text could become authenticated evidence. Declared fields no longer become authentication; verified flags remain false, all physical requests remain BLOCKED_EXTERNAL_AUTHORITY, blocking propagates through wrapper and CLI exits3. Signed structured receipt validation remains open.

- **LCTL-008 — APPLIED_SCOPE_CORRECTION_WITH_OPEN_IMPLEMENTATION.** Reference aggregates and checkpoint text overstated implementation. Report merge laws as unknown and merge_laws_verified=false; report runtime_state_restored=false and operation=CHECKPOINT_METADATA_INSPECTION. Real merge algebra and validated complete-state restoration remain open.

- **LCTL-010 — APPLIED.** Missing status/checksum records could be accepted. Require explicit PASS/status evidence, bound runtime calls, reject malformed/duplicate/escaping/missing checksum records, preserve source hashes in provenance and rebuild current checksum manifests.

- **LCTL-011 — APPLIED.** Nonfinite numeric cells bypassed comparison-based bounds. Require Double.isFinite in the canonical numeric decoder, rebuild every exposed runtime jar and mirror the updated column tooling jar. Reject 16 resealed variants spanning four numeric contexts and four nonfinite spellings in both core and fabric admission.

- **LCTL-012 — APPLIED.** Fabric entry points bypassed canonical seals and admission. Make canonical verification mandatory at the fabric boundary and derive the program from the verified in-memory snapshot, binding its original source digest without rereading mutable source. Remove unsupported source magic claims and exercise five admission variants with explicit core/fabric rejection checks. Rebuild all five exposed runtime jars per package.

- **BASE-22 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: 1.6 descriptors are structurally checked; physical transport/authentication/proofs remain open.

## LCTL 1 6 1 RC1 COLUMNED HYPERFEDERATED EXECUTION LANGUAGE

- **LCTL-001 — APPLIED.** Roundtrip could certify loss of bundle or frame policy. Serialize every bundle and frame field, preserve exact row confidence spelling, quote/unescape exactly, and fingerprint length-delimited complete arrays.

- **LCTL-002 — APPLIED.** Malformed compact source silently accepted. Reject unknown/duplicate keys and semantic alias collisions, malformed quotes, wrong directive order, unfinished frames, duplicate headers/IDs, and empty frames. Invalid commands and failed roundtrips now return a failure exit.

- **LCTL-003 — APPLIED.** Column selftest counts exceeded executed cases. Report 1 positive and 1 distinct negative case, add 120-check semantic-policy regression including all 53 roundtrips and 14 malformed variants, retain historical artifacts as source evidence.

- **LCTL-004 — APPLIED.** Grammar referenced undefined terminals. Complete lexical definitions and explain accepted forms, restricted key sets, required structure and uniqueness constraints.

- **LCTL-005 — APPLIED_SCOPE_CORRECTION_WITH_OPEN_IMPLEMENTATION.** 1.6 descriptor counts were presented as semantic conformance. Add descriptor schema/identity validation; report PASS_WITH_SCOPE, descriptor_execution=false, actual repeated selftest coverage, and full_conformance_verified=false. Building executable inputs for every named group remains open.

- **LCTL-006 — APPLIED.** 1.5 runner ignored individual descriptor data. Read and validate all 512 descriptors, pass exact inputs to a batched Java runner, execute 768 underlying reference calls/package, enforce invalid-type error specificity. Results remain scoped because CRDT algebra is not implemented.

- **LCTL-007 — APPLIED_FAIL_CLOSED_WITH_OPEN_AUTHENTICATION.** Unsigned adapter text could become authenticated evidence. Declared fields no longer become authentication; verified flags remain false, all physical requests remain BLOCKED_EXTERNAL_AUTHORITY, blocking propagates through wrapper and CLI exits3. Signed structured receipt validation remains open.

- **LCTL-008 — APPLIED_SCOPE_CORRECTION_WITH_OPEN_IMPLEMENTATION.** Reference aggregates and checkpoint text overstated implementation. Report merge laws as unknown and merge_laws_verified=false; report runtime_state_restored=false and operation=CHECKPOINT_METADATA_INSPECTION. Real merge algebra and validated complete-state restoration remain open.

- **LCTL-010 — APPLIED.** Missing status/checksum records could be accepted. Require explicit PASS/status evidence, bound runtime calls, reject malformed/duplicate/escaping/missing checksum records, preserve source hashes in provenance and rebuild current checksum manifests.

- **LCTL-011 — APPLIED.** Nonfinite numeric cells bypassed comparison-based bounds. Require Double.isFinite in the canonical numeric decoder, rebuild every exposed runtime jar and mirror the updated column tooling jar. Reject 16 resealed variants spanning four numeric contexts and four nonfinite spellings in both core and fabric admission.

- **LCTL-012 — APPLIED.** Fabric entry points bypassed canonical seals and admission. Make canonical verification mandatory at the fabric boundary and derive the program from the verified in-memory snapshot, binding its original source digest without rereading mutable source. Remove unsupported source magic claims and exercise five admission variants with explicit core/fabric rejection checks. Rebuild all five exposed runtime jars per package.

- **BASE-23 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Use full-policy fingerprints; no native federation execution claim.

## LKVEXA LANGUAGE AUDIT AND USAGE GUIDE

- **BASE-24 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Use this updated audit and evidence qualifications as current release authority.

## MSSL WRITERS CORPUS 1 0 0

- **MSSL-001 — APPLIED.** Seal helper could not reliably compute or report failures. Use one portable standard-library parser/helper and grouped CMD usage, parse top-level field boundaries even when marker text occurs inside quoted strings; preserve compatibility PowerShell sample APIs. No authority bytes changed.

- **MSSL-002 — APPLIED.** Integrity/count-only validation did not check semantic source projections. Add portable observed-subset validator, strict integrity records, all positive and negative fixture validation, normalized statement/fact/source coverage, exact seals and split leakage checks. Tighten validation schema booleans. Runtime claims remain observations.

- **BASE-25 — APPLIED.** Nested packaging, raw modeled labels and historical copies need explicit current provenance and reuse boundaries. Expanded materialized payload; source and updated manifests; change ledger; dataset-bound qualification; individual audit and fabric role. Remaining: Preserve original authority/seals; record validation is not physical/runtime certification.
