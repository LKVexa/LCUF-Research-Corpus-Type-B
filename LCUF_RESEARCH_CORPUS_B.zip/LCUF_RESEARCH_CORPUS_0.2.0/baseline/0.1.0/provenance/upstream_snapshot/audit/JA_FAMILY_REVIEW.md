# JA family audit and fabric language roles

The updated JA family can supply language contracts and source references for the proposed fabric language. Its modeled AST, semantic, R12, runtime and MCRT outcomes remain expectations. Current record qualifications preserve that distinction, and native execution eligibility remains false until a real implementation produces evidence.

The 14 archives include 13 suites with 10,000 source examples each, plus a Programming archive holding two rewritten reference documents. The original Service master additionally carries one document-metadata preamble. All primary record text was scanned for identity, source templates, requirements and evidence labeling; specs, grammar, current tooling and representative feature programs were reviewed for semantic consistency.

## Applied repairs

- JAXD bootstrap checks now reject missing or empty action capabilities, unsupported versions, delimiter-order errors, spoofed declarations in comments or strings, and missing reduced-motion branches on individual motion declarations. Accepted output is structural evidence; certification is not performed. Rejected input clears stale projections. Generated keyboard-completeness and kernel-race assertions were removed, and projections are marked illustrative. Fourteen regression tests pass; the revised bootstrap accepts 959 and rejects 41 of the 1,000 shipped scripts within its documented subset.
- JA Certifier `tools/inspect_corpus.py` now parses and runs: its line 23 string literal is repaired.
- JA Test Simulation and Proof separates 7,500 fixed fixture unit checks from their bounded nondecrease properties, preserving the original literal fixture inputs/expectations and all 2,500 deliberately failing source programs. It updates 750 scripts, 21 gzip datasets, catalog/index hashes and 22 handbook snippets. Five regression checks verify preservation, independent oracle sensitivity, 382,297 bounded Count values, hashes, qualifiers and replica consistency under the stated Count interpretation. Original structural validation passes; full profile typing and simulation/proof execution remain separate obligations.
- JA Security has 10,000 corrected leak assertions: 7,500 modeled-pass records require `secret_leak == false`, and 2,500 deliberately failing records require `true`. The update includes 1,000 scripts, 21 gzip datasets, 64 conformance references, catalogs, indexes and handbook examples. Source qualifiers were recomputed. Five regression checks and the original structural validator pass.
- JA Programming now includes exact UTF-8 views of both supplied rewritten texts, a separate canonical version 0.2 specification, and indexed complete blocks for 11,072 sequential bootstrap records and 34,899 sequential conformance cases. They remain historical reference expectations. Measured normalized-document hashes replace ambiguity about embedded older source hashes.

## Corpus findings and proposed roles

### Agent

**Profile:** `ja.agent`. **Proposed columns:** `AUTH`, `PLAN`, `EVID`.

JAA-00001 declares tool.invoke:approved while modeled capability metadata lists model.infer. 8,750 source records have a lexical requirement absent from modeled capability metadata.

Typed plan steps, bounded budgets, tool authority, approvals, memory retention and causal observations.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_JAA_Suite_1.0.0/corpus/technical/JA21_JAA_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JAA_Suite_1.0.0/specifications/LANGUAGE_SPECIFICATION.md`.

### Certifier

**Profile:** `ja.certifier`. **Proposed columns:** `VERIFY`, `EVID`.

The shipped inspector has an unterminated string at line 23. The provisional grammar references 10 external or undefined symbols and omits a start declaration alternative used by starter/hello_certifier.ebnf.

Versioned grammar identities, ambiguity and reachability checks, diagnostics and exact-source certification obligations.

**Upgrade status:** applied source or tool repair and qualified. JCG inspector syntax repair.

**Source locations:** `JA21_JCG_Suite_1.0.0/tools/inspect_corpus.py`, `JA21_JCG_Suite_1.0.0/specifications/JA_CERTIFIER_GRAMMAR_SOURCE.ebnf`.

### Core

**Profile:** `ja.core`. **Proposed columns:** `UNIT`, `STATE`, `AUTH`.

JACORE-00001 has a pure record transformation and JSON emission, while modeled effect metadata says file.read and semantic operator match. The metadata must be rederived from a real profile frontend.

Values, algebraic types, ownership, effects, modules and guest-local application behavior. Host integration requires a declared adapter.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_JACORE_Suite_1.0.0/corpus/technical/JA21_JACORE_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JACORE_Suite_1.0.0/spec/LANGUAGE_SPECIFICATION.md`.

### Data

**Profile:** `ja.data`. **Proposed columns:** `DATA`, `AUTH`, `EVID`.

JAD-00001 is labeled join but contains a schema, single dataset and filtered projection without a join construct. Four numeral-normalized source templates cover 32 labeled features; label coverage is not syntactic implementation coverage.

Schemas, nullable values, deterministic ordering, lineage, retention, partitions and data-use rights.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_JAD_Suite_1.0.0/corpus/technical/JA21_JAD_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JAD_Suite_1.0.0/specification/LANGUAGE_SPECIFICATION.md`.

### Interface

**Profile:** `ja.interface`. **Proposed columns:** `VIEW`, `STATE`, `AUTH`.

JAUI-00001 action requires admin.action:approved but modeled capability metadata lists only ui.render. 8,755 source records have lexical requirements absent from modeled capability metadata. A keyboard completeness assertion is not traversal evidence.

Typed interaction and accessibility graphs projected through target adapters outside the minimal guest.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_JAUI_Suite_1.0.0/corpus/technical/JA21_JAUI_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JAUI_Suite_1.0.0/contracts/RUNTIME_CONTRACT.md`.

### Operations

**Profile:** `ja.operations`. **Proposed columns:** `UNIT`, `PLACE`, `PLAN`, `EVID`.

Two numeral-normalized source templates cover 32 labeled features. The runtime contract describes deployment effects but supplies structural tooling rather than an executor; deployment.reproducible assertions are expected obligations.

Reproducible image inputs, compiler profiles, dependency locks, resource budgets, declared network bindings and journaled upgrade/rollback plans.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_JAOPS_Suite_1.0.0/corpus/technical/JA21_JAOPS_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JAOPS_Suite_1.0.0/specification/LANGUAGE_SPECIFICATION.md`.

### Portal Scene

**Profile:** `ja.portal.scene`. **Proposed columns:** `STATE`, `VIEW`, `CLOCK`.

validation_result.result=pass and stage=runtime are modeled expectations. The standalone grammar uses undefined lexical and statement productions; .ja extension overlaps Core and historical SOPHIA.

Stable scene/component graphs, snapshots, resource identity and deterministic bridges to timeline/motion profiles.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_JPSL_Suite_1.0.0/corpus/technical/JA21_JPSL_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JPSL_Suite_1.0.0/spec/grammar/JA_PORTAL_SCENE_STANDALONE.ebnf`.

### Programming

**Profile:** `sophia.ja.0.2`. **Proposed columns:** `UNIT`, `EVID`, `VERIFY`.

The archive is two rewritten document wrappers, not a ready suite tree. The reduced text merges declaration line breaks; its lossless-regeneration promise lacks a shipped generator or an original byte baseline. Embedded source hashes refer to older documents.

Historical observation, classification, routing, learning, archive inspection and versioned technical-suite namespaces.

**Upgrade status:** applied source or tool repair and qualified. Programming readable views and logical record indexing.

**Source locations:** `JA_Language_Coupling_Mechanics_Corpus.jsonl.gz`.

### Security

**Profile:** `ja.security`. **Proposed columns:** `AUTH`, `EVID`.

Passing examples asserted secret_leak=true while intended failure examples asserted false. All 10,000 current assertions now use the corrected polarity, with hashes and qualifications refreshed.

Principal/resource scope, capability attenuation, deny precedence, revocation/expiry, approval witnesses, secret redaction and fail-closed decisions.

**Upgrade status:** applied source or tool repair and qualified. Security leak assertion polarity repair.

**Source locations:** `JA21_JASEC_Suite_1.0.0/corpus/technical/JA21_JASEC_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JASEC_Suite_1.0.0/specification/LANGUAGE_SPECIFICATION.md`.

### Service and Protocol

**Profile:** `ja.service`. **Proposed columns:** `PLAN`, `DATA`, `AUTH`, `PLACE`.

The original master contains 10,001 JSON lines: 10,000 source examples and a document coupling preamble. Preamble metadata must not enter example-schema validation or source compilation.

Typed messages, legal protocol states, explicitly authorized transports, bounded retries, idempotency, quotas and offline behavior.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_JASP_Suite_1.0.0/corpus/technical/JA21_JASP_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JASP_Suite_1.0.0/specification/LANGUAGE_SPECIFICATION.md`.

### Test Simulation and Proof

**Profile:** `ja.proof`. **Proposed columns:** `VERIFY`, `CLOCK`, `EVID`.

7,500 expected-pass property examples compared every x<=input to one fixed fixture result. Under the stated Count interpretation, JATP-00001 gives 0 at x=0 while the fixture expectation is 6. Updated source preserves the fixed fixture oracle in a separate unit test and retains the bounded nondecrease property; derived modeled evidence still requires native revalidation.

Deterministic generators, virtual-time failure schedules, properties, proof obligations and guest/fabric conformance checks.

**Upgrade status:** applied source or tool repair and qualified. JATP quantified arithmetic assertion repair.

**Source locations:** `JA21_JATP_Suite_1.0.0/corpus/technical/JA21_JATP_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JATP_Suite_1.0.0/conformance/ARITHMETIC_AUDIT_ERRATA.md`.

### Training and Evaluation

**Profile:** `ja.training`. **Proposed columns:** `PLAN`, `DATA`, `VERIFY`, `EVID`.

Two numeral-normalized source templates cover 32 labeled features. Declared seed and mixed precision do not establish hardware-independent replay; experiment.reproducible remains an obligation until environment and numerical profiles are executed.

Immutable model/dataset references, seeds, evaluation gates, checkpoint lineage and registry promotion through authorized adapters.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_JATE_Suite_1.0.0/corpus/technical/JA21_JATE_TECHNICAL_CORPUS_10000.jsonl.gz`, `JA21_JATE_Suite_1.0.0/specification/LANGUAGE_SPECIFICATION.md`.

### Experience Design

**Profile:** `ja.experience.design`. **Proposed columns:** `VIEW`, `STATE`, `AUTH`, `CLOCK`.

The bootstrap action regex could not detect actions lacking requires, accepted arbitrary versions and labeled regex acceptance certified pass. Revised checks fix these defects and emit structural-only evidence with illustrative projections.

Design tokens, journeys, accessible interaction, reduced-motion outcomes and readable target projections outside the minimal guest.

**Upgrade status:** applied source or tool repair and qualified. JAXD bootstrap hardening.

**Source locations:** `JA21_JAXD_Suite_1.0.0_COMPACT/tools/jxd_compiler.py`, `JA21_JAXD_Suite_1.0.0_COMPACT/tools/AUDIT_COMPILER_REVISION.md`.

### Portal Timeline

**Profile:** `mcrt.portal.timeline`. **Proposed columns:** `CLOCK`, `STATE`, `EVID`.

The canonical grammar references undefined event/key/marker/branch/checkpoint/sync/transition/playback productions; modeled receipts do not establish a distributed clock or causal consensus implementation.

Rational timebases, stable event ordering, synchronization, checkpoints and replay identities. Timeline source remains distinct from MCRT receipt data.

**Upgrade status:** mitigated by explicit evidence qualification. Current records are qualified as modeled expectations; source hash and lexical requirement consistency recorded.

**Source locations:** `JA21_MPTL_Suite_1.0.0/specifications/CANONICAL_GRAMMAR.ebnf`, `JA21_MPTL_Suite_1.0.0/specifications/CANONICAL_RUNTIME_CONTRACT.json`.

## JA arithmetic foundation

The attached **8S Penteract–S³ Master Coupled Mechanics Law** is the author's foundational arithmetic and mechanics reference for JA. Its structure includes a five-coordinate center, an S³ fiber, pairwise and triadic coupling, phase/activation/support/radius relationships, projections, separate geometric and judgment gaps, and the independence-plus-efficacy admission gate. The image and its law are preserved alongside the corpus `_coupling_mechanics` and document coupling profiles.

The JATP arithmetic review concerns the particular `Count` fixtures, quantified ranges and multiplication examples supplied in that corpus. The independent checks used nonnegative integer multiplication as a stated interpretation for those examples. JA operator overloads, Count semantics, units, numerical domains and evaluation rules still require a real versioned language compiler. The 8S expressions and their intended algebraic meaning remain part of the foundation; a correction to a fixture test does not establish a replacement arithmetic model for JA.

The updated source preserves the original fixed fixture expectation in a separate `unit test` and retains the actual quantified nondecrease invariant. The supplied grammar supports the unit declaration. Native profile parsing and type/operator validation remain necessary before execution admission. The independent fixture oracle rejects an incorrect multiplier under the stated Count interpretation.

## Evidence admission and implementation priorities

A source header and version identify a profile before parsing. Each frontend should emit one common typed intermediate record containing source location, module/profile identity, operation, inputs/outputs, effects, required authority, clock/resource envelope, dependencies and evidence state. A columned authoring form may arrange those fields for review; it must preserve their meaning during lowering. Columned syntax and columnar data storage are separate concerns.

Guest builds should use an explicit unikernel target manifest: entrypoint, dependency closure, permitted ABI, memory/resource limits, approved device/network adapters and measured image identity. JA Operations supplies deployment-contract concepts; it supplies no guest boot implementation. Interface, Experience and scene materialization should resolve through declared external adapters so the guest closure stays reviewable.

Federation should exchange typed messages and artifacts across named realms. JA Security supplies the authority contract; Service supplies protocols, deadlines and idempotency; Agent supplies bounded work plans; Data supplies lineage and rights. Native admission must check delegation attenuation, revocation/expiry state, transport authority, resource budgets and causal receipts. These contracts do not establish an implemented federation runtime.

Verification should distinguish modeled expectations, structural validation, native execution, replay and certification. A failing earlier stage must prevent fabricated later evidence. Source/template feature labels require parser coverage before they can become implementation claims. Stable source/hash links and historical identities should remain visible when an upgrade requires revalidation.

The first executable slice should be small: a versioned module, a typed pure transformation, an explicit authority request, a bounded local plan, and a qualified receipt. Native guest boot, device I/O, multi-realm scheduling, cryptographic signing, full JA parsers, layout/rendering and generalized proofs belong to separately tested milestones.
