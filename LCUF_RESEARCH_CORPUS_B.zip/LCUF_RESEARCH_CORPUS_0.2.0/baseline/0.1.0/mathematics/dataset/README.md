# Reference mathematics dataset

The main [cases.jsonl](cases.jsonl) contains **1,619** unique operation/input pairs over **19** families and **66** family/template combinations. [FAMILY_COVERAGE.csv](FAMILY_COVERAGE.csv) records exact family counts; [manifest.json](manifest.json) records input uniqueness, duplicate elimination, tool/source/data hashes and the host environment. Repeated parameter grids are explicit. Their rows are not independent theories, empirical samples or distinct language programs.

Every row separates these fields:

| Field | Meaning |
|---|---|
| input | Authored operation keyword inputs; nonfinite probes use explicit tagged JSON objects |
| oracle | Independent analytical/domain/policy certificate definition |
| expected_frozen | Expected value or controlled rejection, reconstructed without reference execution |
| frozen_observation | Actual frozen helper outcome on the recorded host |
| expected_research | Expected outcome under separately declared research policy |
| research_observation | Actual wrapper outcome on that host |
| mathematical_premise_status | Authored domain, intentional denial, roundoff allowance or invalid-projector counterexample |
| research_qualification | Accepted conditional host policy or denied |
| input_sha256 | SHA256 of canonical operation plus input, excluding labels/observations |
| source_sha256 | Exact frozen reference.py byte identity |
| record_sha256 | SHA256 of every record field except this digest |

The main values are **1,446 frozen successes and173 frozen denials**, compared with **1,442 research-accepted values and177 research denials**. The four additional denials are the frozen helper's excessive-tolerance projector counterexamples. Three tiny-negative metric cases are explicitly roundoff-qualified; accepting those observations does not claim exact PSD authority.

## Analytical oracle methods

- Exact `Fraction` arithmetic checks lattice coordinates, projector residuals, quadratic forms, activation/support products, boundary products, linear embeddings/projections and binary-exact gates.
- Coordinate-supported C4 columns have independently known diagonal projectors and ranks; no Gram–Schmidt result is used as its own expected answer.
- Quarter-period and quarter-turn identities provide exact mathematical sinusoidal expectations, compared against host sine with declared numerical tolerance.
- Perfect rational support cubes give independently specified cube roots for radius cases.
-80-digit `Decimal` exponential/logistic calculations provide independent numerical expectations for sigmoid and pair weights.
- Domain certificates explicitly witness invalid scalar types, nonfinite inputs, dimensions, L1/cube violations, negative directions, nonsymmetry, nonidempotence, duplicate/index errors and typed-record authority conflicts.
- Tolerance counterexamples are deliberately separated from valid orthogonal-projector premises. Their raw arithmetic is analytical, but their frozen acceptance is a documented policy limitation.

[oracles.py](../tools/oracles.py) never imports or calls the frozen helper or wrapper. Analytical expectations remain separate from observations even when they numerically agree. Rational reductions provide exact values for the authored finite rational cases; Decimal/transcendental and matrix-tolerance checks remain numerical evidence with declared limits.

## Canonicalization and strict JSON

Canonical hashes use UTF8, sorted object keys, compact separators and finite JSON values. Array order is retained. Each JSONL line has one complete case. Bare JSON NaN/Infinity and duplicate keys are rejected. Adversarial nonfinite values are encoded as `{"$nonfinite":"NaN"}`, `+Infinity` or `-Infinity`, then decoded only for invoking the function under test. These tags are test harness inputs, not legitimate native arithmetic values.

The [Draft202012 schema](cases.schema.json) checks the closed record envelope. An input can deliberately violate an operation's domain, because denials belong in the corpus. The portable validator adds hashes, independent oracle reconstruction, premise qualification, exact authority flags, sequence/uniqueness, bounded comparison policy and host replay. Optional JSON Schema execution checks every row using a real Draft202012 engine; it does not turn the numerical observations into theorem proofs.

## Independent NumPy differential layer

[numpy_differential.jsonl](numpy_differential.jsonl) is a separately counted500-case layer:200 random PSD geometries,200 C4 projectors and100 linear projections. [NUMPY_DIFFERENTIAL.json](NUMPY_DIFFERENTIAL.json) records NumPy2.3.5, CPython3.12.14, seed82108, PCG64, pseudoinverse rcond1e−12, comparison tolerances2e−10 and measured maximum errors. Each row preserves actual input bytes, the independently computed NumPy expectation, the research host observation and their hashes.

These comparisons use ordinary well-scaled random matrices and vectors; they do not establish behavior for every ill-conditioned case. NumPy's SVD cutoff and the frozen absolute Gram–Schmidt cutoff differ. Rebuilding random inputs under a different dependency version can change them; stored input bytes and the recorded version are the reproducibility baseline. Default stdlib validation checks snapshot integrity and stored numerical agreement without claiming a fresh NumPy execution. Running the optional differential tool actually recomputes the500 comparisons.

No row records a native image, federated transport, fitted Score experiment, physical observation or global-topology proof.
