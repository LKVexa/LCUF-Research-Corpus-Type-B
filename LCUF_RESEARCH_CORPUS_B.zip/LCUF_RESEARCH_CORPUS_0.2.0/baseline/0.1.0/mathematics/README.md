# JA/LCUF mathematics research corpus 0.1.0

This volume preserves JA's declared **8S Penteract–S³ Master Coupled Mechanics Law** and delivers detailed mathematical analysis, a frozen arithmetic reference, a separately versioned host research policy and reproducible analytical/differential datasets. The proposed typed LCUF adapter remains a draft.

Read [the mathematics volume](MATHEMATICS_VOLUME.md), [the adapter contract](ADAPTER_CONTRACT_DRAFT.md), [known limits](KNOWN_LIMITS.md) and [dataset documentation](dataset/README.md). The supplied [figure](frozen/coupling8s/ARITHMETIC_REFERENCE.png), implementation, schema, examples and original tests are all byte-exact copies bound by [provenance](PROVENANCE.json).

The main dataset has **1,619** unique operation/input pairs over **19** families and **66** family/template combinations. It distinguishes 1,446 frozen value observations from 1,442 values accepted under research policy, with 173 and 177 controlled denials respectively. A separate 500-case NumPy differential layer records independent numerical comparisons. The datasets contain host arithmetic observations and explicit analytical/policy expectations; they contain no native, federation, empirical Score or physical-theorem evidence.

The new research wrapper rejects numerical tolerance above 1e−6 and checks finite/domain/shape/gate outputs. The ceiling is explicit engineering policy, not an equation in the author's law. Tiny negative metric values remain qualified roundoff behavior. No frozen reference patch or LCUF core operation change was made.

From this mathematics folder, use Python 3.10+ for the stdlib tools:

```text
python -B tools/validate.py
python -B -m unittest discover -s tests -v
python -B -m unittest discover -s frozen/coupling8s/tests -v
```

To independently regenerate the main authored cases and host observations:

```text
python -B tools/build_dataset.py
python -B tools/validate.py --write-report
```

The optional dependencies are locked in [requirements-optional.txt](requirements-optional.txt); the recorded run used Python 3.12.14, NumPy 2.3.5 and jsonschema 4.25.1. With compatible installed dependencies:

```text
python -B tools/validate.py --json-schema
python -B tools/numpy_differential.py
```

Regeneration writes fresh host observations in this subtree. Preserve the delivered manifest and observation bytes before using a different environment. Exact digest identity is an integrity comparison against a trusted copy; it is not a signature or execution attestation.

Current results are in [VALIDATION.json](dataset/VALIDATION.json), [test receipts](dataset/TEST_RESULTS.json) and [NumPy differential receipts](dataset/NUMPY_DIFFERENTIAL.json). External numerical-method support is narrowly attributed in [SOURCES.md](SOURCES.md). All original sources retain their source ownership/licensing; these additions do not relicense the copied figure or profile.
