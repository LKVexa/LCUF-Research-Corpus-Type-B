# Mathematical and numerical sources

The author-supplied figure is the declared JA arithmetic foundation. Its [PNG](frozen/coupling8s/ARITHMETIC_REFERENCE.png) and [AVIF](frozen/coupling8s/ARITHMETIC_REFERENCE.avif), previously delivered profile/reference/schema/example/tests and validation report are copied exactly; file digests and original collection-relative locations are in [PROVENANCE.json](PROVENANCE.json).

External primary sources were checked on2026-10-09 for the narrow numerical-method statements below. They do not endorse the author's model or supply missing physical/empirical evidence.

| Source | Supported use in this volume |
|---|---|
| [R. Penrose, A generalized inverse for matrices,1955, DOI10.1017/S0305004100030401](https://www.cambridge.org/core/services/aop-cambridge-core/content/view/S0305004100030401) | Algebraic definition/existence of the generalized inverse through its four identities |
| [NumPy2.3 `linalg.pinv`](https://numpy.org/doc/2.3/reference/generated/numpy.linalg.pinv.html) | SVD pseudoinverse and relative singular-value cutoff; the differential run explicitly uses rcond1e−12 |
| [NumPy2.3 Generator](https://numpy.org/doc/2.3/reference/random/generator.html) | default_rng/PCG64 and absence of a cross-version stream guarantee; actual run NumPy2.3.5, seed82108 |
| [Python3.12 Decimal](https://docs.python.org/3.12/library/decimal.html) | Decimal exponential/precision behavior used by independent80-digit oracles |

Conditional deductions about eta bounds, support, projection, local dimension and a sufficient activation sensitivity bound are derived in the volume under their stated assumptions. They are not presented as empirical findings or unqualified global theorems about the author's full framework.
