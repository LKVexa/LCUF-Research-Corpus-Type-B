"""Independent analytical oracles: exact rationals, Decimal and closed-form cases.

This module never imports or invokes the frozen reference or research wrapper.
It deliberately supports authored analytical families, not arbitrary model solving.
"""
from __future__ import annotations
from decimal import Decimal, localcontext
from fractions import Fraction as F
import math


def frac(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError("analytical oracle requires finite real scalars")
    return F(value)


def dec(value):
    f = frac(value)
    return Decimal(f.numerator) / Decimal(f.denominator)


def sqrt_exact(value):
    with localcontext() as context:
        context.prec = 80
        return float((Decimal(value.numerator) / Decimal(value.denominator)).sqrt())


def squared_geometry(inputs):
    # Rational quadratic form independently evaluates authored diagonal/rank-one PSD cases.
    d = [frac(x)-frac(y) for x,y in zip(inputs['c_i'],inputs['c_j'])]
    return sum((d[i]*frac(inputs['G5'][i][j])*d[j] for i in range(5) for j in range(5)), F(0))


def certify_authored_psd(g):
    """Exact certificate for the authored diagonal/rank-one metric families."""
    assert len(g)==5 and all(len(row)==5 for row in g)
    q=[[frac(x) for x in row] for row in g]
    assert all(q[i][j]==q[j][i] for i in range(5) for j in range(5))
    if all(q[i][j]==0 for i in range(5) for j in range(5) if i!=j):
        assert all(q[i][i]>=0 for i in range(5));return
    pivot=next(i for i in range(5) if q[i][i]>0)
    assert all(q[i][j]*q[pivot][pivot]==q[i][pivot]*q[pivot][j] for i in range(5) for j in range(5))
    # Then q=vv^T/q_pp with positive q_pp, a direct rank-one PSD certificate.


def certify_exact_projector(p):
    assert p and all(len(row)==len(p) for row in p)
    q=[[frac(x) for x in row] for row in p]
    assert all(q[i][j]==q[j][i] for i in range(len(p)) for j in range(len(p)))
    assert all(sum((q[i][k]*q[k][j] for k in range(len(p))),F(0))==q[i][j] for i in range(len(p)) for j in range(len(p)))


def admitted(eta, threshold, score8, score7, gain):
    # Authored cases use binary-exact differences, preventing oracle rounding ambiguity.
    delta = frac(score8)-frac(score7)
    left, right = frac(eta)>=frac(threshold), delta>frac(gain)
    return {'eta_ind':float(eta),'Delta8S':float(delta),'independence_pass':left,
        'efficacy_pass':right,'admitted_model_dimension':left and right,'authority':'numeric_model_gate_only'}


def independent_expected(operation, inputs, descriptor):
    kind=descriptor['kind']
    if kind == 'domain_rejection':
        certify_denial(inputs, descriptor)
        return {'status':'reject','error_class':'ModelError'}
    if kind == 'policy_counterexample':
        # Explicit counterexamples specify raw frozen behavior and research denial separately.
        if operation=='independence_score':
            assert inputs['e']==[1] and inputs['projector']==[[4]] and inputs['denominator_epsilon']==1
            assert inputs['tolerance']>1e-6
            return {'status':'value','value':4.5}
        raise ValueError('unsupported counterexample')
    value=None
    if operation=='sigmoid':
        assert kind=='decimal_logistic'
        with localcontext() as context:
            context.prec=80
            h=dec(inputs['h']);value=float(Decimal(1)/(Decimal(1)+(-h).exp()))
    elif operation=='q':
        assert kind=='quarter_period'
        n=frac(inputs['tau'])/frac(inputs['T'])*4
        assert n.denominator==1
        value=[0,.5,1,.5][n.numerator%4]
    elif operation=='lattice_center':
        assert kind=='rational_lattice'
        assert len(inputs['indices'])==5 and sum(abs(n) for n in inputs['indices'])<=inputs['M']
        value=[float(frac(inputs['ell'])*n) for n in inputs['indices']]
        assert all(abs(x)<=1 for x in value)
    elif operation=='projector_from_c4':
        assert kind=='coordinate_column_space'
        c4=inputs['C4']; tol=inputs.get('tolerance',1e-9)
        active=set()
        for j in range(4):
            column=[(i,frac(row[j])) for i,row in enumerate(c4) if row[j]!=0]
            assert len(column)<=1  # Coordinate-supported columns have a known projector.
            if column and abs(float(column[0][1]))>tol: active.add(column[0][0])
        value={'projector':[[int(i==j and i in active) for j in range(len(c4))] for i in range(len(c4))],
            'numerical_rank':len(active),'algorithm':'two_pass_modified_Gram_Schmidt_absolute_tolerance'}
    elif operation=='independence_score':
        assert kind=='rational_projector_residual'
        e=[frac(x) for x in inputs['e']];p=inputs['projector'];certify_exact_projector(p)
        residual=[e[i]-sum((frac(p[i][j])*e[j] for j in range(len(e))),F(0)) for i in range(len(e))]
        numerator=sum((x*x for x in residual),F(0));denominator=sum((x*x for x in e),F(0))+frac(inputs['denominator_epsilon'])
        value=float(numerator/denominator)
    elif operation=='quadratic_geometry':
        assert kind in {'rational_psd_quadratic','declared_roundoff_clamp'}
        exact=squared_geometry(inputs)
        if kind=='declared_roundoff_clamp':
            assert exact<0 and abs(float(exact))<=inputs.get('tolerance',1e-9)
            value=0.0
        else:
            certify_authored_psd(inputs['G5'])
            assert exact>=0
            value=float(exact)
    elif operation=='pair_weight':
        assert kind=='decimal_exponential_weight'
        certify_authored_psd(inputs['G5'])
        with localcontext() as context:
            context.prec=80
            geometry=squared_geometry(inputs)
            exponent=-dec(float(geometry))/(2*dec(inputs['sigma_c'])**2)-dec(inputs['judgment_distance'])**2/(2*dec(inputs['sigma_J'])**2)
            value=float(dec(inputs['A_ij'])*exponent.exp())
    elif operation=='phase_derivative':
        assert kind=='quarter_turn_sparse_phase'
        quarters=descriptor['quarter_counts']; assert inputs['theta']==[x*math.pi/2 for x in quarters]
        i=inputs['index']; sine=lambda k:F([0,1,0,-1][k%4])
        pair=sum((frac(w)*sine(quarters[j]-quarters[i]) for j,w in inputs['pair_terms']),F(0))
        triad=sum((frac(h)*sine(quarters[j]+quarters[k]-2*quarters[i]) for j,k,h in inputs['triad_terms']),F(0))
        value=float(frac(inputs['omega_i'])+frac(inputs['K2'])*pair+frac(inputs['K3'])*triad)
    elif operation=='activation_field':
        assert kind=='rational_activation'
        f=lambda k:frac(inputs[k]);p=[frac(x) for x in inputs['probabilities']]
        pair=sum((frac(w)*(2*p[j]-1) for j,w in inputs['pair_terms']),F(0))
        triad=sum((frac(h)*(2*p[j]-1)*(2*p[k]-1) for j,k,h in inputs['triad_terms']),F(0))
        value=float(f('beta')*(f('M')*f('q_value')+F(1,2)-f('d_i'))+f('a_E')*f('E_i')+f('a_u')*f('u_feature_i')-f('a_chi')*f('chi_i')-f('a_zeta')*f('zeta_i')+f('J2')*pair+f('J3')*triad)
    elif operation=='effective_support':
        assert kind=='rational_support'
        value=float(frac(inputs['p_i'])*frac(inputs['kappa_i'])*(1-frac(inputs['chi_i']))*(1-frac(inputs['zeta_i']))*frac(inputs['velocity_factor']))
    elif operation=='boundary_product':
        assert kind=='five_factor_rational_product';assert len(inputs['weights_4_to_8'])==5
        result=F(1)
        for x in inputs['weights_4_to_8']:result*=frac(x)
        value=float(result)
    elif operation=='radius':
        assert kind=='perfect_cube_radius'
        root=frac(descriptor['support_cube_root']);assert root**3==frac(inputs['support'])
        assert type(inputs['alpha']) is int and inputs['alpha']>0
        value=float(frac(inputs['r_max'])*frac(inputs['boundary_value'])**inputs['alpha']*root)
    elif operation in {'fiber_point','projected_point'}:
        assert kind=='cardinal_fiber_linear_projection';u=inputs['u']
        assert sum(x*x for x in u)==1 and sum(x!=0 for x in u)==1
        c=[frac(x) for x in inputs['c_i']];fiber=[frac(inputs['r_i'])*frac(x) for x in u]
        if operation=='fiber_point':value=[float(x) for x in c+fiber]
        else:value=[float(sum((frac(inputs['Pi5'][i][j])*c[j] for j in range(5)),F(0))+sum((frac(inputs['Psi4'][i][j])*fiber[j] for j in range(4)),F(0))) for i in range(3)]
    elif operation=='geometry_gaps':
        assert kind=='rational_pythagorean_gaps'
        certify_authored_psd(inputs['G5'])
        squared=squared_geometry(inputs);delta=squared+(frac(inputs['r_i'])-frac(inputs['r_j']))**2
        d=[frac(x)-frac(y) for x,y in zip(inputs['c_i'],inputs['c_j'])]
        projected=[sum((frac(row[j])*d[j] for j in range(5)),F(0)) for row in inputs['Pi5']]
        proj_squared=sum((x*x for x in projected),F(0))
        value={'g5':sqrt_exact(squared)-inputs['lambda_i']-inputs['lambda_j'],
            'delta8':sqrt_exact(delta),'g3':sqrt_exact(proj_squared)-inputs['apparent_r_i']-inputs['apparent_r_j'],
            'gJ':float(frac(inputs['judgment_distance'])-frac(inputs['judgment_threshold'])),
            'classification':None,'classification_status':'requires_explicit_versioned_Classify_policy'}
    elif operation=='admit':
        assert kind=='exact_binary_gate'
        value=admitted(inputs['eta_ind'],inputs['epsilon_ind'],inputs['score_M8'],inputs['score_M7'],inputs['epsilon_gain'])
    elif operation=='local_noncollapsed_dimension':
        assert kind=='conditional_regular_chart';value=8 if inputs['r_i']>0 else None
    elif operation=='evaluate_admission_record':
        assert kind=='typed_coordinate_projector_gate'
        r=inputs['record'];ind=r['independence'];eff=r['efficacy']
        if 'C4' in ind:
            p=independent_expected('projector_from_c4',{'C4':ind['C4'],'tolerance':r['numerical_tolerance']},{'kind':'coordinate_column_space'})['value']['projector']
            assert p==ind['projector']
        eta=independent_expected('independence_score',{'e':ind['e'],'projector':ind['projector'],'denominator_epsilon':ind['denominator_epsilon']},{'kind':'rational_projector_residual'})['value']
        value={'profile':'ja.coupling8s','reference_version':'coupling8s.reference.0.1','execution_scope':'host_numeric_reference',
            'native_runtime_executed':False,'physical_theorem_claimed':False,
            'gate':admitted(eta,r['epsilon_ind'],eff['score_M8'],eff['score_M7'],eff['epsilon_gain']),
            'projector_authority':'numerically_checked_C4_column_space_with_declared_tolerance' if 'C4' in ind else 'caller_declared_C4_column_space; symmetry_and_idempotence_checked'}
    else:raise ValueError('no independent authored oracle for '+operation)
    return {'status':'value','value':value}


def path_value(inputs,path):
    value=inputs
    for k in path:value=value[k]
    return value


def certify_denial(inputs, descriptor):
    """Certify each authored domain counterexample without executing the reference."""
    v=descriptor['violation'];x=path_value(inputs,descriptor.get('path',[]))
    if v=='numeric_type': assert isinstance(x,bool) or not isinstance(x,(int,float))
    elif v=='nonfinite':assert isinstance(x,float) and not math.isfinite(x)
    elif v=='negative':assert frac(x)<0
    elif v=='nonpositive':assert frac(x)<=0
    elif v=='unit_interval':assert frac(x)<0 or frac(x)>1
    elif v=='length':assert not isinstance(x,(list,tuple)) or len(x)!=descriptor['required_length']
    elif v=='integer_type':assert isinstance(x,bool) or not isinstance(x,int)
    elif v=='lattice_l1':assert sum(abs(n) for n in inputs['indices'])>inputs['M']
    elif v=='lattice_cube':assert max(abs(inputs['ell']*n) for n in inputs['indices'])>1
    elif v=='nonsymmetric':assert any(abs(x[i][j]-x[j][i])>inputs.get('tolerance',1e-9) for i in range(len(x)) for j in range(len(x)))
    elif v=='negative_diagonal':assert any(row[i]<-inputs.get('tolerance',1e-9) for i,row in enumerate(x))
    elif v=='nonidempotent':assert any(abs(sum(x[i][k]*x[k][j] for k in range(len(x)))-x[i][j])>inputs.get('tolerance',1e-9) for i in range(len(x)) for j in range(len(x)))
    elif v=='duplicate_pair':assert len({t[0] for t in x})<len(x)
    elif v=='duplicate_triad':assert len({(t[0],t[1]) for t in x})<len(x)
    elif v=='index_range':assert isinstance(x,bool) or not isinstance(x,int) or not 0<=x<descriptor['size']
    elif v=='nonunit_fiber':assert abs(sum(z*z for z in x)-1)>inputs.get('tolerance',1e-9)
    elif v=='wrong_identity':assert x!=descriptor['required_value']
    elif v=='unknown_record_field':assert descriptor['field'] in inputs['record']
    elif v=='projector_c4_conflict':
        r=inputs['record']['independence'];assert r['C4']==[[1,0,0,0],[0,0,0,0]] and r['projector']==[[0,0],[0,0]]
    elif v=='host_range':assert abs(dec(x))>Decimal('1e308')
    else:raise ValueError('unsupported denial certificate '+v)
