"""Versioned host research policy around an unchanged JA arithmetic reference.

The tolerance ceiling is engineering policy, not an equation in the supplied law.
This wrapper does not implement an LCUF frontend, native image or transport.
"""
from __future__ import annotations
import importlib.util
import inspect
import math
from pathlib import Path
import sys
sys.dont_write_bytecode = True

VERSION = "lcuf.math.research-policy.0.1"
MAX_NUMERICAL_TOLERANCE = 1e-6
DEFAULT_NUMERICAL_TOLERANCE = 1e-9
ROOT = Path(__file__).resolve().parents[1]
REFERENCE_PATH = ROOT / "frozen/coupling8s/reference.py"
spec = importlib.util.spec_from_file_location("lcuf_frozen_coupling8s", REFERENCE_PATH)
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)

OPERATIONS = frozenset({"sigmoid", "q", "lattice_center", "projector_from_c4",
    "independence_score", "quadratic_geometry", "pair_weight", "phase_derivative",
    "activation_field", "effective_support", "boundary_product", "radius",
    "fiber_point", "projected_point", "geometry_gaps", "admit",
    "local_noncollapsed_dimension", "evaluate_admission_record"})


class PolicyError(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def finite_tree(value):
    if isinstance(value, float) and not math.isfinite(value):
        raise PolicyError("nonfinite", "all numeric input/output values must be finite")
    if isinstance(value, (list, tuple)):
        for x in value: finite_tree(x)
    elif isinstance(value, dict):
        for x in value.values(): finite_tree(x)


def real(value, label, low=None, high=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise PolicyError("output_type", label + " must be real")
    try: x = float(value)
    except (OverflowError, ValueError) as e: raise PolicyError("numeric_range", label) from e
    if not math.isfinite(x) or (low is not None and x < low) or (high is not None and x > high):
        raise PolicyError("output_domain", label + " is outside its declared domain")
    return x


def tolerance(value):
    x = real(value, "numerical tolerance")
    if not 0 < x <= MAX_NUMERICAL_TOLERANCE:
        raise PolicyError("tolerance_policy", "research tolerance must satisfy 0 < tol <= 1e-6")
    return x


def validate_output(operation, value, inputs, tol=DEFAULT_NUMERICAL_TOLERANCE):
    """Public output checks; useful for testing backend corruption explicitly."""
    finite_tree(value)
    if operation in {"sigmoid", "q", "independence_score"}: real(value, operation, 0, 1)
    elif operation in {"quadratic_geometry", "effective_support", "boundary_product", "radius"}:
        real(value, operation, 0)
    elif operation == "pair_weight":
        real(value, operation, 0, float(inputs["A_ij"]) + tol)
    elif operation in {"phase_derivative", "activation_field"}: real(value, operation)
    elif operation in {"lattice_center", "fiber_point", "projected_point"}:
        length = {"lattice_center": 5, "fiber_point": 9, "projected_point": 3}[operation]
        if not isinstance(value, list) or len(value) != length: raise PolicyError("output_shape", operation)
        for item in value: real(item, operation)
        if operation in {"lattice_center", "fiber_point"}:
            for item in value[:5]: real(item, "center coordinate", -1, 1)
    elif operation == "projector_from_c4":
        if not isinstance(value, dict) or set(value) != {"projector", "numerical_rank", "algorithm"}:
            raise PolicyError("output_shape", "projector result")
        n = len(inputs["C4"])
        rank = value["numerical_rank"]
        if isinstance(rank, bool) or not isinstance(rank, int) or not 0 <= rank <= min(n, 4):
            raise PolicyError("output_rank", "invalid numerical rank")
        reference.verify_projector(value["projector"], n, tol)
    elif operation == "geometry_gaps":
        if not isinstance(value, dict) or set(value) != {"g5", "delta8", "g3", "gJ", "classification", "classification_status"}:
            raise PolicyError("output_shape", "geometry gap result")
        for name in ("g5", "g3", "gJ"): real(value[name], name)
        real(value["delta8"], "delta8", 0)
        if value["classification"] is not None or value["classification_status"] != "requires_explicit_versioned_Classify_policy":
            raise PolicyError("classification_authority", "Classify remains undefined")
    elif operation in {"admit", "evaluate_admission_record"}:
        gate = value if operation == "admit" else value.get("gate", {})
        if not isinstance(gate, dict) or set(gate) != {"eta_ind", "Delta8S", "independence_pass", "efficacy_pass", "admitted_model_dimension", "authority"}:
            raise PolicyError("output_shape", "admission gate")
        eta = real(gate["eta_ind"], "eta_ind", 0, 1)
        delta = real(gate["Delta8S"], "Delta8S")
        record = inputs.get("record")
        threshold = inputs["epsilon_ind"] if record is None else record["epsilon_ind"]
        gain = inputs["epsilon_gain"] if record is None else record["efficacy"]["epsilon_gain"]
        expected = (eta >= threshold, delta > gain)
        fields = ("independence_pass", "efficacy_pass", "admitted_model_dimension")
        if any(type(gate[k]) is not bool for k in fields) or tuple(gate[k] for k in fields) != (*expected, all(expected)):
            raise PolicyError("gate_consistency", "reported gate differs from the supplied inequalities")
        if gate["authority"] != "numeric_model_gate_only": raise PolicyError("gate_authority", "invalid authority")
        if record is not None:
            if value.get("execution_scope") != "host_numeric_reference" or value.get("native_runtime_executed") is not False or value.get("physical_theorem_claimed") is not False:
                raise PolicyError("scope", "host-only evidence is required")
    elif operation == "local_noncollapsed_dimension":
        if value is not None and (type(value) is not int or value != 8): raise PolicyError("dimension", "conditional local dimension only")
    else: raise PolicyError("unknown_operation", operation)
    return value


def evaluate(operation, inputs):
    if operation not in OPERATIONS or not isinstance(inputs, dict):
        raise PolicyError("input_shape", "known operation and keyword input object required")
    finite_tree(inputs)
    function = getattr(reference, operation)
    try: bound = inspect.signature(function).bind(**inputs)
    except TypeError as error: raise PolicyError("input_signature", str(error)) from error
    bound.apply_defaults()
    tol = tolerance(bound.arguments.get("tolerance", DEFAULT_NUMERICAL_TOLERANCE))
    if operation == "evaluate_admission_record":
        record = inputs.get("record")
        if not isinstance(record, dict): raise PolicyError("input_shape", "record must be an object")
        tol = tolerance(record.get("numerical_tolerance"))
    result = function(**inputs)
    return validate_output(operation, result, inputs, tol)
