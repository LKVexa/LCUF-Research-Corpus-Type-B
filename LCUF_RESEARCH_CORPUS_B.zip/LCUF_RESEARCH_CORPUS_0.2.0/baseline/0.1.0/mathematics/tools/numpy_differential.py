"""Optional, reproducible independent numerical comparisons; requires NumPy2.3.5.

Random cases are well-scaled differential checks, not analytical proofs or empirical
model evaluation. Their expectations come from NumPy, never the frozen reference.
"""
import hashlib
import json
import platform
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import numpy as np
from build_dataset import canonical,digest,file_digest
from research_wrapper import ROOT, reference, evaluate

SEED=82108
ABS=2e-10
REL=2e-10


def run(write=True):
    rng=np.random.default_rng(SEED);records=[];maximums={}
    source=file_digest(ROOT/'frozen/coupling8s/reference.py')
    for kind,count in [('PSD_geometry',200),('C4_projector',200),('linear_projection',100)]:
        errors=[]
        for number in range(count):
            if kind=='PSD_geometry':
                a=rng.normal(size=(5,5));g=a.T@a;ci=rng.uniform(-1,1,5);cj=rng.uniform(-1,1,5);d=ci-cj
                inputs={'c_i':ci.tolist(),'c_j':cj.tolist(),'G5':g.tolist()};op='quadratic_geometry'
                expected=float(d@g@d)
                actual=evaluate(op,inputs);difference=abs(actual-expected);ok=bool(np.isclose(actual,expected,atol=ABS,rtol=REL))
            elif kind=='C4_projector':
                c4=rng.normal(size=(8,4))
                if number%4==0:c4[:,3]=2*c4[:,0] # Deliberate exact dependence, numerical backend treatment.
                inputs={'C4':c4.tolist()};op='projector_from_c4'
                p=c4@np.linalg.pinv(c4,rcond=1e-12);expected=p.tolist()
                actual=evaluate(op,inputs)['projector'];difference=float(np.max(np.abs(np.array(actual)-p)));ok=bool(np.allclose(actual,p,atol=ABS,rtol=REL))
            else:
                ci=rng.uniform(-1,1,5);u=rng.normal(size=4);u=u/np.linalg.norm(u);r=float(rng.uniform(.01,4));pi=rng.normal(size=(3,5));psi=rng.normal(size=(3,4))
                inputs={'c_i':ci.tolist(),'r_i':r,'u':u.tolist(),'Pi5':pi.tolist(),'Psi4':psi.tolist()};op='projected_point'
                expected=(pi@ci+psi@(r*u)).tolist();actual=evaluate(op,inputs)
                difference=float(np.max(np.abs(np.array(actual)-np.array(expected))));ok=bool(np.allclose(actual,expected,atol=ABS,rtol=REL))
            if not ok:raise AssertionError(kind+' differential mismatch '+str(number))
            errors.append(difference)
            record={'id':f'NUMPY-{len(records)+1:06d}','family':kind,'operation':op,'input':inputs,'input_sha256':digest({'operation':op,'input':inputs}),
                'source_sha256':source,'independent_numpy_expected':expected,'observed_research_host':actual,'max_absolute_difference':difference,
                'absolute_tolerance':ABS,'relative_tolerance':REL,'execution_scope':'host_numeric_differential','native_execution':False,'physical_theorem_claim':False}
            record['record_sha256']=digest(record);records.append(record)
        maximums[kind]=max(errors)
    data=b''.join(canonical(record)+b'\n' for record in records)
    report={'status':'PASS','checks':len(records),'family_counts':{'PSD_geometry':200,'C4_projector':200,'linear_projection':100},
        'seed':SEED,'numpy_version':np.__version__,'python':platform.python_version(),'platform':platform.platform(),
        'generator':'numpy.default_rng(PCG64)','pinv_rcond':1e-12,'frozen_rank_absolute_tolerance':1e-9,
        'absolute_comparison_tolerance':ABS,'relative_comparison_tolerance':REL,'maximum_absolute_differences':maximums,
        'dataset_sha256':hashlib.sha256(data).hexdigest(),'reference_sha256':source,
        'scope':'Well-scaled random host numerical differential checks only; no exact rank, conditioning, global-topology, empirical Score, native/federation or physical-theorem proof'}
    if write:
        (ROOT/'dataset/numpy_differential.jsonl').write_bytes(data)
        (ROOT/'dataset/NUMPY_DIFFERENTIAL.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report


if __name__=='__main__':print(json.dumps(run(),indent=2))
