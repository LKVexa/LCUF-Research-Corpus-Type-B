"""Build deterministic authored math cases and separately record host observations."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import copy
import csv
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
sys.dont_write_bytecode = True
from oracles import independent_expected
from research_wrapper import ROOT, reference, evaluate, VERSION as POLICY_VERSION

CASE_VERSION="lcuf.math.case.0.1"


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def digest(value):return hashlib.sha256(canonical(value)).hexdigest()
def file_digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def decode(value):
    if isinstance(value,dict) and set(value)=={'$nonfinite'}:
        return {'NaN':math.nan,'+Infinity':math.inf,'-Infinity':-math.inf}[value['$nonfinite']]
    if isinstance(value,dict):return {k:decode(v) for k,v in value.items()}
    if isinstance(value,list):return [decode(v) for v in value]
    return value


def observe(operation,inputs,research=False):
    try:
        value=evaluate(operation,decode(inputs)) if research else getattr(reference,operation)(**decode(inputs))
        canonical(value) # A successful observation cannot contain nonfinite output.
        return {'status':'value','value':value,'execution_scope':'host_numeric_reference'}
    except Exception as error:
        obj={'status':'reject' if type(error).__name__ in {'ModelError','PolicyError'} else 'unexpected_exception',
             'error_class':type(error).__name__,'error_message':str(error),'execution_scope':'host_numeric_reference'}
        if hasattr(error,'code'):obj['policy_code']=error.code
        return obj


def eye(n):return [[int(i==j) for j in range(n)] for i in range(n)]
def diag5(values):return [[values[i] if i==j else 0 for j in range(5)] for i in range(5)]
ZERO=[0]*5
PI=[[int(i==j) for j in range(5)] for i in range(3)]
PSI=[[int(i==j) for j in range(4)] for i in range(3)]


def authored_cases():
    cases=[];seen=set();duplicates=0
    def add(family,template,op,inputs,kind,**details):
        nonlocal duplicates
        key=digest({'operation':op,'input':inputs})
        if key in seen:duplicates+=1;return
        seen.add(key)
        oracle={'kind':kind,**details}
        expected=independent_expected(op,decode(inputs),oracle)
        research_expected=copy.deepcopy(expected)
        if expected['status']=='reject':research_expected={'status':'reject','allowed_error_classes':['ModelError','PolicyError']}
        if kind=='policy_counterexample':research_expected={'status':'reject','allowed_error_classes':['PolicyError'],'policy_code':'tolerance_policy'}
        cases.append({'schema_version':CASE_VERSION,'id':f'MATH-{len(cases)+1:06d}',
            'family':family,'template':template,'operation':op,'input':copy.deepcopy(inputs),'input_sha256':key,
            'oracle':oracle,'expected_frozen':expected,'expected_research':research_expected,
            'comparison':{'absolute_tolerance':2e-12,'relative_tolerance':2e-12},
            'mathematical_premise_status':('counterexample_invalid_projector' if kind=='policy_counterexample' else 'declared_roundoff_allowance' if kind=='declared_roundoff_clamp' else 'reference_domain_denial' if expected['status']=='reject' else 'authored_analytic_domains'),
            'claim_scope':'authored analytical or declared numerical-policy case; host evaluation only'})
    for h in [*range(-32,33),-1000,-100,-50,50,100,1000]:
        add('sigmoid','high_precision_logistic','sigmoid',{'h':h},'decimal_logistic')
    for T in [.125,1,2,8,16]:
        for n in range(-8,9):add('periodic_q','quarter_period_identity','q',{'tau':T*n/4,'T':T},'quarter_period')
    for axis in range(5):
        for n in [-3,-2,-1,1,2,3]:
            for ell in [.125,.25]:
                indices=[0]*5;indices[axis]=n
                add('lattice','axis_and_cube','lattice_center',{'indices':indices,'ell':ell,'M':abs(n)},'rational_lattice')
        for sign in [-1,1]:
            for ell in [.25,.5]:
                indices=[0]*5;indices[axis]=sign;indices[(axis+1)%5]=-sign
                add('lattice','two_coordinate_L1_boundary','lattice_center',{'indices':indices,'ell':ell,'M':2},'rational_lattice')
    for n in range(2,9):
        for rank in range(min(n,4)+1):
            for variant in [0,1]:
                c4=[[0]*4 for _ in range(n)]
                for j in range(4):
                    if rank:c4[(j%rank+variant)%n][j]=2**(j+variant)
                add('projector_rank','coordinate_columns_with_dependence','projector_from_c4',{'C4':c4},'coordinate_column_space')
    for x in [-3,-1,0,1,3]:
        for y in [0,1,2,3]:
            for epsilon in [.25,1,4]:
                add('independence','coordinate_projector_residual','independence_score',{'e':[x,y],'projector':[[1,0],[0,0]],'denominator_epsilon':epsilon},'rational_projector_residual')
        for y in [-2,0,1,2]:
            add('independence','oblique_exact_rank_one','independence_score',{'e':[x,y],'projector':[[.5,.5],[.5,.5]],'denominator_epsilon':1},'rational_projector_residual')
    for axis in range(5):
        for weight in [0,.25,1,4,16]:
            for coordinate in [-1,-.5,.25,1]:
                values=[1]*5;values[axis]=weight;c=[0]*5;c[axis]=coordinate
                add('psd_geometry','diagonal_PSD_and_nullspace','quadratic_geometry',{'c_i':ZERO,'c_j':c,'G5':diag5(values)},'rational_psd_quadratic')
        for coordinate in [-1,-.5,.25,1]:
            v=[0]*5;v[axis]=1;v[(axis+1)%5]=2
            g=[[a*b for b in v] for a in v];c=[0]*5;c[axis]=coordinate;c[(axis+1)%5]=.5
            add('psd_geometry','rank_one_outer_product','quadratic_geometry',{'c_i':ZERO,'c_j':c,'G5':g},'rational_psd_quadratic')
    for axis in range(5):
        for coordinate in [.25,.5,1]:
            for A in [0,.5,2]:
                for dj in [0,.5]:
                    c=[0]*5;c[axis]=coordinate
                    add('pair_coupling','independent_Decimal_exponential','pair_weight',{'A_ij':A,'c_i':ZERO,'c_j':c,'G5':eye(5),'judgment_distance':dj,'sigma_c':1,'sigma_J':.5},'decimal_exponential_weight')
    for k in range(4):
        quarters=[0,k,(k+1)%4]
        for omega in [-2,0,2]:
            for K2 in [-1,.5,2]:
                add('phase_dynamics','ordered_pair_triad_quarter_turns','phase_derivative',{'index':0,'theta':[x*math.pi/2 for x in quarters],
                    'omega_i':omega,'K2':K2,'K3':.5,'pair_terms':[[2,1],[1,.25]],'triad_terms':[[2,1,-.25],[1,2,.5]]},'quarter_turn_sparse_phase',quarter_counts=quarters)
        for K3 in [-2,0,2]:
            for K2 in [0,1]:
                add('phase_dynamics','explicit_zero_and_signed_triad','phase_derivative',{'index':1,'theta':[x*math.pi/2 for x in quarters],
                    'omega_i':1,'K2':K2,'K3':K3,'pair_terms':[[0,2]],'triad_terms':[[0,2,1]]},'quarter_turn_sparse_phase',quarter_counts=quarters)
    for p1 in [.25,.5,.75]:
        for p2 in [0,.5,1]:
            for d in [-1,0,.5]:
                for J3 in [-2,0,2]:
                    add('activation','exact_rational_ordered_interactions','activation_field',{'beta':2,'M':2,'q_value':.25,'d_i':d,
                        'a_E':.5,'E_i':2,'a_u':2,'u_feature_i':.25,'a_chi':1,'chi_i':.5,'a_zeta':2,'zeta_i':.25,
                        'J2':2,'J3':J3,'probabilities':[.5,p1,p2],'pair_terms':[[1,.5],[2,1]],'triad_terms':[[1,2,2]]},'rational_activation')
    for p in [0,.25,.5,.75,1]:
        for k in [1,2]:
            for chi in [0,.5]:
                for velocity in [.5,1,2]:
                    add('support','independent_rational_factors','effective_support',{'p_i':p,'kappa_i':k,'chi_i':chi,'zeta_i':.25,'velocity_factor':velocity},'rational_support')
    for axis in range(5):
        for weight in [0,.25,1,2]:
            values=[.5]*5;values[axis]=weight
            add('boundary','coordinate_labels_4_through_8','boundary_product',{'weights_4_to_8':values},'five_factor_rational_product')
    for mask in range(32):
        add('boundary','five_binary_boundary_factors','boundary_product',{'weights_4_to_8':[.5 if mask&(1<<i) else 1 for i in range(5)]},'five_factor_rational_product')
    for root in [0,.5,1,2,3]:
        for b in [0,.5,1,2]:
            for alpha in [1,2,3]:
                for rmax in [1,2]:
                    add('radius','independent_perfect_cube_root','radius',{'r_max':rmax,'boundary_value':b,'alpha':alpha,'support':root**3},'perfect_cube_radius',support_cube_root=root)
    directions=[]
    for axis in range(4):
        for sign in [-1,1]:
            u=[0]*4;u[axis]=sign;directions.append(u)
    for c in [ZERO,[.5,0,-.5,0,1],[-1,.25,0,.5,0]]:
        for r in [0,.25,2]:
            for u in directions:add('fiber_embedding','cardinal_R4_fiber_R9_embedding','fiber_point',{'c_i':c,'r_i':r,'u':u},'cardinal_fiber_linear_projection')
    for c in [ZERO,[.5,0,-.5,0,1]]:
        for r in [0,.5,2]:
            for u in directions:
                for kind in [0,1,2]:
                    pi=copy.deepcopy(PI);psi=copy.deepcopy(PSI)
                    if kind==1:pi=[[0]*5 for _ in range(3)]
                    if kind==2:psi=[[0]*4 for _ in range(3)];pi[2][4]=2
                    add('linear_projection','rank_loss_and_fiber_contribution','projected_point',{'c_i':c,'r_i':r,'u':u,'Pi5':pi,'Psi4':psi},'cardinal_fiber_linear_projection')
    for weight in [1,4,9,16]:
        for coordinate in [.5,1]:
            for radii in [[0,0],[1,1],[0,1],[1,2]]:
                for exclusion in [0,.25,.5]:
                    add('gap_descriptors','independent_latent_fiber_projected_judgment','geometry_gaps',{'c_i':ZERO,'c_j':[coordinate,0,0,0,0],
                        'G5':diag5([weight,1,1,1,1]),'lambda_i':exclusion,'lambda_j':.25,'r_i':radii[0],'r_j':radii[1],
                        'Pi5':PI,'apparent_r_i':.5,'apparent_r_j':.25,'judgment_distance':exclusion,'judgment_threshold':.25},'rational_pythagorean_gaps')
    for eta in [.25,.5,.75]:
        for threshold in [math.nextafter(eta,-math.inf),eta,math.nextafter(eta,math.inf)]:
            for score in [.25,.5,.75]:
                for gain in [math.nextafter(score,-math.inf),score,math.nextafter(score,math.inf)]:
                    add('admission_edges','inclusive_eta_strict_gain_adjacent_floats','admit',{'eta_ind':eta,'epsilon_ind':threshold,'score_M8':score,'score_M7':0,'epsilon_gain':gain},'exact_binary_gate')
    for eta in [0,1]:
        for threshold in [0,1]:
            for score in [0,1]:
                for gain in [0,1]:
                    add('admission_edges','closed_interval_and_zero_gain_boundaries','admit',{'eta_ind':eta,'epsilon_ind':threshold,'score_M8':score,'score_M7':0,'epsilon_gain':gain},'exact_binary_gate')
    for r in [0,*[2.0**n for n in range(-20,21,2)]]:
        add('local_dimension','positive_regular_chart_or_collapse','local_noncollapsed_dimension',{'r_i':r},'conditional_regular_chart')
    example=json.loads((ROOT/'frozen/coupling8s/example_input.json').read_text(encoding='utf-8'))
    for x in [-1,0,1]:
        for y in [0,1,2]:
            for threshold in [.25,.5,.75]:
                for include_c4 in [False,True]:
                    record=copy.deepcopy(example);record['independence']['e']=[x,y];record['epsilon_ind']=threshold
                    if not include_c4:record['independence'].pop('C4')
                    add('typed_admission','explicit_projector_authority_and_gate','evaluate_admission_record',{'record':record},'typed_coordinate_projector_gate')
    for tol in [12,13,16,20]:
        add('tolerance_policy','unbounded_frozen_projector_counterexample','independence_score',{'e':[1],'projector':[[4]],'denominator_epsilon':1,'tolerance':tol},'policy_counterexample')
    for negative in [-1e-12,-1e-10,-5e-10]:
        add('tolerance_policy','declared_tiny_negative_PSD_roundoff','quadratic_geometry',{'c_i':ZERO,'c_j':[1,0,0,0,0],'G5':diag5([negative,1,1,1,1]),'tolerance':1e-9},'declared_roundoff_clamp')
    for weight in [1e-10,1e-9,1e-8]:
        add('tolerance_policy','absolute_rank_boundary','projector_from_c4',{'C4':[[weight,0,0,0],[0,0,0,0]],'tolerance':1e-9},'coordinate_column_space')
    primary={'sigmoid':['h'],'q':['tau'],'lattice_center':['ell'],'projector_from_c4':['C4',0,0],
        'independence_score':['denominator_epsilon'],'quadratic_geometry':['G5',0,0],'pair_weight':['A_ij'],
        'phase_derivative':['omega_i'],'activation_field':['beta'],'effective_support':['p_i'],'boundary_product':['weights_4_to_8',0],
        'radius':['r_max'],'fiber_point':['r_i'],'projected_point':['r_i'],'geometry_gaps':['lambda_i'],'admit':['eta_ind'],
        'local_noncollapsed_dimension':['r_i'],'evaluate_admission_record':['record','epsilon_ind']}
    valid={}
    for case in cases:
        if case['expected_frozen']['status']=='value':valid.setdefault(case['operation'],case)
    def set_path(obj,path,value):
        cursor=obj
        for k in path[:-1]:cursor=cursor[k]
        cursor[path[-1]]=value
    for op,path in primary.items():
        for bad in [True,'1',None,{'$nonfinite':'NaN'},{'$nonfinite':'+Infinity'},{'$nonfinite':'-Infinity'}]:
            inputs=copy.deepcopy(valid[op]['input']);set_path(inputs,path,bad)
            add(valid[op]['family'],'nonfinite_and_numeric_type_denial',op,inputs,'domain_rejection',
                violation='nonfinite' if isinstance(bad,dict) else 'numeric_type',path=path)
    def reject(op,path,value,violation,template='domain_and_structure_denial',**extra):
        inputs=copy.deepcopy(valid[op]['input']);set_path(inputs,path,value)
        add(valid[op]['family'],template,op,inputs,'domain_rejection',violation=violation,path=path,**extra)
    for op,path in [('q',['T']),('lattice_center',['ell']),('independence_score',['denominator_epsilon']),('pair_weight',['sigma_c']),('pair_weight',['sigma_J']),('radius',['alpha'])]:
        for bad in [0,-1]:reject(op,path,bad,'nonpositive')
    for op,path in [('radius',['support']),('radius',['boundary_value']),('radius',['r_max']),('effective_support',['kappa_i']),('effective_support',['velocity_factor']),('pair_weight',['A_ij']),('pair_weight',['judgment_distance']),('fiber_point',['r_i']),('local_noncollapsed_dimension',['r_i']),('geometry_gaps',['lambda_i']),('geometry_gaps',['apparent_r_i']),('admit',['epsilon_gain'])]:
        reject(op,path,-.25,'negative')
    for op,path in [('admit',['eta_ind']),('admit',['epsilon_ind']),('effective_support',['p_i']),('effective_support',['chi_i']),('effective_support',['zeta_i']),('activation_field',['q_value']),('activation_field',['probabilities',0])]:
        for bad in [-.25,1.25]:reject(op,path,bad,'unit_interval')
    for op,path,size in [('lattice_center',['indices'],5),('boundary_product',['weights_4_to_8'],5),('fiber_point',['u'],4),('quadratic_geometry',['c_i'],5),('projector_from_c4',['C4',0],4),('projected_point',['Pi5'],3)]:
        reject(op,path,[0]*(size-1),'length',required_length=size)
    reject('lattice_center',['indices',0],True,'integer_type')
    add('lattice','L1_reject','lattice_center',{'indices':[1,1,0,0,0],'ell':.25,'M':1},'domain_rejection',violation='lattice_l1')
    add('lattice','cube_reject','lattice_center',{'indices':[3,0,0,0,0],'ell':.5,'M':3},'domain_rejection',violation='lattice_cube')
    g=eye(5);g[0][1]=1;reject('quadratic_geometry',['G5'],g,'nonsymmetric')
    for axis in range(5):
        g=eye(5);g[axis][axis]=-1;reject('quadratic_geometry',['G5'],g,'negative_diagonal')
    reject('independence_score',['projector'],[[1,1],[0,0]],'nonsymmetric')
    reject('independence_score',['projector'],[[.5,0],[0,.5]],'nonidempotent')
    reject('phase_derivative',['pair_terms'],[[1,1],[1,2]],'duplicate_pair')
    reject('phase_derivative',['triad_terms'],[[1,2,1],[1,2,2]],'duplicate_triad')
    reject('phase_derivative',['index'],3,'index_range',size=3)
    reject('fiber_point',['u'],[2,0,0,0],'nonunit_fiber')
    reject('boundary_product',['weights_4_to_8',0],-.25,'negative')
    for field,value,required in [('profile','ambient.authority','ja.coupling8s'),('mode','native','admission'),('coordinate_convention','indices-1-to-8','center-indices-4-to-8/v1')]:
        reject('evaluate_admission_record',['record',field],value,'wrong_identity',required_value=required)
    record=copy.deepcopy(example);record['invented_authority']=True
    add('typed_admission','unknown_record_field','evaluate_admission_record',{'record':record},'domain_rejection',violation='unknown_record_field',field='invented_authority')
    record=copy.deepcopy(example);record['independence']['projector']=[[0,0],[0,0]]
    add('typed_admission','supplied_C4_projector_conflict','evaluate_admission_record',{'record':record},'domain_rejection',violation='projector_c4_conflict')
    return cases,duplicates


def build():
    cases,duplicates=authored_cases();source=file_digest(ROOT/'frozen/coupling8s/reference.py')
    for case in cases:
        case['source_sha256']=source
        case['frozen_observation']=observe(case['operation'],case['input'])
        case['research_observation']=observe(case['operation'],case['input'],True)
        case['reference_version']=reference.VERSION;case['research_policy_version']=POLICY_VERSION
        case['native_execution']=False;case['physical_theorem_claim']=False
        case['research_qualification']='accepted_conditional_host_policy' if case['research_observation']['status']=='value' else 'denied'
        case['record_sha256']=digest(case)
    output=ROOT/'dataset';output.mkdir(exist_ok=True)
    data=b''.join(canonical(case)+b'\n' for case in cases);(output/'cases.jsonl').write_bytes(data)
    families=Counter(c['family'] for c in cases);templates=Counter((c['family'],c['template']) for c in cases)
    with (output/'FAMILY_COVERAGE.csv').open('w',encoding='utf-8',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['family','cases','template_count','frozen_values','frozen_denials','research_values','research_denials'])
        for family,count in sorted(families.items()):
            group=[c for c in cases if c['family']==family]
            writer.writerow([family,count,len({c['template'] for c in group}),sum(c['frozen_observation']['status']=='value' for c in group),sum(c['frozen_observation']['status']=='reject' for c in group),sum(c['research_observation']['status']=='value' for c in group),sum(c['research_observation']['status']=='reject' for c in group)])
    manifest={'schema_version':'lcuf.math.dataset.0.1','case_count':len(cases),'unique_operation_input_count':len({c['input_sha256'] for c in cases}),
        'family_count':len(families),'family_counts':dict(sorted(families.items())),'family_template_count':len(templates),
        'template_counts':[{'family':f,'template':t,'count':n} for (f,t),n in sorted(templates.items())],
        'duplicate_inputs_eliminated':duplicates,'dataset_sha256':hashlib.sha256(data).hexdigest(),
        'reference_sha256':source,'reference_version':reference.VERSION,'research_policy_version':POLICY_VERSION,
        'tool_sha256':{p.name:file_digest(p) for p in sorted((ROOT/'tools').glob('*.py'))},
        'schema_sha256':{p.name:file_digest(p) for p in sorted((ROOT/'dataset').glob('*.schema.json'))},
        'host_environment':{'python':platform.python_version(),'implementation':platform.python_implementation(),'platform':platform.platform()},
        'frozen_observations':dict(Counter(c['frozen_observation']['status'] for c in cases)),
        'research_observations':dict(Counter(c['research_observation']['status'] for c in cases)),
        'uniqueness_scope':'Unique operation plus exact canonical input; repeated parameterized templates are counted explicitly, not independent theories or programs',
        'oracle_scope':'Decimal80 logistic/exponential, exact rational reductions, quarter-turn identities, coordinate-column projectors, explicit domain certificates and declared numerical-policy counterexamples; no reference-derived expected results',
        'execution_scope':'host_numeric_reference','native_execution':False,'federation_execution':False,'physical_theorem_claim':False}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:manifest[k] for k in ['case_count','unique_operation_input_count','family_count','family_template_count','frozen_observations','research_observations']}))


if __name__=='__main__':build()
