"""Portable stdlib validation, independent oracle reconstruction and host replay."""
from __future__ import annotations
import argparse
from collections import Counter
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import sys
sys.dont_write_bytecode=True
from build_dataset import canonical,digest,decode,file_digest,observe,CASE_VERSION
from oracles import independent_expected
from research_wrapper import ROOT, reference, VERSION as POLICY_VERSION, OPERATIONS

FIELDS={'schema_version','id','family','template','operation','input','input_sha256','oracle','expected_frozen','expected_research',
    'comparison','claim_scope','source_sha256','frozen_observation','research_observation','reference_version','research_policy_version',
    'native_execution','physical_theorem_claim','record_sha256','mathematical_premise_status','research_qualification'}
HASH=re.compile(r'^[0-9a-f]{64}$')


class ValidationError(ValueError):pass


def require(condition,message):
    if not condition:raise ValidationError(message)


def strict_json(text):
    def no_constant(value):raise ValidationError('nonstandard JSON numeric constant '+value)
    def unique(pairs):
        out={}
        for k,v in pairs:
            if k in out:raise ValidationError('duplicate JSON key '+k)
            out[k]=v
        return out
    try:return json.loads(text,parse_constant=no_constant,object_pairs_hook=unique)
    except (ValueError,UnicodeError,RecursionError) as e:raise ValidationError('invalid strict JSON: '+str(e)) from e


def json_tree(value):
    if value is None or isinstance(value,(bool,str,int)):return
    if isinstance(value,float):require(math.isfinite(value),'bare nonfinite JSON number');return
    if isinstance(value,list):
        for x in value:json_tree(x)
        return
    if isinstance(value,dict):
        require(all(isinstance(k,str) for k in value),'object keys must be strings')
        if '$nonfinite' in value:require(set(value)=={'$nonfinite'} and value['$nonfinite'] in {'NaN','+Infinity','-Infinity'},'invalid tagged nonfinite input')
        for x in value.values():json_tree(x)
        return
    raise ValidationError('non-JSON value')


def close_tree(actual,expected,absolute=2e-12,relative=2e-12,path='result'):
    if isinstance(expected,bool) or expected is None or isinstance(expected,str):
        require(type(actual) is type(expected) and actual==expected,path+' exact value mismatch');return
    if isinstance(expected,(int,float)):
        require(not isinstance(actual,bool) and isinstance(actual,(int,float)) and math.isfinite(actual),path+' numeric type mismatch')
        require(math.isclose(actual,expected,rel_tol=relative,abs_tol=absolute),path+' numeric mismatch');return
    if isinstance(expected,list):
        require(isinstance(actual,list) and len(actual)==len(expected),path+' array shape mismatch')
        for i,(a,e) in enumerate(zip(actual,expected)):close_tree(a,e,absolute,relative,path+f'[{i}]')
        return
    require(isinstance(expected,dict) and isinstance(actual,dict) and set(actual)==set(expected),path+' object field mismatch')
    for k,e in expected.items():close_tree(actual[k],e,absolute,relative,path+'.'+k)


def observation_matches(observed,expected,comparison):
    require(isinstance(observed,dict) and observed.get('execution_scope')=='host_numeric_reference','observation scope')
    require(observed.get('status')==expected['status'],'observation status differs from independent expectation')
    if expected['status']=='value':
        require(set(observed)=={'status','value','execution_scope'},'value observation fields')
        close_tree(observed['value'],expected['value'],comparison['absolute_tolerance'],comparison['relative_tolerance'])
    else:
        require(set(observed)<= {'status','error_class','error_message','execution_scope','policy_code'} and {'status','error_class','error_message','execution_scope'}<=set(observed),'denial observation fields')
        allowed=expected.get('allowed_error_classes',[expected.get('error_class')])
        require(observed['error_class'] in allowed,'unexpected denial class')
        if 'policy_code' in expected:require(observed.get('policy_code')==expected['policy_code'],'incorrect policy denial')


def check_case(case,source_sha256,replay=True):
    require(isinstance(case,dict) and set(case)==FIELDS,'case field set')
    require(case['schema_version']==CASE_VERSION and case['reference_version']==reference.VERSION and case['research_policy_version']==POLICY_VERSION,'case/profile version')
    require(re.fullmatch(r'MATH-[0-9]{6}',case['id']) is not None,'case identity')
    require(case['operation'] in OPERATIONS,'unknown operation')
    for k in ('family','template','claim_scope'):require(isinstance(case[k],str) and bool(case[k]),k+' must be nonempty')
    require(isinstance(case['input'],dict) and isinstance(case['oracle'],dict),'input/oracle objects')
    require(case['native_execution'] is False and case['physical_theorem_claim'] is False,'invalid execution/theorem authority')
    json_tree(case)
    for k in ('input_sha256','source_sha256','record_sha256'):require(isinstance(case[k],str) and HASH.fullmatch(case[k]) is not None,'invalid '+k)
    require(case['source_sha256']==source_sha256,'frozen source identity differs')
    require(case['input_sha256']==digest({'operation':case['operation'],'input':case['input']}),'input digest mismatch')
    unhashed={k:v for k,v in case.items() if k!='record_sha256'}
    require(case['record_sha256']==digest(unhashed),'record digest mismatch')
    require(case['comparison']=={'absolute_tolerance':2e-12,'relative_tolerance':2e-12},'unauthorized comparison tolerance')
    try:expected=independent_expected(case['operation'],decode(case['input']),case['oracle'])
    except (AssertionError,ValueError,KeyError,IndexError,TypeError) as e:raise ValidationError('invalid analytical/domain certificate: '+str(e)) from e
    require(canonical(expected)==canonical(case['expected_frozen']),'stored expectation differs from independent oracle')
    research_expected=copy.deepcopy(expected)
    if expected['status']=='reject':research_expected={'status':'reject','allowed_error_classes':['ModelError','PolicyError']}
    if case['oracle']['kind']=='policy_counterexample':research_expected={'status':'reject','allowed_error_classes':['PolicyError'],'policy_code':'tolerance_policy'}
    require(canonical(research_expected)==canonical(case['expected_research']),'research expectation differs from independently declared policy')
    premise='counterexample_invalid_projector' if case['oracle']['kind']=='policy_counterexample' else 'declared_roundoff_allowance' if case['oracle']['kind']=='declared_roundoff_clamp' else 'reference_domain_denial' if expected['status']=='reject' else 'authored_analytic_domains'
    require(case['mathematical_premise_status']==premise,'incorrect mathematical premise qualification')
    require(case['research_qualification']==('accepted_conditional_host_policy' if research_expected['status']=='value' else 'denied'),'incorrect research acceptance qualification')
    observation_matches(case['frozen_observation'],expected,case['comparison'])
    observation_matches(case['research_observation'],research_expected,case['comparison'])
    if replay:
        observation_matches(observe(case['operation'],case['input']),expected,case['comparison'])
        observation_matches(observe(case['operation'],case['input'],True),research_expected,case['comparison'])
    return True


def verify_provenance():
    provenance=strict_json((ROOT/'PROVENANCE.json').read_text(encoding='utf-8'))
    require(provenance['reference_patched'] is False,'frozen reference patch claim')
    for entry in provenance['copied_files']:
        path=(ROOT/entry['copy_relative_path']).resolve()
        require(path.is_relative_to(ROOT.resolve()),'escaping frozen path')
        data=path.read_bytes()
        require(len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'] and entry['copy_is_byte_exact'] is True,'frozen provenance mismatch')
    return len(provenance['copied_files'])


def local_schema_refs(value):
    if isinstance(value,dict):
        for k,v in value.items():
            if k in {'$ref','$dynamicRef'}:require(isinstance(v,str) and v.startswith('#'),'external schema reference')
            local_schema_refs(v)
    elif isinstance(value,list):
        for x in value:local_schema_refs(x)


def verify_numpy_snapshot(replay=True,json_schema=False):
    """Verify stored independent numerical expectations without requiring NumPy."""
    path=ROOT/'dataset/numpy_differential.jsonl';report_path=ROOT/'dataset/NUMPY_DIFFERENTIAL.json'
    if not path.exists():return {'status':'NOT_PRESENT','checks':0}
    report=strict_json(report_path.read_text(encoding='utf-8'));data=path.read_bytes()
    require(hashlib.sha256(data).hexdigest()==report['dataset_sha256'],'NumPy snapshot digest')
    source=file_digest(ROOT/'frozen/coupling8s/reference.py')
    records=[strict_json(line) for line in data.decode('utf-8').splitlines()];unique=set();engine=None
    if json_schema:
        import jsonschema
        schema=strict_json((ROOT/'dataset/numpy_differential.schema.json').read_text(encoding='utf-8'))
        local_schema_refs(schema);jsonschema.Draft202012Validator.check_schema(schema)
        engine=jsonschema.Draft202012Validator(schema)
    for i,record in enumerate(records,1):
        if engine is not None:engine.validate(record)
        require(set(record)=={'absolute_tolerance','execution_scope','family','id','independent_numpy_expected','input','input_sha256','max_absolute_difference','native_execution','observed_research_host','operation','physical_theorem_claim','record_sha256','relative_tolerance','source_sha256'},'NumPy record field set')
        require(record['id']==f'NUMPY-{i:06d}','NumPy snapshot identity')
        require(record['source_sha256']==source,'NumPy source identity')
        require(record['native_execution'] is False and record['physical_theorem_claim'] is False and record['execution_scope']=='host_numeric_differential','NumPy authority scope')
        json_tree(record)
        require(record['input_sha256']==digest({'operation':record['operation'],'input':record['input']}),'NumPy input digest')
        require(record['record_sha256']==digest({k:v for k,v in record.items() if k!='record_sha256'}),'NumPy record digest')
        require(record['input_sha256'] not in unique,'NumPy duplicate operation/input');unique.add(record['input_sha256'])
        require({'PSD_geometry':'quadratic_geometry','C4_projector':'projector_from_c4','linear_projection':'projected_point'}.get(record['family'])==record['operation'],'NumPy operation/family contract')
        require(record['absolute_tolerance']==2e-10 and record['relative_tolerance']==2e-10,'NumPy comparison policy')
        close_tree(record['observed_research_host'],record['independent_numpy_expected'],2e-10,2e-10)
        if replay:
            observation=observe(record['operation'],record['input'],True)
            require(observation['status']=='value','NumPy snapshot host replay denial')
            result=observation['value']['projector'] if record['operation']=='projector_from_c4' else observation['value']
            close_tree(result,record['independent_numpy_expected'],2e-10,2e-10)
    require(len(records)==report['checks']==500,'NumPy snapshot count')
    require(dict(Counter(r['family'] for r in records))==report['family_counts'],'NumPy family counts')
    return {'status':'PASS_SNAPSHOT_INTEGRITY_AND_STORED_COMPARISON','checks':len(records),'fresh_NumPy_execution':False,
        'fresh_research_host_replays':len(records) if replay else 0,'json_schema':'Draft202012 PASS' if engine is not None else 'not requested'}


def validate_dataset(replay=True,json_schema=False):
    count_frozen=verify_provenance();path=ROOT/'dataset/cases.jsonl';data=path.read_bytes()
    manifest=strict_json((ROOT/'dataset/manifest.json').read_text(encoding='utf-8'))
    require(hashlib.sha256(data).hexdigest()==manifest['dataset_sha256'],'dataset file digest')
    source=file_digest(ROOT/'frozen/coupling8s/reference.py');require(source==manifest['reference_sha256'],'manifest reference hash')
    for name,h in manifest['tool_sha256'].items():require(file_digest(ROOT/'tools'/name)==h,'tool identity '+name)
    for name,h in manifest['schema_sha256'].items():require(file_digest(ROOT/'dataset'/name)==h,'schema identity '+name)
    cases=[strict_json(line) for line in data.decode('utf-8').splitlines()]
    schema_validator=None
    if json_schema:
        import jsonschema
        schema=strict_json((ROOT/'dataset/cases.schema.json').read_text(encoding='utf-8'))
        # All schema references are local; loading cannot require a network fetch.
        local_schema_refs(schema);jsonschema.Draft202012Validator.check_schema(schema)
        schema_validator=jsonschema.Draft202012Validator(schema)
    ids=set();inputs=set()
    for i,case in enumerate(cases,1):
        require(case['id']==f'MATH-{i:06d}' and case['id'] not in ids,'sequence/identity conflict')
        require(case['input_sha256'] not in inputs,'duplicate operation/input')
        ids.add(case['id']);inputs.add(case['input_sha256'])
        try:
            if schema_validator is not None:schema_validator.validate(case)
            check_case(case,source,replay)
        except Exception as e:raise ValidationError(case['id']+': '+str(e)) from e
    families=Counter(c['family'] for c in cases);templates={(c['family'],c['template']) for c in cases}
    require(len(cases)==manifest['case_count']==manifest['unique_operation_input_count'],'count claim')
    require(dict(families)==manifest['family_counts'] and len(families)==manifest['family_count'],'family claim')
    require(len(templates)==manifest['family_template_count'],'template claim')
    result={'status':'PASS','cases':len(cases),'unique_operation_inputs':len(inputs),'families':len(families),'family_templates':len(templates),
        'frozen_files_verified':count_frozen,'independent_oracles_checked':len(cases),'host_evaluations_replayed':2*len(cases) if replay else 0,
        'frozen_value_cases':sum(c['frozen_observation']['status']=='value' for c in cases),
        'research_accepted_value_cases':sum(c['research_observation']['status']=='value' for c in cases),
        'research_denials':sum(c['research_observation']['status']=='reject' for c in cases),
        'json_schema':'Draft202012 PASS' if json_schema else 'stdlib closed-envelope/domain checks; JSON Schema engine optional',
        'native_execution':False,'federation_execution':False,'physical_theorem_claim':False}
    result['numpy_snapshot']=verify_numpy_snapshot(replay,json_schema)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--no-replay',action='store_true');parser.add_argument('--json-schema',action='store_true');parser.add_argument('--write-report',action='store_true');args=parser.parse_args()
    try:
        result=validate_dataset(not args.no_replay,args.json_schema)
        if args.write_report:(ROOT/'dataset/VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(result,indent=2))
    except Exception as error:
        print(json.dumps({'status':'FAIL','error':str(error)}));sys.exit(2)
