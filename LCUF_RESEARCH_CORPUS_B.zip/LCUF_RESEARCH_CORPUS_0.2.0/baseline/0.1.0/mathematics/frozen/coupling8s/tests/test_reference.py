import importlib.util
import copy
import json
import math
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("coupling8s_reference", ROOT / "reference.py")
ref = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ref)
G5 = [[float(i == j) for j in range(5)] for i in range(5)]
PI5 = [[float(i == j) for j in range(5)] for i in range(3)]
PSI4 = [[float(i == j) for j in range(4)] for i in range(3)]
ZERO = [0.0] * 5


class ArithmeticReference(unittest.TestCase):
    def test_stable_sigmoid(self):
        self.assertEqual(ref.sigmoid(0), .5)
        self.assertEqual(ref.sigmoid(1000), 1)
        self.assertEqual(ref.sigmoid(-1000), 0)
        self.assertAlmostEqual(ref.sigmoid(2) + ref.sigmoid(-2), 1)

    def test_periodic_q_has_no_undeclared_phase(self):
        self.assertAlmostEqual(ref.q(0, 2), 0)
        self.assertAlmostEqual(ref.q(1, 2), 1)
        self.assertAlmostEqual(ref.q(2, 2), 0)
        with self.assertRaises(ref.ModelError):
            ref.q(1, 0)

    def test_lattice_and_coordinate_convention(self):
        self.assertEqual(ref.COORDINATE_INDICES, (4, 5, 6, 7, 8))
        self.assertEqual(ref.lattice_center([1, 0, -1, 0, 0], .5, 2), [.5, 0, -.5, 0, 0])
        for indices, ell, M in [([1, 1, 1, 0, 0], .5, 2), ([3, 0, 0, 0, 0], .5, 3), ([True, 0, 0, 0, 0], .5, 1)]:
            with self.assertRaises(ref.ModelError):
                ref.lattice_center(indices, ell, M)

    def test_independence_projector_and_zero_coordinate(self):
        p = [[1, 0], [0, 0]]
        self.assertAlmostEqual(ref.independence_score([0, 2], p, 1), .8)
        self.assertEqual(ref.independence_score([2, 0], p, 1), 0)
        self.assertEqual(ref.independence_score([0, 0], p, 1), 0)

    def test_projector_matrix_rejection(self):
        for p in [[[1, 1], [0, 0]], [[.5, 0], [0, .5]], [[1]], [[1, math.inf], [0, 0]]]:
            with self.assertRaises(ref.ModelError):
                ref.independence_score([0, 1], p, 1)
        with self.assertRaises(ref.ModelError):
            ref.independence_score([0, 1], [[1, 0], [0, 0]], 0)

    def test_projector_tolerance_is_explicit(self):
        nearly = [[1 + 1e-11, 0], [0, 0]]
        ref.verify_projector(nearly, 2, 1e-9)
        with self.assertRaises(ref.ModelError):
            ref.verify_projector(nearly, 2, 1e-13)
        with self.assertRaises(ref.ModelError):
            ref.verify_projector([[1, 0], [0, 0]], 2, 0)

    def test_c4_column_space_projector(self):
        result = ref.projector_from_c4([[1, 2, 0, 0], [0, 0, 0, 0]])
        self.assertEqual(result["numerical_rank"], 1)
        self.assertEqual(result["projector"], [[1, 0], [0, 0]])
        self.assertEqual(ref.projector_from_c4([[0, 0, 0, 0]])["numerical_rank"], 0)
        with self.assertRaises(ref.ModelError):
            ref.projector_from_c4([[1, 0]])

    def test_weighted_geometry_and_sparse_weight(self):
        g = [row[:] for row in G5]
        g[0][0] = 4
        c = [.5, 0, 0, 0, 0]
        self.assertEqual(ref.quadratic_geometry(ZERO, c, g), 1)
        self.assertAlmostEqual(ref.pair_weight(2, ZERO, c, g, 1, 1, 1), 2 * math.exp(-1))
        self.assertEqual(ref.pair_weight(0, ZERO, c, g, 1, 1, 1), 0)

    def test_metric_semidefinite_and_negative_direction(self):
        singular = [[0.0] * 5 for _ in range(5)]
        singular[0][0] = 1
        self.assertEqual(ref.quadratic_geometry(ZERO, [0, 1, 0, 0, 0], singular), 0)
        bad = [row[:] for row in G5]
        bad[4][4] = -1
        with self.assertRaises(ref.ModelError):
            ref.quadratic_geometry(ZERO, ZERO, bad)
        bad = [row[:] for row in G5]
        bad[0][1] = 1
        with self.assertRaises(ref.ModelError):
            ref.quadratic_geometry(ZERO, ZERO, bad)

    def test_sparse_pair_and_triad_phase(self):
        theta = [0, math.pi / 4, math.pi / 4]
        expected = 1 + math.sqrt(.5) + 1
        self.assertAlmostEqual(ref.phase_derivative(0, theta, 1, 2, .5, [(1, .5)], [(1, 2, 2)]), expected)
        a = ref.phase_derivative(0, theta, 0, 1, 1, [(2, .2), (1, .3)], [(2, 1, .5), (1, 2, .1)])
        b = ref.phase_derivative(0, theta, 0, 1, 1, [(1, .3), (2, .2)], [(1, 2, .1), (2, 1, .5)])
        self.assertEqual(a, b)

    def test_sparse_indices_and_duplicates(self):
        for pairs, triads in [([(3, 1)], []), ([(1, 1), (1, 1)], []), ([], [(0, 1, 1), (0, 1, 1)]), ([(True, 1)], [])]:
            with self.assertRaises(ref.ModelError):
                ref.phase_derivative(0, [0, 1], 0, 1, 1, pairs, triads)

    def test_pair_and_triad_activation(self):
        h = ref.activation_field(2, 1, .5, 0, 1, 3, 0, 0, 1, 0, 1, 0,
                                 3, 2, [.5, .75, .25], [(1, 2)], [(1, 2, 4)])
        self.assertAlmostEqual(h, 6)

    def test_five_boundary_factors_support_and_radius(self):
        self.assertEqual(ref.boundary_product([.5] * 5), 1 / 32)
        support = ref.effective_support(.5, 1, 0, 0, .25)
        self.assertEqual(support, .125)
        self.assertAlmostEqual(ref.radius(4, .5, 2, support), .5)
        self.assertEqual(ref.radius(4, 0, 2, support), 0)
        self.assertEqual(ref.radius(4, .5, 2, 0), 0)
        with self.assertRaises(ref.ModelError):
            ref.boundary_product([1] * 8)
        with self.assertRaises(ref.ModelError):
            ref.radius(1, .5, 0, 1)
        with self.assertRaises(ref.ModelError):
            ref.effective_support(.5, 1, 2, 0, 1)

    def test_embedding_and_projection_dimensions(self):
        z = ref.fiber_point(ZERO, 2, [1, 0, 0, 0])
        self.assertEqual(len(z), 9)
        self.assertEqual(z[5:], [2, 0, 0, 0])
        self.assertEqual(ref.projected_point(ZERO, 2, [1, 0, 0, 0], PI5, PSI4), [2, 0, 0])
        with self.assertRaises(ref.ModelError):
            ref.fiber_point(ZERO, 2, [2, 0, 0, 0])
        with self.assertRaises(ref.ModelError):
            ref.projected_point(ZERO, 2, [1, 0, 0, 0], PI5[:2], PSI4)

    def test_independent_gaps_preserve_classification_boundary(self):
        g = [row[:] for row in G5]
        g[0][0] = 4
        result = ref.geometry_gaps(ZERO, [.5, 0, 0, 0, 0], g, .1, .2, 1, 2, PI5, .2, .4, .7, .9)
        self.assertAlmostEqual(result["g5"], .7)
        self.assertAlmostEqual(result["delta8"], math.sqrt(2))
        self.assertAlmostEqual(result["g3"], -.1)
        self.assertAlmostEqual(result["gJ"], -.2)
        self.assertIsNone(result["classification"])

    def test_inclusive_independence_strict_efficacy_gate(self):
        self.assertTrue(ref.admit(.8, .8, .75, .25, .25)["admitted_model_dimension"])
        self.assertFalse(ref.admit(.8, .8, .75, .25, .5)["admitted_model_dimension"])
        self.assertFalse(ref.admit(.79, .8, .75, .25, .25)["admitted_model_dimension"])

    def test_dimension_claim_is_noncollapsed_and_conditional(self):
        self.assertEqual(ref.local_noncollapsed_dimension(1), 8)
        self.assertIsNone(ref.local_noncollapsed_dimension(0))
        with self.assertRaises(ref.ModelError):
            ref.local_noncollapsed_dimension(-1)

    def test_nonfinite_boolean_and_host_range_rejections(self):
        for x in [math.nan, math.inf, -math.inf, True, "1"]:
            with self.assertRaises(ref.ModelError):
                ref.sigmoid(x)
        with self.assertRaises(ref.ModelError):
            ref.phase_derivative(0, [1e308, -1e308], 0, 1, 0, [(1, 1)])
        with self.assertRaises(ref.ModelError):
            ref.pair_weight(1, ZERO, [.5, 0, 0, 0, 0], G5, 0, 1e-300, 1)

    def test_typed_record_gate_has_host_scope(self):
        record = json.loads((ROOT / "example_input.json").read_text(encoding="utf-8"))
        result = ref.evaluate_admission_record(record)
        self.assertTrue(result["gate"]["admitted_model_dimension"])
        self.assertFalse(result["native_runtime_executed"])
        self.assertFalse(result["physical_theorem_claimed"])
        self.assertEqual(result["execution_scope"], "host_numeric_reference")
        with self.assertRaises(ref.ModelError):
            ref.evaluate_admission_record({"schema_version": ref.VERSION})

    def test_typed_record_identity_and_projector_conflicts(self):
        record = json.loads((ROOT / "example_input.json").read_text(encoding="utf-8"))
        for key, value in [("profile", "ambient.authority"), ("mode", "native"), ("coordinate_convention", "wrong")]:
            changed = copy.deepcopy(record)
            changed[key] = value
            with self.assertRaises(ref.ModelError):
                ref.evaluate_admission_record(changed)
        changed = copy.deepcopy(record)
        changed["independence"]["projector"] = [[0, 0], [0, 0]]
        with self.assertRaises(ref.ModelError):
            ref.evaluate_admission_record(changed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
