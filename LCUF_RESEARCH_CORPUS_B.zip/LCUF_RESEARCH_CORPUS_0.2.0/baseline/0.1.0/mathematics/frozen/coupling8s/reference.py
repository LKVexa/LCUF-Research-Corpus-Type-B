"""Pure host reference arithmetic for the supplied 8S Penteract-S^3 law.

No native image, transport, physical claim, model fitting or classification engine.
All inputs are explicit and nonfinite/ill-typed values raise ModelError.
"""
from __future__ import annotations
import functools
import math

VERSION = "coupling8s.reference.0.1"
COORDINATE_INDICES = (4, 5, 6, 7, 8)
DEFAULT_TOLERANCE = 1e-9


class ModelError(ValueError):
    pass


def host_numeric(function):
    """Turn backend range/domain errors into the profile's controlled rejection."""
    @functools.wraps(function)
    def checked(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except ModelError:
            raise
        except (ArithmeticError, ValueError) as error:
            raise ModelError(f"{function.__name__} exceeds the finite host numeric domain") from error
    return checked


def scalar(value, name="value", minimum=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ModelError(f"{name} must be a finite real number")
    try:
        result = float(value)
    except (ValueError, OverflowError) as error:
        raise ModelError(f"{name} exceeds host numeric range") from error
    if not math.isfinite(result) or (minimum is not None and result < minimum):
        raise ModelError(f"{name} is nonfinite or outside its domain")
    return result


def positive(value, name="value"):
    result = scalar(value, name, 0)
    if result == 0:
        raise ModelError(f"{name} must be positive")
    return result


def unit_interval(value, name="value"):
    result = scalar(value, name, 0)
    if result > 1:
        raise ModelError(f"{name} must be within [0,1]")
    return result


def vector(value, length=None, name="vector"):
    if not isinstance(value, (list, tuple)) or not value or (length is not None and len(value) != length):
        raise ModelError(f"{name} has invalid dimensions")
    return [scalar(x, f"{name}[{i}]") for i, x in enumerate(value)]


def matrix(value, rows, columns, name="matrix"):
    if not isinstance(value, (list, tuple)) or len(value) != rows:
        raise ModelError(f"{name} has invalid row count")
    return [vector(row, columns, f"{name}[{i}]") for i, row in enumerate(value)]


def dot(a, b):
    if len(a) != len(b):
        raise ModelError("dot-product dimensions disagree")
    products = [scalar(x * y, "product") for x, y in zip(a, b)]
    try:
        return scalar(math.fsum(products), "sum")
    except (ValueError, OverflowError) as error:
        raise ModelError("sum exceeds host numeric range") from error


def matvec(a, x):
    return [dot(row, x) for row in a]


def center(value):
    c = vector(value, 5, "center[4..8]")
    if any(abs(x) > 1 for x in c):
        raise ModelError("center must lie in [-1,1]^5")
    return c


@host_numeric
def lattice_center(indices, ell, M):
    if not isinstance(indices, (list, tuple)) or len(indices) != 5 or any(isinstance(n, bool) or not isinstance(n, int) for n in indices):
        raise ModelError("lattice index must contain five integers, ordered 4..8")
    if isinstance(M, bool) or not isinstance(M, int) or M < 0 or sum(abs(n) for n in indices) > M:
        raise ModelError("lattice index violates the nonnegative integer L1 bound M")
    ell = positive(ell, "ell")
    return center([scalar(ell * n, "lattice center") for n in indices])


def sigmoid(h):
    h = scalar(h, "h")
    if h >= 0:
        return 1 / (1 + math.exp(-h))
    exp_h = math.exp(h)
    return exp_h / (1 + exp_h)


@host_numeric
def q(tau, T):
    return math.sin(scalar(math.pi * scalar(tau, "tau") / positive(T, "T"), "phase argument")) ** 2


def verify_projector(projector, size, tolerance=DEFAULT_TOLERANCE):
    tol = positive(tolerance, "numerical tolerance")
    p = matrix(projector, size, size, "orthogonal projector")
    for i in range(size):
        for j in range(size):
            if abs(p[i][j] - p[j][i]) > tol:
                raise ModelError("projector must be symmetric within tolerance")
            product = dot(p[i], [p[k][j] for k in range(size)])
            if abs(product - p[i][j]) > tol:
                raise ModelError("projector must be idempotent within tolerance")
    return p


@host_numeric
def projector_from_c4(C4, tolerance=DEFAULT_TOLERANCE):
    """Numerical C4-column-space projector using two-pass Gram-Schmidt.

    Rank uses an explicit absolute tolerance; this is a host algorithm rather
    than a symbolic Moore-Penrose or conditioning proof.
    """
    if not isinstance(C4, (list, tuple)) or not C4:
        raise ModelError("C4 must have at least one row and four columns")
    c4 = matrix(C4, len(C4), 4, "C4")
    tol = positive(tolerance, "numerical tolerance")
    basis = []
    for column in range(4):
        value = [row[column] for row in c4]
        for _ in range(2):
            for direction in basis:
                coefficient = dot(direction, value)
                value = [scalar(v - coefficient * q, "orthogonal residual") for v, q in zip(value, direction)]
        norm = math.sqrt(dot(value, value))
        if norm > tol:
            basis.append([scalar(v / norm, "orthogonal direction") for v in value])
    p = [[scalar(math.fsum(q[i] * q[j] for q in basis), "projector component")
          for j in range(len(c4))] for i in range(len(c4))]
    verify_projector(p, len(c4), tol)
    return {"projector": p, "numerical_rank": len(basis),
            "algorithm": "two_pass_modified_Gram_Schmidt_absolute_tolerance"}


@host_numeric
def independence_score(e, projector, denominator_epsilon, tolerance=DEFAULT_TOLERANCE):
    """Evaluate eta from an explicit projector declared to be C4 C4+.

    Symmetry/idempotence are checked. Its relationship to C4 is caller evidence,
    not established merely by this function or a successful admission result.
    """
    e = vector(e, name="e")
    p = verify_projector(projector, len(e), tolerance)
    residual = [x - y for x, y in zip(e, matvec(p, e))]
    numerator = dot(residual, residual)
    denominator = scalar(dot(e, e) + positive(denominator_epsilon, "denominator epsilon"), "independence denominator")
    eta = scalar(numerator / denominator, "eta_ind", 0)
    if eta > 1 + positive(tolerance, "numerical tolerance"):
        raise ModelError("projector produces an invalid independence score")
    return eta


def _metric(g, tolerance=DEFAULT_TOLERANCE):
    """Check 5x5 symmetric PSD using pivoted Schur elimination."""
    tol = positive(tolerance, "numerical tolerance")
    original = matrix(g, 5, 5, "G5")
    if any(abs(original[i][j] - original[j][i]) > tol for i in range(5) for j in range(5)):
        raise ModelError("G5 must be symmetric")
    a = [[(original[i][j] + original[j][i]) / 2 for j in range(5)] for i in range(5)]
    for k in range(5):
        pivot = max(range(k, 5), key=lambda i: a[i][i])
        a[k], a[pivot] = a[pivot], a[k]
        for row in a:
            row[k], row[pivot] = row[pivot], row[k]
        diagonal = a[k][k]
        if diagonal < -tol:
            raise ModelError("G5 is not positive semidefinite")
        if diagonal <= tol:
            if any(abs(a[i][j]) > tol for i in range(k, 5) for j in range(k, 5)):
                raise ModelError("G5 has an inconsistent null direction")
            break
        for i in range(k + 1, 5):
            for j in range(i, 5):
                a[i][j] = scalar(a[i][j] - a[i][k] * a[j][k] / diagonal, "metric elimination")
                a[j][i] = a[i][j]
    return original


@host_numeric
def quadratic_geometry(c_i, c_j, G5, tolerance=DEFAULT_TOLERANCE):
    ci, cj = center(c_i), center(c_j)
    g = _metric(G5, tolerance)
    difference = [a - b for a, b in zip(ci, cj)]
    value = dot(difference, matvec(g, difference))
    if value < -positive(tolerance, "numerical tolerance"):
        raise ModelError("negative weighted squared distance")
    return max(0.0, value)


@host_numeric
def pair_weight(A_ij, c_i, c_j, G5, judgment_distance, sigma_c, sigma_J, tolerance=DEFAULT_TOLERANCE):
    adjacency = scalar(A_ij, "A_ij", 0)
    dj = scalar(judgment_distance, "d_J", 0)
    sc, sj = positive(sigma_c, "sigma_c"), positive(sigma_J, "sigma_J")
    geometry = quadratic_geometry(c_i, c_j, G5, tolerance)
    exponent = scalar(-geometry / (2 * sc * sc) - dj * dj / (2 * sj * sj), "coupling exponent")
    return scalar(adjacency * math.exp(exponent), "W_ij", 0)


def _index(value, size):
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value < size:
        raise ModelError("sparse coupling index is out of range")
    return value


def _terms(pair_terms, triad_terms, size):
    if not isinstance(pair_terms, (list, tuple)) or not isinstance(triad_terms, (list, tuple)):
        raise ModelError("sparse terms must be explicit sequences")
    pairs, triads, seen_pairs, seen_triads = [], [], set(), set()
    for term in pair_terms:
        if not isinstance(term, (list, tuple)) or len(term) != 2:
            raise ModelError("pair term must be (j,W_ij)")
        j = _index(term[0], size)
        if j in seen_pairs:
            raise ModelError("duplicate sparse pair index")
        seen_pairs.add(j)
        pairs.append((j, scalar(term[1], "W_ij", 0)))
    for term in triad_terms:
        if not isinstance(term, (list, tuple)) or len(term) != 3:
            raise ModelError("triad term must be (j,k,H_ijk)")
        j, k = _index(term[0], size), _index(term[1], size)
        if (j, k) in seen_triads:
            raise ModelError("duplicate ordered sparse triad index")
        seen_triads.add((j, k))
        triads.append((j, k, scalar(term[2], "H_ijk")))
    return sorted(pairs), sorted(triads)


@host_numeric
def phase_derivative(index, theta, omega_i, K2, K3, pair_terms=(), triad_terms=()):
    phases = vector(theta, name="theta")
    i = _index(index, len(phases))
    pairs, triads = _terms(pair_terms, triad_terms, len(phases))
    pair = math.fsum(w * math.sin(phases[j] - phases[i]) for j, w in pairs)
    triad = math.fsum(h * math.sin(phases[j] + phases[k] - 2 * phases[i]) for j, k, h in triads)
    return scalar(scalar(omega_i, "omega_i") + scalar(K2, "K2") * pair + scalar(K3, "K3") * triad, "theta_dot_i")


@host_numeric
def activation_field(beta, M, q_value, d_i, a_E, E_i, a_u, u_feature_i, a_chi, chi_i, a_zeta, zeta_i,
                     J2, J3, probabilities, pair_terms=(), triad_terms=()):
    p = [unit_interval(x, "p_j") for x in vector(probabilities, name="probabilities")]
    pairs, triads = _terms(pair_terms, triad_terms, len(p))
    pair = math.fsum(w * (2 * p[j] - 1) for j, w in pairs)
    triad = math.fsum(h * (2 * p[j] - 1) * (2 * p[k] - 1) for j, k, h in triads)
    return scalar(scalar(beta, "beta") * (scalar(M, "M", 0) * unit_interval(q_value, "q") + .5 - scalar(d_i, "d_i"))
                  + scalar(a_E, "a_E") * scalar(E_i, "E_i")
                  + scalar(a_u, "a_u") * scalar(u_feature_i, "u_feature_i")
                  - scalar(a_chi, "a_chi") * unit_interval(chi_i, "chi_i")
                  - scalar(a_zeta, "a_zeta") * unit_interval(zeta_i, "zeta_i")
                  + scalar(J2, "J2") * pair + scalar(J3, "J3") * triad, "h_i")


@host_numeric
def effective_support(p_i, kappa_i, chi_i, zeta_i, velocity_factor):
    return scalar(unit_interval(p_i, "p_i") * scalar(kappa_i, "kappa_i", 0)
                  * (1 - unit_interval(chi_i, "chi_i")) * (1 - unit_interval(zeta_i, "zeta_i"))
                  * scalar(velocity_factor, "v(omega_i)", 0), "s_i", 0)


@host_numeric
def boundary_product(weights_4_to_8):
    weights = vector(weights_4_to_8, 5, "boundary values b(c_a), a=4..8")
    return scalar(math.prod(scalar(w, "boundary value", 0) for w in weights), "B5", 0)


@host_numeric
def radius(r_max, boundary_value, alpha, support):
    rmax = scalar(r_max, "r_max", 0)
    b, a, s = scalar(boundary_value, "B5", 0), positive(alpha, "alpha"), scalar(support, "s_i", 0)
    try:
        return scalar(rmax * b ** a * s ** (1 / 3), "r_i", 0)
    except OverflowError as error:
        raise ModelError("radius exceeds host numeric range") from error


@host_numeric
def fiber_point(c_i, r_i, u, tolerance=DEFAULT_TOLERANCE):
    c, r, direction = center(c_i), scalar(r_i, "r_i", 0), vector(u, 4, "u in S3")
    if abs(dot(direction, direction) - 1) > positive(tolerance, "numerical tolerance"):
        raise ModelError("fiber direction u must have unit norm in R4")
    return c + [scalar(r * component, "fiber coordinate") for component in direction]


@host_numeric
def projected_point(c_i, r_i, u, Pi5, Psi4, tolerance=DEFAULT_TOLERANCE):
    z = fiber_point(c_i, r_i, u, tolerance)
    pi, psi = matrix(Pi5, 3, 5, "Pi5"), matrix(Psi4, 3, 4, "Psi4")
    return [scalar(a + b, "projected coordinate") for a, b in zip(matvec(pi, z[:5]), matvec(psi, z[5:]))]


@host_numeric
def geometry_gaps(c_i, c_j, G5, lambda_i, lambda_j, r_i, r_j, Pi5, apparent_r_i, apparent_r_j,
                  judgment_distance, judgment_threshold, tolerance=DEFAULT_TOLERANCE):
    squared = quadratic_geometry(c_i, c_j, G5, tolerance)
    ri, rj = scalar(r_i, "r_i", 0), scalar(r_j, "r_j", 0)
    pi = matrix(Pi5, 3, 5, "Pi5")
    difference = [a - b for a, b in zip(matvec(pi, center(c_i)), matvec(pi, center(c_j)))]
    return {
        "g5": scalar(math.sqrt(squared) - scalar(lambda_i, "lambda_i", 0) - scalar(lambda_j, "lambda_j", 0), "g5"),
        "delta8": scalar(math.sqrt(scalar(squared + (ri - rj) ** 2, "delta8 squared")), "delta8", 0),
        "g3": scalar(math.sqrt(dot(difference, difference)) - scalar(apparent_r_i, "apparent_r_i", 0) - scalar(apparent_r_j, "apparent_r_j", 0), "g3"),
        "gJ": scalar(scalar(judgment_distance, "d_J", 0) - scalar(judgment_threshold, "theta_J", 0), "gJ"),
        "classification": None,
        "classification_status": "requires_explicit_versioned_Classify_policy",
    }


@host_numeric
def admit(eta_ind, epsilon_ind, score_M8, score_M7, epsilon_gain):
    eta = unit_interval(eta_ind, "eta_ind")
    threshold = unit_interval(epsilon_ind, "epsilon_ind")
    delta = scalar(scalar(score_M8, "Score(M8)") - scalar(score_M7, "Score(M7)"), "Delta8S")
    gain = scalar(epsilon_gain, "epsilon_gain", 0)
    return {"eta_ind": eta, "Delta8S": delta, "independence_pass": eta >= threshold,
            "efficacy_pass": delta > gain, "admitted_model_dimension": eta >= threshold and delta > gain,
            "authority": "numeric_model_gate_only"}


def local_noncollapsed_dimension(r_i):
    """5+3 only for a positive-radius fiber in a regular local product chart.

    None at collapse: this routine does not infer the total space's singular
    topology or dimension from a zero-radius sample.
    """
    return 8 if scalar(r_i, "r_i", 0) > 0 else None


def evaluate_admission_record(record):
    if not isinstance(record, dict) or record.get("schema_version") != VERSION:
        raise ModelError("unsupported reference record schema")
    fields = {"schema_version", "profile", "mode", "coordinate_convention", "numerical_tolerance",
              "epsilon_ind", "independence", "efficacy", "provenance"}
    if set(record) != fields or record.get("profile") != "ja.coupling8s" or record.get("mode") != "admission" or record.get("coordinate_convention") != "center-indices-4-to-8/v1":
        raise ModelError("record identity, mode, coordinate convention or fields disagree with the profile")
    try:
        independence, efficacy = record["independence"], record["efficacy"]
        if not isinstance(independence, dict) or not isinstance(efficacy, dict):
            raise ModelError("independence and efficacy must be typed objects")
        required_independence = {"e", "projector", "denominator_epsilon", "projector_definition_id"}
        if not required_independence <= set(independence) <= required_independence | {"C4"}:
            raise ModelError("independence fields disagree with the profile")
        if set(efficacy) != {"score_M8", "score_M7", "epsilon_gain", "evaluation_id"}:
            raise ModelError("efficacy fields disagree with the profile")
        provenance = record["provenance"]
        if not isinstance(provenance, dict) or set(provenance) != {"arithmetic_source", "evidence_scope"} or provenance["evidence_scope"] != "host_reference_input":
            raise ModelError("provenance scope must identify host reference input")
        for value in (independence["projector_definition_id"], efficacy["evaluation_id"], provenance["arithmetic_source"]):
            if not isinstance(value, str) or not value:
                raise ModelError("provenance and definition identifiers must be nonempty strings")
        tolerance = positive(record["numerical_tolerance"], "numerical tolerance")
        projector_authority = "caller_declared_C4_column_space; symmetry_and_idempotence_checked"
        if "C4" in independence:
            expected = projector_from_c4(independence["C4"], tolerance)["projector"]
            supplied = matrix(independence["projector"], len(expected), len(expected), "orthogonal projector")
            if any(abs(expected[i][j] - supplied[i][j]) > tolerance for i in range(len(expected)) for j in range(len(expected))):
                raise ModelError("supplied projector disagrees with the numerical column space of C4")
            projector_authority = "numerically_checked_C4_column_space_with_declared_tolerance"
        eta = independence_score(independence["e"], independence["projector"], independence["denominator_epsilon"], tolerance)
        result = admit(eta, record["epsilon_ind"], efficacy["score_M8"], efficacy["score_M7"], efficacy["epsilon_gain"])
    except (KeyError, TypeError) as error:
        raise ModelError("reference record is missing or has invalid typed fields") from error
    return {"profile": "ja.coupling8s", "reference_version": VERSION, "execution_scope": "host_numeric_reference",
            "native_runtime_executed": False, "physical_theorem_claimed": False, "gate": result,
            "projector_authority": projector_authority}
