import copy
import json
import math
from pathlib import Path
import sys
import unittest
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import build_dataset as builder
import oracles
import research_wrapper as wrapper
import validate


class ResearchMathematics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases=[validate.strict_json(line) for line in (ROOT/'dataset/cases.jsonl').read_text(encoding='utf-8').splitlines()]
        cls.source=builder.file_digest(ROOT/'frozen/coupling8s/reference.py')

    def forged(self,case):
        case['record_sha256']=builder.digest({k:v for k,v in case.items() if k!='record_sha256'})
        return case

    def pick(self,operation):return copy.deepcopy(next(c for c in self.cases if c['operation']==operation and c['expected_frozen']['status']=='value'))

    def test_entire_corpus_independent_oracles_and_host_replay(self):
        result=validate.validate_dataset()
        self.assertGreaterEqual(result['cases'],500)
        self.assertGreaterEqual(result['families'],12)

    def test_all_nine_frozen_files_preserved(self):self.assertEqual(validate.verify_provenance(),9)

    def test_independent_oracle_never_imports_reference(self):
        source=(ROOT/'tools/oracles.py').read_text(encoding='utf-8')
        self.assertNotIn('import research_wrapper',source)
        self.assertNotIn('import reference',source)
        self.assertEqual(oracles.independent_expected('sigmoid',{'h':0},{'kind':'decimal_logistic'})['value'],.5)

    def test_input_digest_detects_mutation(self):
        c=self.pick('sigmoid');c['input']['h']=123
        with self.assertRaisesRegex(validate.ValidationError,'input digest'):validate.check_case(self.forged(c),self.source,False)

    def test_forged_expectation_is_rejected_after_rehash(self):
        c=self.pick('sigmoid');c['expected_frozen']['value']=.123;c['frozen_observation']['value']=.123
        with self.assertRaisesRegex(validate.ValidationError,'independent oracle'):validate.check_case(self.forged(c),self.source,False)

    def test_forged_observed_result_is_rejected(self):
        c=self.pick('sigmoid');c['frozen_observation']['value']=.321
        with self.assertRaises(validate.ValidationError):validate.check_case(self.forged(c),self.source,False)

    def test_native_authority_flag_cannot_be_promoted(self):
        c=self.pick('sigmoid');c['native_execution']=True
        with self.assertRaisesRegex(validate.ValidationError,'authority'):validate.check_case(self.forged(c),self.source,False)

    def test_source_identity_mismatch_rejected(self):
        c=self.pick('sigmoid');c['source_sha256']='0'*64
        with self.assertRaisesRegex(validate.ValidationError,'source identity'):validate.check_case(self.forged(c),self.source,False)

    def test_unknown_case_fields_rejected(self):
        c=self.pick('sigmoid');c['certified']=True
        with self.assertRaisesRegex(validate.ValidationError,'field set'):validate.check_case(self.forged(c),self.source,False)

    def test_comparison_tolerance_cannot_be_relaxed(self):
        c=self.pick('sigmoid');c['comparison']['absolute_tolerance']=1
        with self.assertRaisesRegex(validate.ValidationError,'comparison tolerance'):validate.check_case(self.forged(c),self.source,False)

    def test_unauthorized_observation_scope_rejected(self):
        c=self.pick('sigmoid');c['frozen_observation']['execution_scope']='native'
        with self.assertRaisesRegex(validate.ValidationError,'scope'):validate.check_case(self.forged(c),self.source,False)

    def test_uniqueness_is_operation_plus_input(self):
        self.assertEqual(len(self.cases),len({c['input_sha256'] for c in self.cases}))
        manifest=json.loads((ROOT/'dataset/manifest.json').read_text())
        self.assertGreater(manifest['duplicate_inputs_eliminated'],0)

    def test_excessive_tolerance_20_denied_while_frozen_behavior_preserved(self):
        inputs={'e':[1],'projector':[[4]],'denominator_epsilon':1,'tolerance':20}
        self.assertEqual(wrapper.reference.independence_score(**inputs),4.5)
        with self.assertRaises(wrapper.PolicyError) as denial:wrapper.evaluate('independence_score',inputs)
        self.assertEqual(denial.exception.code,'tolerance_policy')

    def test_policy_tolerance_upper_boundary(self):
        self.assertEqual(wrapper.tolerance(1e-6),1e-6)
        with self.assertRaises(wrapper.PolicyError):wrapper.tolerance(math.nextafter(1e-6,math.inf))
        for invalid in [0,-1,True,None,math.inf]:
            with self.assertRaises(wrapper.PolicyError):wrapper.tolerance(invalid)

    def test_tiny_negative_PSD_is_declared_roundoff_only(self):
        g=builder.diag5([-1e-10,1,1,1,1]);inputs={'c_i':[0]*5,'c_j':[1,0,0,0,0],'G5':g,'tolerance':1e-9}
        self.assertEqual(wrapper.evaluate('quadratic_geometry',inputs),0)
        g[0][0]=-1
        with self.assertRaises(wrapper.reference.ModelError):wrapper.evaluate('quadratic_geometry',inputs)

    def test_output_eta_outside_interval_rejected(self):
        with self.assertRaises(wrapper.PolicyError):wrapper.validate_output('independence_score',4.5,{})

    def test_output_negative_geometry_rejected(self):
        with self.assertRaises(wrapper.PolicyError):wrapper.validate_output('quadratic_geometry',-1,{})

    def test_output_nonfinite_rejected(self):
        with self.assertRaises(wrapper.PolicyError):wrapper.validate_output('radius',math.inf,{})

    def test_corrupted_gate_boolean_rejected(self):
        inputs={'eta_ind':.5,'epsilon_ind':.5,'score_M8':.5,'score_M7':0,'epsilon_gain':.5}
        result=wrapper.reference.admit(**inputs);result['efficacy_pass']=True
        with self.assertRaises(wrapper.PolicyError):wrapper.validate_output('admit',result,inputs)

    def test_inclusive_independence_and_strict_gain(self):
        x={'eta_ind':.5,'epsilon_ind':.5,'score_M8':.5,'score_M7':0,'epsilon_gain':.5}
        gate=wrapper.evaluate('admit',x)
        self.assertTrue(gate['independence_pass']);self.assertFalse(gate['efficacy_pass'])
        x['epsilon_gain']=math.nextafter(.5,0);self.assertTrue(wrapper.evaluate('admit',x)['admitted_model_dimension'])
        x['epsilon_ind']=math.nextafter(.5,1);self.assertFalse(wrapper.evaluate('admit',x)['admitted_model_dimension'])

    def test_bools_do_not_match_numeric_oracles(self):
        with self.assertRaises(validate.ValidationError):validate.close_tree(True,1)
        with self.assertRaises(validate.ValidationError):validate.close_tree(1,True)

    def test_strict_JSON_rejects_native_nan_and_duplicate_keys(self):
        for text in ['{"x":NaN}','{"x":Infinity}','{"x":1,"x":2}']:
            with self.assertRaises(validate.ValidationError):validate.strict_json(text)

    def test_nonfinite_tags_are_test_inputs_only(self):
        self.assertTrue(math.isnan(builder.decode({'$nonfinite':'NaN'})))
        with self.assertRaises(wrapper.PolicyError):wrapper.evaluate('sigmoid',{'h':builder.decode({'$nonfinite':'NaN'})})

    def test_unknown_operation_or_keyword_rejected(self):
        with self.assertRaises(wrapper.PolicyError):wrapper.evaluate('run_native',{})
        with self.assertRaises(wrapper.PolicyError):wrapper.evaluate('sigmoid',{'h':0,'network':True})

    def test_zero_radius_has_no_total_space_dimension_claim(self):
        self.assertIsNone(wrapper.evaluate('local_noncollapsed_dimension',{'r_i':0}))
        self.assertEqual(wrapper.evaluate('local_noncollapsed_dimension',{'r_i':1}),8)

    def test_no_Classify_policy_is_synthesized(self):
        c=self.pick('geometry_gaps');result=wrapper.evaluate(c['operation'],c['input'])
        self.assertIsNone(result['classification'])
        result['classification']='TRUE_8S'
        with self.assertRaises(wrapper.PolicyError):wrapper.validate_output('geometry_gaps',result,c['input'])

    def test_typed_record_rejects_ambient_authority(self):
        c=self.pick('evaluate_admission_record');c['input']['record']['profile']='ambient.authority'
        with self.assertRaises(wrapper.reference.ModelError):wrapper.evaluate(c['operation'],c['input'])

    def test_no_unexpected_exception_is_hidden(self):
        for c in self.cases:
            self.assertNotEqual(c['frozen_observation']['status'],'unexpected_exception')
            self.assertNotEqual(c['research_observation']['status'],'unexpected_exception')


if __name__=='__main__':unittest.main(verbosity=2)
