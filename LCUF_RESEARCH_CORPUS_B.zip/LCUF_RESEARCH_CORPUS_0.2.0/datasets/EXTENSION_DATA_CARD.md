# Article-derived extension data card

The extension master contains **352 records** in **55 construction families**: 272 accepted programs, 32 intentional rejection cases and 48 metamorphic pairs. A complete replay evaluates 400 source slots because each pair contains two sources. It is additional bounded LCUF-X research evidence; the frozen baseline's 10,144 core records and mathematical datasets remain separately preserved.

## Construction and independence

Seventeen accepted families have sixteen parameter variants each. Their golden outputs are stated through closed-form integer, basis-vector, stencil, sample-index and scaled-sign examples in [the builder](../tools/build_extension_cases.py). Thirty-two rejection families contain one representative mutation each. Six identity families have eight pairs each. Rejection bodies are not duplicated under eight different module names merely to increase the population.

The builder's header, columns, operation profiles/arities and effect/capability tables are independent literal fixture contracts. They do not obtain expected policy from the target compiler's mutable metadata. Thus changing a target policy does not silently regenerate a matching expected source. Actual observations still come from the target by definition; expected scalar/vector answers and rejection predicates remain separate.

Parameter variants share algorithmic templates and many shapes. Exact source identity does not establish independent design, machine-learning generalization or blind evaluation. This extension has no training/test split; its purpose is conformance. The baseline's family partitions likewise retain their documented leakage limits. Article labels identify related design lineage, not a certification of every assertion in an article.

## Golden families

Finite arithmetic covers modular addition/product, signed i64 reduction, zero/nonzero capped valuation and explicit precision reduction. PField cases cover global average, low-digit coset average and identity. HRR cases use independently specified basis shifts and a non-inverse counterexample. Additional cases cover cyclic permutation, a convex periodic diffusion stencil, exact u8 translation, scaled-sign reconstruction, local residual extraction and wire-only remote model copying.

For a four-vector x=[a,0,0,0] with zero residual, the expected RMS scale is a/2, reconstructed q=[a/2,a/2,a/2,a/2], and retained r=[a/2,−a/2,−a/2,−a/2]. For samples 0..7 over Z/(2³), averaging by parity gives [3,4,3,4,3,4,3,4]. For key [1,1,0,0], binding [a,0,2a,0] then correlating gives [2a,3a,4a,3a], demonstrating that correlation is not general exact inversion.

Rejections exercise composite radices, precision/shape limits, noncanonical residues, Boolean coercion, implicit refinement, mixed primes, nonfinite literals, raster samples, residual initialization and remote ownership, state grants/effects, unstable diffusion, malformed operation/type signatures, packet literals, insufficient work, insufficient retained-plus-scratch reservation, link/sender/receiver authority, duplicate writers, cycles, unsupported physical operations, wrong header and invalid UTF-8.

Metamorphic pairs test comments, CRLF, BOM, cell spacing, row permutation and typed-float literal normalization. Their raw source hashes differ while their normalized reference-contract identity remains equal. They retain the same numerical golden outputs. Changing reference source bytes changes the implementation identity and therefore the contract hash; whitespace changes in a program do not change that reference identity.

## Record and verification contracts

[The schema](../schemas/extension_record.schema.json) requires exact source base64, UTF-8 projection or null, source digest, family/variant, related article IDs, stable X requirements, expected predicate, actual observation, PASS comparison and host-only scope. It conditionally requires the second source/observation only for a metamorphic record. Execution flags for native, authenticated network, physical optics and full 1-bit LAMB are always false.

The [validator](../tools/validate_extensions.py) applies Draft 2020-12, rejects duplicate keys and nonfinite JSON, binds source bytes/text/hash, checks independent operation policy, verifies complete expected family/ID populations, reruns source, compares the stored observation exactly, checks independently constructed golden outputs, and recomputes receipt bodies/chains from the scheduled rows and results. Empty and truncated populations fail. A metadata-only mode lacks fresh observation replay and must retain that distinction.

Golden real outputs use 2e−13 absolute and relative tolerance; exact integer, raster, Boolean, text, packet-field and identifier comparisons preserve type distinctions. The stored observation is separately compared exactly against fresh execution on the recorded host. A different platform/library environment can require numerical requalification rather than silently replacing an observation.

## Independent numerical layer

The [208-case numerical layer](numerical_crosschecks.jsonl) contains 64 FFT convolution comparisons, 64 FFT correlation comparisons, 32 exact-rational coset averages, 32 exact-rational diffusion stencils and 16 independent NumPy RMS-sign comparisons. HRR vector lengths include 1,2,3,4,5,8,16,32; compression comparisons additionally cover 256. Seed 82109 and NumPy 2.3.5 are recorded in [the receipt](../validation/NUMERICAL_CROSSCHECKS.json).

The independent algorithms use NumPy complex FFTs and norm calculations, or Fraction evaluation followed by one binary64 conversion. The main reference uses direct products/fsum and a scaled RMS construction. The checks use 2e−13 absolute and relative tolerance and selected well-scaled finite inputs. Agreement establishes these finite comparisons, not arbitrary conditioning, continuous p-adic diffusion, physical optics, full optimizer convergence or a theorem about all inputs.

## Additional assurance

The new unit suites test mathematical boundary/counterexamples, wire bytes and padding, large finite RMS scale, signed-zero admission, state transitions, type/authority/resource boundaries, deterministic identity, receipt evidence, and validator tampering. An independent read-only review includes 69 adversarial probes and a 100-step nonzero-residual stream. Five specified in-memory fault experiments apply 1,760 record checks; all five faults are detected. Neither the review nor those mutations constitute exhaustive proof.

Regeneration commands and dependency/platform conditions are in [reproducibility](../REPRODUCIBILITY.md). Preserve the release manifest before regenerating the master or numerical observations. All examples and source articles remain local artifacts, and no dataset operation contacts a remote execution site.
