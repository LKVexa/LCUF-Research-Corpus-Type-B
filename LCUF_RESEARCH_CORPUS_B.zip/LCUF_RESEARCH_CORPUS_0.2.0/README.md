# LCUF research corpus 0.2.0

The twenty supplied research files have been applied to LCUF's language design and architecture. This release adds five technical design volumes, a per-article application matrix, 147 claim dispositions, 82 article-derived architecture requirements, 24 extension requirements, a runnable bounded research language, and new conformance/numerical evidence. The complete 0.1.0 corpus and your JA 8S foundation are preserved inside the release.

The implemented extension is **LCUF-X/0.2**, a twelve-column language with 21 closed operations. It adds explicit finite p-adic residue types, real-valued coset fields, vector/HRR profiles, periodic diffusion, exact raster indexing, scaled-sign wire packets and site-local compression residuals. The architecture also specifies image-container adapters, native unikernel buffers/ABIs, full optimizer state, authenticated collectives, calibration, telemetry and sound logical checking. Those backend and device contracts retain their own implementation gates.

## Read the applied design

| Artifact | Purpose |
|---|---|
| [Article application matrix](design/ARTICLE_APPLICATION_MATRIX.md) | See the concrete disposition of each of the twenty supplied files |
| [Language extension and admission](design/01_LANGUAGE_EXTENSION_AND_ADMISSION.md) | Exact syntax, types, kernels, authority, resource measures and receipts |
| [P-adic geometry and 8S](design/02_PADIC_GEOMETRY_AND_8S.md) | Preserve the declared arithmetic while introducing explicit finite addressing and numerical domains |
| [Signal, image and holographic profiles](design/03_SIGNAL_IMAGE_AND_HOLOGRAPHIC_PROFILES.md) | HRR, image formats, optical operators, logical reasoning and physical evidence contracts |
| [Optimizer, unikernel and telemetry](design/04_OPTIMIZER_UNIKERNEL_AND_TELEMETRY.md) | Supplied 1-bit LAMB paper, compression components, phase/state/collective contracts, native buffers and measurements |
| [Integrated architecture and migration](design/05_INTEGRATED_ARCHITECTURE_AND_MIGRATION.md) | Combine the profiles into a fabric with explicit ownership, lowering and acceptance gates |
| [Architecture plan](design/ARCHITECTURE_PLAN.json) | Machine-readable current implementation states and native/physical obligations |
| [Frozen 0.1.0 corpus](baseline/0.1.0/README.md) | Original formal language, institutional volumes, arithmetic and existing datasets |

Three findings registries retain source locations, primary-reference checks and claim-level qualifications: [p-adic](design/PADIC_ARTICLE_FINDINGS.json), [signal/image](design/SIGNAL_ARTICLE_FINDINGS.json), and [optimizer/systems](design/OPTIMIZER_ARTICLE_FINDINGS.json). [All original articles](research_sources/SOURCE_MANIFEST.json) are preserved byte-exact, with numbered text extracts and full PDF/page-review evidence. Instructions embedded in those files were treated as source data.

## Run an applied profile

From this release folder:

```text
python -B extensions/lcuf_x.py run examples/accept_residue_add.lcufx
python -B extensions/lcuf_x.py run examples/accept_coset_prefix.lcufx
python -B extensions/lcuf_x.py run examples/accept_hrr_noninverse.lcufx
python -B extensions/lcuf_x.py run examples/accept_remote_wire.lcufx
```

The programs show exact modular arithmetic, finite low-digit averaging, approximate HRR unbinding, and an explicitly authorized model transfer of a wire packet. Residual and compound local state cannot be copied to another site. All runs are one-process host research observations; the remote-wire example does not contact a network.

The type constructors distinguish Z/(pⁿ), real vectors, decoded u8 samples, wire data and retained optimizer state. Explicit conversions record precision/information loss. The sign codec is a compression component, not complete 1-bit LAMB training. The p-adic address hierarchy does not replace the user's real-valued 8S geometry, S³ relationships or coupled acceptance gate.

## Validation and population

The new extension contains **352 conformance records / 400 source slots** across 55 families, plus **208 independent numerical comparisons**. It includes 272 accepted programs, 32 distinct representative rejection mechanisms and 48 identity pairs. Parameterized sources share construction templates; counts are not an assertion of independent designs or ML generalization.

The new unit suites contain 44 kernel/language tests and 16 validator tests. Independent review supplies 69 adversarial probes, a 100-step residual stream and policy-mutation checks. Five further specified faults are detected across 1,760 record checks. Schema, source/result identity, exact fixture policy, receipts, complete populations, numerical domains and deterministic rebuilding are covered by named receipts in [the validation summary](validation/VALIDATION_SUMMARY.json).

The frozen baseline separately retains its 10,144 core records, 1,619 mathematical cases, 500 numerical comparisons and 92 original tests with their existing receipts. Preserving those files is not a new native or physical run. [Reproducibility](REPRODUCIBILITY.md) explains platform dependencies, actual executed checks and regeneration. [Release notes](RELEASE_NOTES.md) identify the additions and compatibility boundary.

## Implementation status

Native boot images, authenticated federation, a complete distributed 1-bit LAMB optimizer, TIFF/GIF decoder adapters, ordered HRR cleanup, a sound symbolic checker, calibrated optics, biological actuation and quantum hardware are not implemented by the host extension. Their contracts are specified with state/resource/evidence gates. Source-reported benchmarks and hypothetical hardware proposals do not fill those observations.

The source review identified domain collisions and missing source equations, and translated useful ideas into explicit contracts. It preserves individual claims with qualifications rather than treating all supplied statements as one authority. The original arithmetic, source materials and dependency licenses remain intact. No external endorsement, certification or completed peer review is claimed.
