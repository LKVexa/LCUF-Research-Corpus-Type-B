# LCUF 0.2 applied research release notes

This release applies twenty user-supplied text/PDF research files to LCUF and retains the complete frozen 0.1.0 release under `baseline/0.1.0/`. Original articles and the user's JA 8S reference are preserved; the earlier scalar compiler and arithmetic implementation are unchanged.

Five new design volumes connect finite p-adic representations, holographic/vector operations, scientific image/storage contracts, diffusion, optimizer compression, native buffers, federation and telemetry. A twenty-file application matrix and three findings registries retain 147 claim dispositions, exact source locations, primary-reference checks and 82 architecture requirements. Missing equations and unsupported generalizations remain visible qualifications.

The new **LCUF-X/0.2** frontend retains twelve explicit columns and supplies 21 bounded operations, including fifteen additional profile operations. It introduces finite residue/field types, vectors, u8 rasters, packets and site-local residual/compound state; rejects implicit domain changes; and checks per-row modeled work plus retained payload/peak modeled scratch before evaluation. Canonical IR binds the reference implementation; local receipts retain exact origin/result scope.

New evidence includes 352 source records, 208 independent numerical comparisons, 60 unit tests, an independent 69-probe/100-step residual review and five detected fault experiments. Rejection mechanisms have one representative record each; repeated module names are not used to inflate that population. Numerical and property checks retain their domains and tolerances.

The implemented RMS-sign codec and phase guard are distinct from full distributed 1-bit LAMB. Native image construction, authenticated collectives, complete optimizer updates, image-format decoders, ordered cleanup/sound logic and physical devices remain specified development contracts. The architecture explicitly distinguishes compression LCTL from the user's column language and image GIF from Gaussian Interaction Frames.

Version selection is explicit: a program with header LCUF/0.1 goes to the frozen compiler; a program with LCUF-X/0.2 goes to the experimental extension. No inherited source silently gains a new operation or mathematical interpretation. Source and dependency rights remain as supplied; there is no umbrella relicensing, external institutional endorsement or completed peer review claim.
