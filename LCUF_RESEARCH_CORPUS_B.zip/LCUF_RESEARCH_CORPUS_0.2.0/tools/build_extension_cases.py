"""Construct independent bounded golden cases for the article-derived profiles."""
from __future__ import annotations
import base64,collections,hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'extensions'))
import lcuf_x as X
HEADER='LCUF-X/0.2'
COLUMNS=['id','site','profile','op','inputs','output','type','effects','caps','after','budget','evidence']
# Fixture policy is independent of the target compiler's mutable tables.
EXPECTED_OPS={
 'const':('lcuf.scalar',0),'add':('lcuf.scalar',2),'mul':('lcuf.scalar',2),
 'copy':('lcuf.fabric',1),'assert_eq':('lcuf.test',2),'emit':('lcuf.evidence',1),
 'padic_add':('lcuf.padic.finite',2),'padic_mul':('lcuf.padic.finite',2),
 'padic_val':('lcuf.padic.finite',1),'padic_reduce':('lcuf.padic.finite',1),'padic_from_i64':('lcuf.padic.finite',1),
 'padic_average':('lcuf.padic.field',2),'hrr_bind':('lcuf.hrr.real',2),
 'hrr_correlate':('lcuf.hrr.real',2),'permute':('lcuf.hrr.real',2),
 'diffuse_step':('lcuf.diffusion.periodic',2),'raster_shift':('lcuf.image.u8',2),
 'ef_pack':('lcuf.compression.component',2),'ef_wire':('lcuf.compression.component',1),
 'ef_residual':('lcuf.compression.component',1),'sign_decode':('lcuf.compression.component',1)}
EXPECTED_AUTHORITY={'copy':({'fabric.transfer'},{'fabric.receive'}),'emit':({'evidence.emit'},{'evidence.write'}),
 'ef_pack':({'optimizer.local_state'},{'optimizer.state'}),'ef_wire':({'optimizer.local_state'},{'optimizer.state'}),'ef_residual':({'optimizer.local_state'},{'optimizer.state'})}

def dump(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def row(rid,op,inputs,out,t='i64',site='s',budget=4096,evidence='none',effects=None,caps=None):
    want_effects,want_caps=EXPECTED_AUTHORITY.get(op,(set(),set()))
    return ' | '.join(map(str,[rid,site,EXPECTED_OPS[op][0],op,inputs,out,t,','.join(sorted(want_effects)) or '-' if effects is None else effects,','.join(sorted(want_caps)) or '-' if caps is None else caps,'-',budget,evidence]))
def literal(value):return json.dumps(value,ensure_ascii=False,allow_nan=False).replace('|','\\u007c')
def const(rid,out,value,t='i64',site='s'):return row(rid,'const',literal(value),out,t,site)
def program(name,rows,remote=False,grant=True,memory=1000000):
    lines=[HEADER,'module '+name,f'site s trust=local memory={memory} steps=1000000']
    if remote:lines.append(f'site t trust=peer memory={memory} steps=1000000')
    if grant:lines.append('grant s caps=evidence.write,optimizer.state'+(',fabric.send' if remote else ''))
    if remote:lines.extend(['grant t caps=fabric.receive,evidence.write,optimizer.state','link s t transfer=copy'])
    return ('\n'.join(lines+[' | '.join(COLUMNS)]+rows+['end',''])).encode('utf-8')
def observation(raw):
    try:return X.run_source(raw)
    except (X.Diagnostic,ValueError,UnicodeError) as error:return {'status':'rejected','diagnostic':str(error)}
def bound(raw):
    try:text=raw.decode('utf-8')
    except UnicodeError:text=None
    return {'bytes_base64':base64.b64encode(raw).decode('ascii'),'utf8_text':text,'sha256':hashlib.sha256(raw).hexdigest()}
def equal(a,b):
    if type(a) is not type(b):return False
    if type(a) is float:return abs(a-b)<=2e-13+2e-13*max(abs(a),abs(b))
    if type(a) is list:return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    if type(a) is dict:return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
    return a==b

def positive(family,v):
    name=f'{family}_{v}';a=v+1
    if family in ('residue_add','residue_mul'):
        p,n=3,3;m=27;x=(v*5+20)%m;y=(v*7+15)%m;op='padic_add' if family=='residue_add' else 'padic_mul'
        rows=[const('a','x',x,'Zp[3,3]'),const('b','y',y,'Zp[3,3]'),row('c',op,'x,y','result','Zp[3,3]',evidence='receipt')];value=(x+y)%m if op=='padic_add' else (x*y)%m
    elif family=='explicit_signed_conversion':
        x=-a;rows=[const('a','x',x),row('b','padic_from_i64','x','result','Zp[2,4]')];value=x%16
    elif family=='capped_valuation':
        x=0 if v==0 else 3**(v%4);rows=[const('a','x',x,'Zp[3,4]'),row('b','padic_val','x','result')];value=4 if v==0 else v%4
    elif family=='precision_reduction':
        x=v+16;rows=[const('a','x',x,'Zp[2,5]'),row('b','padic_reduce','x','result','Zp[2,3]')];value=x%8
    elif family in ('coset_global','coset_prefix','coset_identity'):
        k={'coset_global':0,'coset_prefix':1,'coset_identity':3}[family];xs=[float(i+a) for i in range(8)]
        rows=[const('a','x',xs,'PField[2,3]'),const('b','k',k),row('c','padic_average','x,k','result','PField[2,3]')]
        value=[a+3.5]*8 if k==0 else [float(a+3+i%2) for i in range(8)] if k==1 else xs
    elif family in ('hrr_basis_bind','hrr_basis_correlation'):
        xs=[float(a),float(a+1),float(a+2),float(a+3)];shift=v%4;key=[float(i==shift) for i in range(4)]
        op='hrr_bind' if family=='hrr_basis_bind' else 'hrr_correlate';rows=[const('a','x',xs,'Vec[f64,4]'),const('b','k',key,'Vec[f64,4]'),row('c',op,'x,k','result','Vec[f64,4]')]
        value=[xs[(i-shift)%4] for i in range(4)] if op=='hrr_bind' else [xs[(i+shift)%4] for i in range(4)]
    elif family=='hrr_noninverse':
        xs=[float(a),0.0,float(2*a),0.0];key=[1.0,1.0,0.0,0.0]
        rows=[const('a','x',xs,'Vec[f64,4]'),const('b','k',key,'Vec[f64,4]'),row('c','hrr_bind','x,k','bound','Vec[f64,4]'),row('d','hrr_correlate','bound,k','result','Vec[f64,4]')];value=[float(2*a),float(3*a),float(4*a),float(3*a)]
    elif family=='cyclic_permutation':
        xs=[float(a+i) for i in range(4)];shift=v-8;rows=[const('a','x',xs,'Vec[f64,4]'),const('b','k',shift),row('c','permute','x,k','result','Vec[f64,4]')];value=[xs[(i-shift)%4] for i in range(4)]
    elif family=='periodic_convex_diffusion':
        xs=[float(a),0.0,0.0,0.0];rows=[const('a','x',xs,'Vec[f64,4]'),const('b','alpha',0.25,'f64'),row('c','diffuse_step','x,alpha','result','Vec[f64,4]')];value=[a/2,a/4,0.0,a/4]
    elif family=='exact_raster_translation':
        xs=[v,v+1,v+2,v+3];rows=[const('a','x',xs,'Raster[u8,2,2,1]'),const('b','k',1),row('c','raster_shift','x,k','result','Raster[u8,2,2,1]')];value=[v+1,v,v+3,v+2]
    elif family in ('sign_packet_decode','local_residual','remote_wire'):
        xs=[float(a),0.0,0.0,0.0];rows=[const('a','x',xs,'Vec[f64,4]'),const('b','r',[0,0,0,0],'Residual[4]'),row('c','ef_pack','x,r','bundle','EFBundle[4]',evidence='receipt')]
        if family=='local_residual':rows.append(row('d','ef_residual','bundle','result','Residual[4]'));value=[a/2,-a/2,-a/2,-a/2]
        else:
            rows.append(row('d','ef_wire','bundle','wire','SignPacket[4]'))
            if family=='remote_wire':rows.append(row('e','copy','wire','remote','SignPacket[4]',site='t',evidence='receipt'));packet='remote';site='t'
            else:packet='wire';site='s'
            rows.append(row('f','sign_decode',packet,'result','Vec[f64,4]',site=site));value=[a/2]*4
    else:raise ValueError(family)
    return program(name,rows,remote=family=='remote_wire'),{'result':value}

POSITIVE=['residue_add','residue_mul','explicit_signed_conversion','capped_valuation','precision_reduction','coset_global','coset_prefix','coset_identity','hrr_basis_bind','hrr_basis_correlation','hrr_noninverse','cyclic_permutation','periodic_convex_diffusion','exact_raster_translation','sign_packet_decode','local_residual','remote_wire']
NEGATIVE=['composite_radix','excess_precision','noncanonical_residue','boolean_residue','implicit_refinement','radix_mismatch','float_overflow_literal','boolean_float','vector_empty','vector_shape','vector_limit','negative_raster_sample','large_raster_sample','raster_shape','nonzero_residual_literal','residual_transfer','bundle_transfer','missing_state_grant','erased_state_effect','diffusion_unstable_step','hrr_shape_mismatch','packet_literal','kernel_work_underreserve','payload_scratch_underreserve','missing_directed_link','missing_sender','missing_receiver','duplicate_writer','dependency_cycle','unsupported_physical_op','wrong_language_header','invalid_utf8']
DIAGNOSTICS=['prime radix','precision','canonical residue','integer required','reduction','equal radix','finite binary64','finite real','vector shape','vector shape','vector length','u8 raster','u8 raster','u8 raster','zero initial','owner-affine','owner-affine','capability','capability','alpha','vector operands','packet literals','modeled minimum','peak scratch','transfer/sender','transfer/sender','capability','multiple output','cycle','unsupported operation','required header','UTF-8']
def negative(family,v):
    name=f'{family}_{v}';rows=[const('a','x',1,'Zp[3,3]')];remote=False;grant=True;memory=1000000
    if family=='composite_radix':rows=[const('a','x',1,'Zp[4,3]')]
    elif family=='excess_precision':rows=[const('a','x',1,'Zp[2,17]')]
    elif family=='noncanonical_residue':rows=[const('a','x',27,'Zp[3,3]')]
    elif family=='boolean_residue':rows=[const('a','x',True,'Zp[3,3]')]
    elif family=='implicit_refinement':rows.append(row('b','padic_reduce','x','result','Zp[3,4]'))
    elif family=='radix_mismatch':rows.extend([const('b','y',1,'Zp[2,3]'),row('c','padic_add','x,y','result','Zp[3,3]')])
    elif family=='float_overflow_literal':rows=[row('a','const','1e999','x','f64')]
    elif family=='boolean_float':rows=[const('a','x',True,'f64')]
    elif family in ('vector_empty','vector_shape','vector_limit'):
        xs=[] if family=='vector_empty' else [1,2] if family=='vector_shape' else [0]*257;t='Vec[f64,4]' if family!='vector_limit' else 'Vec[f64,257]';rows=[const('a','x',xs,t)]
    elif family in ('negative_raster_sample','large_raster_sample','raster_shape'):
        xs=[-1,0,0,0] if family=='negative_raster_sample' else [256,0,0,0] if family=='large_raster_sample' else [0];rows=[const('a','x',xs,'Raster[u8,2,2,1]')]
    elif family=='nonzero_residual_literal':rows=[const('a','x',[1,0,0,0],'Residual[4]')]
    elif family in ('residual_transfer','bundle_transfer'):
        rows=[const('a','x',[1,0,0,0],'Vec[f64,4]'),const('b','r',[0]*4,'Residual[4]')];remote=True
        if family=='bundle_transfer':rows.append(row('c','ef_pack','x,r','bundle','EFBundle[4]'));inp,t='bundle','EFBundle[4]'
        else:inp,t='r','Residual[4]'
        rows.append(row('d','copy',inp,'result',t,site='t'))
    elif family in ('missing_state_grant','erased_state_effect'):
        rows=[const('a','x',[1,0,0,0],'Vec[f64,4]'),const('b','r',[0]*4,'Residual[4]'),row('c','ef_pack','x,r','result','EFBundle[4]',effects='-' if family=='erased_state_effect' else None)];grant=family!='missing_state_grant'
    elif family=='diffusion_unstable_step':rows=[const('a','x',[1,0,0,0],'Vec[f64,4]'),const('b','alpha',0.5001,'f64'),row('c','diffuse_step','x,alpha','result','Vec[f64,4]')]
    elif family=='hrr_shape_mismatch':rows=[const('a','x',[1]*4,'Vec[f64,4]'),const('b','y',[1]*3,'Vec[f64,3]'),row('c','hrr_bind','x,y','result','Vec[f64,4]')]
    elif family=='packet_literal':rows=[const('a','x',{},'SignPacket[4]')]
    elif family=='kernel_work_underreserve':rows=[const('a','x',[1]*4,'Vec[f64,4]'),row('b','hrr_bind','x,x','result','Vec[f64,4]',budget=15)]
    elif family=='payload_scratch_underreserve':rows=[const('a','x',[1]*4,'Vec[f64,4]'),row('b','hrr_bind','x,x','result','Vec[f64,4]')];memory=95
    elif family in ('missing_directed_link','missing_sender','missing_receiver'):
        rows=[const('a','x',v+1),row('b','copy','x','result',site='t')];remote=True
    elif family=='duplicate_writer':rows.append(const('b','x',2))
    elif family=='dependency_cycle':rows=[row('a','add','y,y','x'),row('b','add','x,x','y')]
    elif family=='unsupported_physical_op':rows=[row('a','const','1','x') .replace(' | const | ',' | optical_propagate | ')]
    raw=program(name,rows,remote,grant,memory)
    if family=='missing_directed_link':raw=raw.replace(b'link s t transfer=copy\n',b'')
    elif family=='missing_sender':raw=raw.replace(b',fabric.send',b'')
    elif family=='missing_receiver':raw=raw.replace(b'caps=fabric.receive,',b'caps=')
    elif family=='wrong_language_header':raw=raw.replace(HEADER.encode(),b'LCUF/0.1',1)
    elif family=='invalid_utf8':raw=b'\xff'+raw
    return raw,DIAGNOSTICS[NEGATIVE.index(family)]

METAMORPHIC=['comments','crlf','bom','cell_spacing','row_order','typed_float_literal_normalization']
def annotations(family):
    rule_overrides={
      'residue_add':['X-003'],'residue_mul':['X-003'],'explicit_signed_conversion':['X-004'],
      'capped_valuation':['X-005'],'precision_reduction':['X-004'],
      'composite_radix':['X-002','X-003'],'excess_precision':['X-002','X-003'],
      'noncanonical_residue':['X-003'],'boolean_residue':['X-003','X-021'],
      'implicit_refinement':['X-004'],'radix_mismatch':['X-003'],
      'hrr_basis_bind':['X-008'],'hrr_basis_correlation':['X-009'],'hrr_noninverse':['X-009'],
      'cyclic_permutation':['X-010'],'hrr_shape_mismatch':['X-002','X-008'],
      'sign_packet_decode':['X-013'],'local_residual':['X-014'],'remote_wire':['X-013','X-019'],
      'nonzero_residual_literal':['X-014'],'residual_transfer':['X-014'],'bundle_transfer':['X-014'],
      'missing_state_grant':['X-018'],'erased_state_effect':['X-018'],'packet_literal':['X-013'],
      'missing_directed_link':['X-019'],'missing_sender':['X-019'],'missing_receiver':['X-018','X-019'],
      'duplicate_writer':['X-017'],'dependency_cycle':['X-017'],
      'float_overflow_literal':['X-021'],'boolean_float':['X-021'],
      'vector_empty':['X-002'],'vector_shape':['X-002'],'vector_limit':['X-002'],
      'wrong_language_header':['X-001','X-023'],'invalid_utf8':['X-001'],
      'comments':['X-022'],'crlf':['X-022'],'bom':['X-022'],'cell_spacing':['X-022'],
      'row_order':['X-017','X-022'],'typed_float_literal_normalization':['X-021','X-022']}
    articles,requirements=article_group(family)
    return articles,rule_overrides.get(family,requirements)
def article_group(family):
    if family in ('residue_add','residue_mul','capped_valuation','explicit_signed_conversion','precision_reduction','composite_radix','excess_precision','noncanonical_residue','boolean_residue','implicit_refinement','radix_mismatch'):
        return ['ART-03','ART-04','ART-05','ART-06','ART-07','ART-11'],['X-003','X-004','X-005']
    if family.startswith('coset_'):return ['ART-04','ART-05','ART-06'],['X-007']
    if family.startswith(('hrr_','cyclic_')):return ['ART-15','ART-18'],['X-008','X-009','X-010']
    if 'raster' in family:return ['ART-03','ART-07','ART-16','ART-19','ART-20'],['X-012']
    if family in ('periodic_convex_diffusion','diffusion_unstable_step'):return ['ART-01','ART-04','ART-05','ART-06'],['X-011']
    if family in ('sign_packet_decode','local_residual','remote_wire','nonzero_residual_literal','residual_transfer','bundle_transfer','missing_state_grant','erased_state_effect','packet_literal'):
        return ['ART-02','ART-08','ART-10','ART-11','ART-14'],['X-013','X-014','X-018','X-019']
    if 'underreserve' in family:return ['ART-08','ART-09','ART-10','ART-14'],['X-020']
    if family=='unsupported_physical_op':return ['ART-01','ART-12','ART-13','ART-17'],['X-024']
    return ['ART-08'],['X-001','X-002','X-017','X-021','X-022','X-023']
def paired(family,v):
    raw,values=positive('hrr_basis_bind',v)
    if family=='comments':other=raw.replace(b'module ',b'# explanation\nmodule ',1)
    elif family=='crlf':other=raw.replace(b'\n',b'\r\n')
    elif family=='bom':other=b'\xef\xbb\xbf'+raw
    elif family=='cell_spacing':other=raw.replace(b' | ',b'|')
    elif family=='row_order':
        lines=raw.decode().splitlines();start=next(i for i,x in enumerate(lines) if x.startswith('id |'));other=('\n'.join(lines[:start+1]+list(reversed(lines[start+1:-1]))+[lines[-1]])+'\n').encode()
    else:other=raw.replace(b'.0',b'')
    return raw,other,values

def build():
    records=[];examples=[]
    for kind,families,variants in [('accept',POSITIVE,16),('reject',NEGATIVE,1),('metamorphic',METAMORPHIC,8)]:
        for family in families:
            for v in range(variants):
                if kind=='accept':raw,values=positive(family,v);expected={'kind':kind,'values':values}
                elif kind=='reject':raw,diagnostic=negative(family,v);expected={'kind':kind,'diagnostic_contains':diagnostic}
                else:raw,other,values=paired(family,v);expected={'kind':kind,'values':values,'semantic_equal':True,'source_different':True}
                observed=observation(raw)
                if kind=='reject':ok=observed['status']=='rejected' and expected['diagnostic_contains'] in observed['diagnostic']
                else:ok=observed['status']=='host_research_pass' and all(k in observed['values'] and equal(val,observed['values'][k]) for k,val in values.items())
                articles,requirements=annotations(family)
                record={'id':f'LX-{len(records)+1:06d}','family':family,'variant':v,'article_ids':articles,'requirement_ids':requirements,'language':HEADER,'source':bound(raw),'expected':expected,'observed':observed,'verification':'PASS' if ok else 'FAIL','scope':'single_process_host_research','native_eligible':False}
                if kind=='metamorphic':
                    record['paired_source']=bound(other);record['paired_observed']=observation(other);paired_obs=record['paired_observed']
                    ok=ok and paired_obs['status']=='host_research_pass' and observed['semantic_sha256']==paired_obs['semantic_sha256'] and observed['source_sha256']!=paired_obs['source_sha256'];record['verification']='PASS' if ok else 'FAIL'
                if not ok:raise AssertionError(json.dumps(record,indent=2))
                records.append(record)
                if v==0:
                    path=ROOT/'examples'/f'{kind}_{family}.lcufx';path.write_bytes(raw);examples.append(path.relative_to(ROOT).as_posix())
    master=ROOT/'datasets/extension_conformance.jsonl'
    master.write_text(''.join(json.dumps(r,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n' for r in records),encoding='utf-8')
    counts=collections.Counter(r['expected']['kind'] for r in records)
    report={'status':'PASS','master_records':len(records),'source_evaluation_slots':len(records)+counts['metamorphic'],'counts':dict(counts),'families':len(POSITIVE)+len(NEGATIVE)+len(METAMORPHIC),'family_variants':{'accept':16,'reject':1,'metamorphic':8},'sha256':hashlib.sha256(master.read_bytes()).hexdigest(),'kernel_source_sha256':hashlib.sha256((ROOT/'extensions/math_kernels.py').read_bytes()).hexdigest(),'compiler_source_sha256':hashlib.sha256((ROOT/'extensions/lcuf_x.py').read_bytes()).hexdigest(),'scope':'Deterministic synthetic bounded host golden cases; no independent native/physical/optimizer evidence.'}
    dump(ROOT/'validation/EXTENSION_BUILD.json',report);dump(ROOT/'examples/INDEX.json',examples);print(json.dumps(report,indent=2))

if __name__=='__main__':build()
