"""Independent optional numerical comparisons for bounded extension kernels."""
import fractions,hashlib,json,math,pathlib,platform,sys
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'extensions'))
import math_kernels as K
import numpy as np

def run():
    rng=np.random.default_rng(82109);records=[]
    def add(family,inputs,observed,expected,method):
        actual=np.asarray(observed,dtype=np.float64);golden=np.asarray(expected,dtype=np.float64)
        maximum=float(np.max(np.abs(actual-golden)))
        passed=bool(np.allclose(actual,golden,rtol=2e-13,atol=2e-13))
        if not passed:raise AssertionError((family,maximum))
        records.append({'id':f'NX-{len(records)+1:06d}','family':family,'inputs':inputs,'host_output':observed,'independent_output':golden.tolist(),'oracle':method,'absolute_tolerance':2e-13,'relative_tolerance':2e-13,'maximum_absolute_difference':maximum,'status':'PASS','scope':'finite_host_numerical_comparison'})
    for n in [1,2,3,4,5,8,16,32]:
        for variant in range(8):
            a=rng.normal(0,.5,n).tolist();b=rng.normal(0,.5,n).tolist();fa=np.fft.fft(a);fb=np.fft.fft(b)
            add('hrr_fft_bind',{'a':a,'b':b},K.hrr_bind(a,b),np.fft.ifft(fa*fb).real,'Independent complex NumPy FFT convolution, inverse normalization by NumPy')
            add('hrr_fft_correlation',{'bound':a,'key':b},K.hrr_correlate(a,b),np.fft.ifft(fa*np.conj(fb)).real,'Independent complex NumPy FFT correlation')
    F=fractions.Fraction
    for variant in range(32):
        p,n=(2,3) if variant%2==0 else (3,3);m=p**n;k=variant%(n+1);xs=[int(x)/2 for x in rng.integers(-8,9,m)]
        q=m//(p**k);golden=[float(sum((F(xs[j]) for j in range(i%(p**k),m,p**k)),F(0))/q) for i in range(m)]
        add('finite_coset_fraction',{'p':p,'n':n,'k':k,'samples':xs},K.padic_average(xs,p,n,k),golden,'Exact rational conditional averages converted once to binary64')
    for variant in range(32):
        n=[1,2,4,8][variant%4];alpha=[0,.125,.25,.5][variant//4%4];xs=[int(x)/2 for x in rng.integers(-8,9,n)]
        a=F(alpha);golden=[float((1-2*a)*F(xs[i])+a*F(xs[(i-1)%n])+a*F(xs[(i+1)%n])) for i in range(n)]
        add('periodic_diffusion_fraction',{'alpha':alpha,'samples':xs},K.diffuse_step(xs,alpha),golden,'Exact rational stencil evaluation with periodic indices')
    for variant in range(16):
        n=[1,2,3,4,8,16,32,256][variant%8];xs=rng.normal(0,.5,n).tolist();res=rng.normal(0,.05,n).tolist();z=np.asarray(xs)+res;s=float(np.linalg.norm(z)/np.sqrt(n));golden=np.where(z>=0,s,-s)
        bundle=K.sign_pack(xs,res);add('rms_sign_numpy',{'samples':xs,'residual':res},K.sign_decode(bundle['wire']),golden,'Independent NumPy norm and sign reconstruction on well-scaled finite inputs')
    path=ROOT/'datasets/numerical_crosschecks.jsonl';path.write_text(''.join(json.dumps(r,separators=(',',':'),allow_nan=False)+'\n' for r in records),encoding='utf-8')
    counts={family:sum(r['family']==family for r in records) for family in sorted({r['family'] for r in records})}
    report={'status':'PASS','checks':len(records),'family_counts':counts,'seed':82109,'numpy_version':np.__version__,'python':platform.python_version(),'platform':platform.platform(),'dataset_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'kernel_sha256':hashlib.sha256((ROOT/'extensions/math_kernels.py').read_bytes()).hexdigest(),'maximum_absolute_difference':max(r['maximum_absolute_difference'] for r in records),'absolute_tolerance':2e-13,'relative_tolerance':2e-13,'fresh_numpy_execution':True,'scope':'Independent algorithm/rational comparisons on selected bounded host inputs; not full optimizer, device, native, continuous p-adic or physical evidence.'}
    (ROOT/'validation/NUMERICAL_CROSSCHECKS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2))

if __name__=='__main__':run()
