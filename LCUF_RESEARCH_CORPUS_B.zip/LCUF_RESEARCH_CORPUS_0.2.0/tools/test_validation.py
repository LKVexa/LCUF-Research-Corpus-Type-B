import copy,json,pathlib,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'tools'))
import validate_extensions as V

class ValidatorEvidence(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records=[V.strict_json(x) for x in (ROOT/'datasets/extension_conformance.jsonl').read_text(encoding='utf-8').splitlines()]
        cls.schema=V.strict_json((ROOT/'schemas/extension_record.schema.json').read_text(encoding='utf-8'));cls.validator=V.jsonschema.Draft202012Validator(cls.schema)
    def sample(self,family):return copy.deepcopy(next(r for r in self.records if r['family']==family))
    def reject(self,record):self.assertTrue(V.check_record(record,self.validator))
    def test_complete_population(self):self.assertFalse(V.population(self.records))
    def test_empty_population(self):self.assertTrue(V.population([]))
    def test_truncated_population(self):self.assertTrue(V.population(self.records[:-1]))
    def test_changed_source_hash(self):
        r=self.sample('residue_add');r['source']['sha256']='0'*64;self.reject(r)
    def test_changed_text_projection(self):
        r=self.sample('residue_add');r['source']['utf8_text']+='\n';self.reject(r)
    def test_forged_native_claim(self):
        r=self.sample('residue_add');r['observed']['native_unikernel_built']=True;self.reject(r)
    def test_bool_integer_alias(self):
        r=self.sample('residue_add');r['observed']['values']['result']=True;self.reject(r)
    def test_forged_receipt_result(self):
        r=self.sample('remote_wire');r['observed']['receipts'][0]['result_sha256']='0'*64;self.reject(r)
    def test_bad_metamorphic_pair(self):
        r=self.sample('comments');r['paired_observed']['semantic_sha256']='0'*64;self.reject(r)
    def test_unknown_requirement(self):
        r=self.sample('residue_add');r['requirement_ids']=['X-999'];self.reject(r)
    def test_unknown_article(self):
        r=self.sample('residue_add');r['article_ids']=['ART-99'];self.reject(r)
    def test_family_label_swap(self):
        rows=copy.deepcopy(self.records);a=next(r for r in rows if r['family']=='residue_add');b=next(r for r in rows if r['family']=='residue_mul');a['family'],b['family']=b['family'],a['family'];self.reject(a);self.assertTrue(V.population(rows))
    def test_source_and_oracle_replacement(self):
        r=self.sample('residue_add');raw=V.B.program('replacement',[V.B.const('a','result',999)]);r['source']=V.B.bound(raw);r['observed']=V.B.observation(raw);r['expected']['values']={'result':999};self.reject(r)
    def test_regenerated_zero_hash_observation(self):
        r=self.sample('residue_add');raw=V.decoded(r['source']);saved=V.X.digest
        try:
            V.X.digest=lambda value:'0'*64;r['observed']=V.B.observation(raw);self.reject(r)
        finally:V.X.digest=saved
    def test_duplicate_json(self):
        with self.assertRaises(ValueError):V.strict_json('{"x":1,"x":2}')
    def test_nonfinite_json(self):
        with self.assertRaises(ValueError):V.strict_json('{"x":NaN}')

if __name__=='__main__':unittest.main()
