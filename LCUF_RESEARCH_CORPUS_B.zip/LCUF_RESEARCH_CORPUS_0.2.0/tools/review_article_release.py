"""Review navigation, source identity, evidence bindings and research-plan consistency."""
import ast,hashlib,json,pathlib,re,sys,urllib.parse
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'tools'))
import validate_extensions as V
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return V.strict_json(p.read_text(encoding='utf-8-sig'))
def anchors(p):
    text=p.read_text(encoding='utf-8');result=set(re.findall(r'<a\s+(?:id|name)=["\']([^"\']+)',text));counts={}
    for heading in re.findall(r'^#{1,6}\s+(.+)$',text,re.M):
        base=re.sub(r'[^\w\- ]','',heading.lower()).replace(' ','-');n=counts.get(base,0);counts[base]=n+1;result.add(base+(f'-{n}' if n else ''))
    return result
def main():
    errors=[];links=0;manifest_files=0;pyfiles=0;bindings=0;jsonfiles=0
    def fail(context,error):errors.append({'context':context,'error':str(error)})
    def match(rel,expected,context):
        nonlocal bindings
        path=(ROOT/rel).resolve();bindings+=1
        if not path.is_relative_to(ROOT.resolve()) or not path.is_file() or sha(path)!=expected:fail(context,'file hash binding differs: '+rel)
    catalog=read(ROOT/'CORPUS_CATALOG.json')
    for entry in catalog['documents']:
        source=ROOT/entry['path'];match(entry['path'],entry['sha256'],'catalog');text=source.read_text(encoding='utf-8')
        if len(text.split())!=entry['words_whitespace_split']:fail(entry['path'],'word count changed')
        for m in re.finditer(r'!?\[[^\]\n]*\]\((<[^>]+>|[^\s)]+)(?:\s+["\'][^)]*)?\)',text):
            raw=m.group(1).strip('<>')
            if re.match(r'^[a-z][a-z0-9+.-]*:',raw,re.I):continue
            s=urllib.parse.urlsplit(raw);target=(source.parent/urllib.parse.unquote(s.path)).resolve() if s.path else source;links+=1
            if not target.is_relative_to(ROOT.resolve()) or not target.is_file():fail(entry['path'],'local link absent/outside package: '+raw)
            elif s.fragment and target.suffix=='.md' and urllib.parse.unquote(s.fragment) not in anchors(target):fail(entry['path'],'anchor absent: '+raw)
    if len(catalog['documents'])!=catalog['document_count'] or sum(d['primary_volume'] for d in catalog['documents'])!=catalog['primary_volume_count']:fail('catalog','population differs')
    for rel,base in [('specification/SPECIFICATION_MANIFEST.json','specification'),('research/RESEARCH_FILE_MANIFEST.json','research'),('mathematics/INVENTORY.json','mathematics'),('provenance/SELECTED_EVIDENCE_MANIFEST.json','provenance/upstream_snapshot')]:
        manifest=read(ROOT/'baseline/0.1.0'/rel)
        for e in manifest['files']:
            path=ROOT/'baseline/0.1.0'/base/e['path'];manifest_files+=1
            if not path.is_file() or path.stat().st_size!=e['bytes'] or sha(path)!=e['sha256']:fail(rel,'subcollection identity differs: '+e['path'])
        if len(manifest['files'])!=manifest['file_count']:fail(rel,'manifest count differs')
    for p in ROOT.rglob('*'):
        if not p.is_file():continue
        try:
            if p.suffix=='.json' and p.relative_to(ROOT).as_posix() not in {'RELEASE_MANIFEST.json','validation/RELEASE_VERIFICATION.json','validation/ARTIFACT_REVIEW.json'}:read(p);jsonfiles+=1
            if p.suffix=='.py' and 'vendor' not in p.parts and 'upstream_snapshot' not in p.parts:ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p));pyfiles+=1
        except (ValueError,SyntaxError,UnicodeError) as error:fail(p.relative_to(ROOT).as_posix(),error)
    source=read(ROOT/'research_sources/SOURCE_MANIFEST.json');matrix=read(ROOT/'design/ARTICLE_APPLICATION_MATRIX.json')
    if len(source['files'])!=20 or len(matrix['articles'])!=20:fail('sources','article population differs')
    for a,b in zip(source['files'],matrix['articles']):
        match(a['portable_path'],a['sha256'],'original source')
        if a['id']!=b['article_id'] or a['sha256']!=b['source_sha256'] or not set(b['implemented_host_operations'])<=set(V.X.OPS):fail(a['id'],'source-to-architecture mapping differs')
    try:
        schema=read(ROOT/'schemas/architecture_plan.schema.json');V.jsonschema.Draft202012Validator.check_schema(schema);V.jsonschema.Draft202012Validator(schema).validate(read(ROOT/'design/ARCHITECTURE_PLAN.json'))
    except Exception as error:fail('architecture plan',error)
    summary=read(ROOT/'validation/VALIDATION_SUMMARY.json')
    for entry in summary['observed']:
        match(entry['receipt'],entry['receipt_sha256'],'summary receipt');obj=read(ROOT/entry['receipt'])
        if obj.get('status')!='PASS':fail(entry['receipt'],'receipt not PASS')
    for name in ['PADIC_INTEGRATION_REVIEW.json','SIGNAL_INTEGRATION_REVIEW.json','INDEPENDENT_EXTENSION_REVIEW.json','VALIDATOR_INDEPENDENCE_REVIEW.json']:
        obj=read(ROOT/'validation'/name)
        for key in ['reviewed_artifacts','reviewed_documents','receipt_identities','evidence_receipts_consulted']:
            for e in obj.get(key,[]):match(e['path'],e['sha256'],name)
        for key in ['reviewed_source_sha256','reviewed_file_sha256']:
            for rel,value in obj.get(key,{}).items():match(rel,value,name)
        if obj.get('pending_assembly_links'):fail(name,'assembly links pending')
    unit=read(ROOT/'validation/UNIT_TESTS.json')
    for suite in unit['suites']:
        match(suite['source'],suite['source_sha256'],'unit suite source');match(suite['log'],suite['log_sha256'],'unit log')
        methods=sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse((ROOT/suite['source']).read_text(encoding='utf-8'))))
        if methods!=suite['tests']:fail(suite['source'],'test method count differs from receipt')
    result={'status':'PASS' if not errors else 'FAIL','curated_markdown_documents':catalog['document_count'],'curated_local_links_and_anchors_checked':links,'embedded_subcollection_manifest_files_checked':manifest_files,'authored_python_syntax_checked':pyfiles,'strict_json_files_checked':jsonfiles,'source_and_receipt_file_bindings_checked':bindings,'scope':'Curated navigation, embedded manifests, strict JSON/authored Python syntax, source/plan identity and review/summary bindings. Copied upstream internal navigation excluded. Semantic execution and external certification are outside this check.','errors':errors}
    (ROOT/'validation/ARTIFACT_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
