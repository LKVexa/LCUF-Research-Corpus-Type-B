"""Five explicit in-memory fault experiments; delivered reference files untouched."""
import json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'tools'))
import validate_extensions as V
X=V.X;K=X.K

def main():
    records=[V.strict_json(x) for x in (ROOT/'datasets/extension_conformance.jsonl').read_text(encoding='utf-8').splitlines()];validator=V.jsonschema.Draft202012Validator(V.strict_json((ROOT/'schemas/extension_record.schema.json').read_text(encoding='utf-8')))
    authority=X.authority;ops=X.OPS;add=K.residue_add;bind=K.hrr_bind;digest=X.digest
    def erase_wire():X.authority=lambda op:(set(),set()) if op=='ef_wire' else authority(op)
    def reassign_residual():X.OPS={**ops,'ef_residual':('lcuf.scalar',1)}
    def wrong_ring():K.residue_add=lambda a,b,p,n:(a-b)%(p**n)
    def reverse_bind():K.hrr_bind=K.hrr_correlate
    def zero_hashes():X.digest=lambda value:'0'*64
    experiments=[]
    for name,mutate in [('wire_authority_erased',erase_wire),('residual_profile_reassigned',reassign_residual),('ring_addition_replaced_by_subtraction',wrong_ring),('convolution_replaced_by_correlation',reverse_bind),('result_contract_hashes_suppressed',zero_hashes)]:
        try:
            mutate();detected=[r['id'] for r in records if V.check_record(r,validator)]
            experiments.append({'fault':name,'status':'DETECTED' if detected else 'MISSED','record_checks':len(records),'detecting_records':len(detected),'first_detecting_ids':detected[:8]})
        finally:X.authority=authority;X.OPS=ops;K.residue_add=add;K.hrr_bind=bind;X.digest=digest
    result={'status':'PASS' if all(x['status']=='DETECTED' for x in experiments) else 'FAIL','specified_faults':5,'record_checks':5*len(records),'experiments':experiments,'scope':'Sensitivity to five specified in-memory faults, including policy-table independence; not exhaustive mutation adequacy.'}
    (ROOT/'validation/EXTENSION_SENSITIVITY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2));raise SystemExit(0 if result['status']=='PASS' else 1)

if __name__=='__main__':main()
