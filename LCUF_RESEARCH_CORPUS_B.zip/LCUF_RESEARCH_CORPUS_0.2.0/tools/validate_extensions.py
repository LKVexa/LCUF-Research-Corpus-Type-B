"""Validate the complete finite research corpus against independent golden contracts."""
from __future__ import annotations
import argparse,base64,collections,hashlib,json,pathlib,platform,sys
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'extensions'));sys.path.insert(0,str(ROOT/'tools'))
if sys.platform=='win32' and sys.version_info[:2]==(3,12) and platform.machine().lower() in ('amd64','x86_64'):sys.path.insert(0,str(ROOT/'baseline/0.1.0/tools/vendor'))
import jsonschema
import lcuf_x as X
import build_extension_cases as B

def strict_json(raw):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise ValueError('duplicate JSON key')
            result[key]=value
        return result
    def invalid(value):raise ValueError('nonfinite JSON constant '+value)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=invalid)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(value):return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def decoded(source):
    raw=base64.b64decode(source['bytes_base64'],validate=True)
    if base64.b64encode(raw).decode('ascii')!=source['bytes_base64']:raise ValueError('noncanonical source base64')
    if hashlib.sha256(raw).hexdigest()!=source['sha256']:raise ValueError('source hash mismatch')
    try:text=raw.decode('utf-8')
    except UnicodeError:text=None
    if text!=source['utf8_text']:raise ValueError('source UTF-8 projection mismatch')
    return raw
def receipt_checks(raw,observed):
    if observed['status']!='host_research_pass':return
    compiled=X.compile_source(raw);ir=compiled['ir'];rows=[r for r in ir['rows'] if r['evidence']=='receipt'];previous='0'*64
    if hashlib.sha256(raw).hexdigest()!=observed['source_sha256'] or compiled['source_sha256']!=observed['source_sha256'] or digest(ir)!=observed['semantic_sha256'] or compiled['semantic_sha256']!=observed['semantic_sha256']:raise ValueError('observation source or independently hashed contract identity')
    if len(rows)!=len(observed['receipts']):raise ValueError('receipt population')
    for row,receipt in zip(rows,observed['receipts']):
        value=observed['values'][row['output']] if row['output']!='-' else observed['values'][row['inputs'][0]] if row['op']=='emit' else None
        body={'scope':'LCUF_X_HOST_RESEARCH','row':row['id'],'site':row['site'],'profile':row['profile'],'semantic_sha256':observed['semantic_sha256'],'previous_sha256':previous,'result_sha256':digest(value)}
        previous=digest(body)
        if canonical(receipt)!=canonical({**body,'sha256':previous}):raise ValueError('receipt row/result/chain binding')
    if previous!=observed['receipt_chain_head']:raise ValueError('receipt chain head')
    if observed['admission']!=ir['admission'] or observed['row_order']!=[r['id'] for r in ir['rows']]:raise ValueError('admission/order observation')
def check_record(record,validator,replay=True):
    errors=[]
    try:
        validator.validate(record);raw=decoded(record['source']);expected=record['expected'];observed=record['observed'];family=record['family'];variant=record['variant']
        if family in B.POSITIVE:
            fixture,values=B.positive(family,variant);oracle={'kind':'accept','values':values}
        elif family in B.NEGATIVE:
            fixture,diagnostic=B.negative(family,variant);oracle={'kind':'reject','diagnostic_contains':diagnostic}
        else:
            fixture,paired_fixture,values=B.paired(family,variant);oracle={'kind':'metamorphic','values':values,'semantic_equal':True,'source_different':True}
            if decoded(record['paired_source'])!=paired_fixture:raise ValueError('paired source construction-lineage mismatch')
        if raw!=fixture or canonical(expected)!=canonical(oracle):raise ValueError('source or independent oracle construction-lineage mismatch')
        articles,requirements=B.annotations(record['family'])
        if record['article_ids']!=articles or record['requirement_ids']!=requirements:raise ValueError('construction annotation lineage mismatch')
        if replay and canonical(B.observation(raw))!=canonical(observed):raise ValueError('stored observation differs from fresh execution')
        if expected['kind']=='reject':
            if observed['status']!='rejected' or expected['diagnostic_contains'] not in observed['diagnostic']:raise ValueError('rejection oracle mismatch')
        else:
            if observed['status']!='host_research_pass' or not all(name in observed['values'] and B.equal(value,observed['values'][name]) for name,value in expected['values'].items()):raise ValueError('independent value oracle mismatch')
            receipt_checks(raw,observed)
        if expected['kind']=='metamorphic':
            other=decoded(record['paired_source']);paired=record['paired_observed']
            if replay and canonical(B.observation(other))!=canonical(paired):raise ValueError('paired observation differs from fresh execution')
            if observed['source_sha256']==paired['source_sha256'] or observed['semantic_sha256']!=paired['semantic_sha256']:raise ValueError('metamorphic identity mismatch')
            if not all(name in paired['values'] and B.equal(value,paired['values'][name]) for name,value in expected['values'].items()):raise ValueError('paired value oracle mismatch')
            receipt_checks(other,paired)
    except (ValueError,TypeError,KeyError,RecursionError,jsonschema.ValidationError) as error:errors.append(str(error))
    return errors

def population(records):
    ordered=[(family,v) for family in B.POSITIVE for v in range(16)]+[(family,0) for family in B.NEGATIVE]+[(family,v) for family in B.METAMORPHIC for v in range(8)]
    expected=set(ordered)
    observed={(r.get('family'),r.get('variant')) for r in records}
    ids=[r.get('id') for r in records]
    errors=[]
    if observed!=expected or len(records)!=len(expected):errors.append('complete expected family/variant population required')
    if ids!=[f'LX-{i:06d}' for i in range(1,len(expected)+1)]:errors.append('complete ordered record identity population required')
    if [(r.get('family'),r.get('variant')) for r in records]!=ordered:errors.append('record identities must bind their ordered construction lineage')
    return errors

def validate(replay=True):
    errors=[];records=[];schema=strict_json((ROOT/'schemas/extension_record.schema.json').read_text(encoding='utf-8'))
    jsonschema.Draft202012Validator.check_schema(schema);validator=jsonschema.Draft202012Validator(schema)
    if X.OPS!=B.EXPECTED_OPS:errors.append({'error':'runtime operation metadata differs from independent fixture contracts'})
    for op in B.EXPECTED_OPS:
        if X.authority(op)!=B.EXPECTED_AUTHORITY.get(op,(set(),set())):errors.append({'error':'runtime authority differs from independent contract','operation':op})
    build=strict_json((ROOT/'validation/EXTENSION_BUILD.json').read_text(encoding='utf-8'))
    master=ROOT/'datasets/extension_conformance.jsonl'
    if sha(master)!=build['sha256'] or sha(ROOT/'extensions/math_kernels.py')!=build['kernel_source_sha256'] or sha(ROOT/'extensions/lcuf_x.py')!=build['compiler_source_sha256']:errors.append({'error':'dataset/runtime byte identity differs from build receipt'})
    for number,line in enumerate(master.read_text(encoding='utf-8').splitlines(),1):
        try:
            record=strict_json(line);record_errors=check_record(record,validator,replay)
            if record_errors:errors.append({'line':number,'errors':record_errors})
            else:records.append(record)
        except (ValueError,TypeError,RecursionError) as error:errors.append({'line':number,'error':str(error)})
    errors.extend({'error':e} for e in population(records))
    counts=collections.Counter(r['expected']['kind'] for r in records);rules=collections.Counter(k for r in records for k in r['requirement_ids'])
    if len(records)!=build['master_records'] or dict(counts)!=build['counts'] or build.get('status')!='PASS':errors.append({'error':'build receipt population agreement'})
    return {'status':'PASS' if not errors else 'FAIL','records':len(records),'source_evaluation_slots':len(records)+counts['metamorphic'],'counts':dict(counts),'families':len({r['family'] for r in records}),'primary_requirement_case_counts':dict(sorted(rules.items())),'fresh_host_execution':replay,'schema':'JSON Schema Draft2020-12','source_binding':True,'independent_fixture_policy_checked':True,'receipt_binding':'Exact row/site/profile/source-contract/result/previous-hash recomputation','scope':'Bounded host conformance; no native/device/full-optimizer execution or exhaustive proof.','errors':errors[:100]}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--metadata-only',action='store_true');args=parser.parse_args()
    result=validate(not args.metadata_only);text=json.dumps(result,indent=2)+'\n';(ROOT/'validation/EXTENSION_VALIDATION.json').write_text(text,encoding='utf-8');print(text,end='');sys.exit(0 if result['status']=='PASS' else 1)
