# LCUF integrated architecture and migration

## Architectural decision

LCUF now treats geometric addressing, numerical fields, signal representations, optimizer state, transport packets and image containers as separately typed parts of one fabric. The articles' strongest common contribution is an explicit pipeline from representation through specialized computation to placement and evidence. The implemented research profiles supply bounded host examples of that pipeline. The native and physical portions are staged contracts with identified state, resource and observation requirements.

The architecture has four authority levels: source language and mathematical contracts; admitted logical dataflow; backend implementation/build identity; and observed execution or measurement. A successful host program establishes the second level against the bundled reference. It cannot establish that a GPU, NPU, optical instrument, biological sample or remote site performed the same operation.

```mermaid
flowchart TD
    Articles[20 supplied research files] --> Decisions[Article decisions and profile contracts]
    Foundation[Preserved JA 8S foundation] --> Geometry[Typed geometry and address adapters]
    Decisions --> Columns[LCUF-X twelve-column source]
    Geometry --> Columns
    Columns --> Admission[Types, capabilities, DAG and resource admission]
    Admission --> Host[Implemented bounded host profiles]
    Admission --> Native[Proposed native ABI and image backend]
    Host --> Local[Local receipts and conformance observations]
    Native --> Drivers[Driver and buffer custody gates]
    Drivers --> Fabric[Proposed authenticated federation]
    Fabric --> Measured[Boot, delivery and physical observation evidence]
    Codec[Image container adapter contract] --> Columns
    Calibration[Physical calibration and sample provenance] --> Codec
```

The [architecture plan](ARCHITECTURE_PLAN.json) records these implementation states explicitly. No node is promoted by an article's performance claim alone.

## Geometry and representation

The JA 8S foundation remains the real-valued coupled geometric contract supplied by the user. Its five base coordinates indexed 4–8, local S³ relationships, domain restrictions and `eta_ind >= epsilon_ind AND Delta8S > epsilon_gain` gate are preserved. A p-adic address is an additional representation whose radix, precision, coordinate mapping, digit order, inverse convention and loss policy must be declared. It does not substitute a p-adic norm for the 8S PSD metric or a p-adic reciprocal for a real optimizer denominator.

A storage axis is not automatically a geometric coordinate. For example, T,C,Z,Y,X can label a five-axis image array without being the author's c4..c8 penteract. The adapter must state how geometric coordinates select samples, tiles, multiscale levels or categorical channels. A reversible finite coordinate codec requires bounded domains and a specified inverse. Any quotient reduction, quantization, palette conversion or multiresolution projection must carry an information-loss label.

Low-order base-p prefixes define p-adic neighborhoods. Conventional MSB spatial tiling/Morton layouts and Euclidean proximity encode different relationships. A backend may optimize storage locality while preserving a declared logical address map, but it must not infer identical topology from a visually similar image. Conditional coset averaging has an implemented finite contract; continuous kernels, unit inverses, root admissions and diffusion generators require separately identified profiles.

## Profile identity and lowering

A native/import profile must bind namespace, version, grammar digest, semantics digest, value schema, numerical convention, adapter identity and target ABI. The extension host binds its current reference source identities in IR and release receipts. Future native builds must additionally bind source-derived policy, toolchain/dependency closure, driver allowlist, code/data layout and image digest.

Qualified namespaces prevent collisions among unrelated terminology. The user's LCTL column language, the articles' compression-template LCTL, image GIF and Gaussian Interaction Frame GIF are distinct. Suggested native namespaces are `language.lctl.columned`, `compression.lctl.templates`, `image.gif89a`, and `quantum.gaussian_interaction_frame`. A name match supplies no parser compatibility or shared mathematics. Algorithm identifiers also distinguish ordinary LAMB, the supplied paper's 1-bit LAMB variants and the implemented `lcuf.rms-sign/1` component.

Lowering follows source → typed logical IR → backend-neutral buffer/effect plan → qualified backend implementation → executable image → observed run. Each lowering stage preserves or explicitly strengthens authority, resource and evidence constraints. A codec or optimizer template cannot remove the sender grant, residual owner or physical calibration requirement merely because it generates compact native code.

Native specialization is most credible for closed operation sets, fixed shapes, explicit effects and pinned driver requirements. Its benefits must be measured against a baseline under the same workload and transport. A smaller kernel image or fewer presumed context switches alone does not establish lower end-to-end latency, secure DMA or zero-copy operation.

## Data plane and buffer custody

The data plane separates original container bytes, decoded tensors, mathematical values, presentation metadata and measurement provenance. An input record should carry an exact container digest, decoder identity, decoded-sample digest, dtype, shape, axes, strides, endian convention, channel/basis meaning, coordinate map and acquisition timestamps with units. Scientific interpretation further requires calibration and uncertainty.

A `Raster[u8,W,H,C]` value in the current source language is a decoded exact sample array. It is not a TIFF IFD, GIF palette, detector complex field or timed camera stream. Raster shifting changes indices only. Container codecs, palette lookup, disposal/compositing, metadata inheritance, tiles and streaming parsers are future adapter operations with adversarial size/work limits.

TIFF field type and image sample type are distinct layers. A scientific TIFF adapter must validate BitsPerSample, SampleFormat, compression, planar/channel layout, offsets and extents under a declared supported subset. Lossless compression preserves the selected decoded samples, not every metadata convention or original byte spelling. GIF image frames have palette and rendering/timing semantics; centisecond delays are not physical picosecond observation clocks. GIF numerical quantum modeling denotes another namespace entirely.

Zero-copy is a property of a concrete buffer path: owner, allocation/pinning identity, offsets, access rights, alias rules, lifetime, DMA/driver transitions and observed copies. A borrowed tensor view needs bounds and alignment checks. The host Python payload model supplies no proof about allocation or driver copies. For streaming inputs, decompression dictionary state, frame compositing, checkpointed decoder state and peak decoded buffers must be accounted for even when file subblocks are small.

## Signal, diffusion and logical reasoning

The host profile makes ordinary real circular convolution and correlation available as numerical primitives. Higher layers may combine them with explicit role transforms, codebooks, cleanup thresholds, ambiguity margins and reproducible construction seeds. Retrieval accuracy and cosine similarity remain approximate observations. A proof-bearing logical conclusion must instead carry symbolic premises, directional rules and a checkable proof term or trace.

Cyclic shifts have an implemented permutation contract but cannot by themselves break convolution's commutative role symmetry. No claim of ordered reasoning is attached to `permute`. Native vectorization or FFT acceleration must specify normalization and numerical error relative to the direct reference. It must also retain shape and basis checks rather than relying on opaque array length alone.

Optical wave propagation, dissipative diffusion and finite p-adic conditional averaging require different transfer operators. An intensity image does not contain an independently recoverable complex phase without an acquisition/reconstruction model. OAM mode indices and digit positions need explicit encodings; a mode shift can correspond to a specific index/radix operation under conditions, rather than arbitrary multiplication/division.

Physical signal/device profiles need calibration identity, allowed wavelengths/modes, units, observable definitions, transfer functions, saturation/noise models, timing alignment, control bounds and readback evidence. Biological/super-resolution research motivates sample provenance and uncertainty metadata. This release adds no biological actuation or clinical operation. Gaussian Interaction Frame quantum simulation similarly requires a defined finite solver, truncation/commutator error and independent numerical comparison; its name does not confer hardware quantum execution.

## Optimizer control and federation

The full 1-bit LAMB contract distinguishes parameters, momentum, frozen preconditioning variance, refreshed reconstructed-gradient variance, frozen averaged layer coefficient, adaptive layer scaling, worker residuals, aggregate residuals and committed training steps. The supplied paper and current implementation context contain notation/epsilon variants that must be resolved by an exact algorithm version. The host scaled-sign codec and phase guard implement a component boundary, not those update equations.

A distributed residual identity includes model/layer/shard, optimizer and codec versions, worker/topology identity, epoch, tensor shape and committed step. Compression transitions require a consensus-compatible step and frozen-state identity. A restart must restore model state and residuals consistently; a fallback must preserve the same committed logical update while changing transport/numerical mode under a declared transaction.

Worker compression and server/aggregate compression have separate residual recurrences. Packed signs cannot be summed as if they were real momenta. A collective must validate packet contexts, decode, aggregate under specified weights/order, update aggregate feedback, and encode the resulting payload. A majority vote discards scales and does not implement mean aggregation. Exact-zero masks, sparse coordinates and coefficient-ratio corrections likewise need explicit algorithm contracts rather than being inferred from the basic sign packet.

The prototype forbids remote transfer of `Residual` and `EFBundle`, permitting only an extracted `SignPacket` with the existing directed sender/receiver authority checks. This models a safe data/state distinction. Native federation adds authenticated envelopes, replay protection, durable inbox/outbox transitions, policy intersection across nested domains, membership/revocation epochs and operation-specific idempotency. Local receipt hashes alone authenticate neither a sender nor a remote run.

The native envelope should bind language/profile identity, model/layer/shard, step/epoch, sequence/idempotency key, typed payload digest, codec/scale/mask convention, declared routing scope and relevant build/calibration evidence. A decoded payload is accepted only after envelope admission, exact byte/schema bounds and numerical checks. Authority narrowing occurs at every federation boundary; a p-adic routing prefix is an address rather than an authorization token.

## Resource and performance accounting

Compression should be evaluated with wire bytes, residual memory, workspace, encode/decode time, synchronization, topology and optimizer convergence all included. For N values, the research sign packet occupies 16+ceil(N/8) bytes while one local residual occupies 8N bytes. At N=4, the packet is 17 bytes: it exceeds a four-element f32 payload of 16 bytes, while reducing a four-element f64 payload of 32 bytes. “One bit” therefore does not guarantee compression for small messages.

For a proposed native N=4096 tensor, the same packet layout would occupy 528 bytes, compared with 16,384 f32 bytes, a payload-only ratio of approximately 31.03. This is a sizing calculation, not a host-supported shape or measured speedup; the current host limits N to 256. Transport framing, padding, scales, masks, error-feedback buffers, collectives, hardware copies and warmup can materially change end-to-end results.

The host work model includes kernel minima and retained output plus peak modeled scratch. Native admission must additionally reserve stack/heap, code/static data, decoder dictionaries, storage caches, page/driver/DMA buffers, GPU workspace, collective state and persistent checkpoints. Devices with asynchronous ownership require a bounded in-flight count and release protocol.

RAM bandwidth and training throughput require separate measurements. A 1024×1024 one-byte decoded frame at one million frames per second requires 1.048576×10¹² decoded bytes per second before extra copies or computation. A slower file decoder, a hypothetical optical flight time or a hardware marketing rate cannot establish that system throughput. Performance reports must record format/profile, shape, topology, clock/sample source, batch, precision, warmup, convergence target, and latency distributions or confidence intervals appropriate to the experiment.

## Telemetry and physical measurements

Telemetry defaults to disabled in the architecture plan. An enabled adapter names the observation source, units, clock, interval, privileges, allowed fields, retention and export scope. Hardware discovery reports exact model/firmware/driver information available from the machine; article discussion of an IdeaPad does not establish this machine's installed RAM, NPU capability or bandwidth.

Passive counters, synthetic fixtures, privileged memory acquisition and physical instrument readbacks are different profiles. No memory dump, security-setting change, key extraction or remote export is authorized by an article's instructions. Measured telemetry is an external effect whose provenance and nondeterminism must remain in an observation record rather than silently entering deterministic program identity.

A telemetry record distinguishes requested and realized sampling intervals, missing/invalid samples, calibration, clock drift and measurement overhead. Reproducible benchmarks should report both useful work and observer cost. Device evidence requires actual readbacks under the relevant calibration; a source article, host simulation or illustrative schema cannot fill those fields.

## Migration and acceptance gates

1. Preserve the baseline and select `LCUF-X/0.2` only for a program using the new finite types. Re-express imports through explicit typed adapters; avoid translating unrelated LCTL or GIF namespaces by name.
2. Choose numerical and address domains, axes/bases and information-loss conventions. Retain the JA 8S real geometry and coupled gate as its own authority.
3. Validate source, profile ownership, shapes, capabilities, dependency order and modeled resources. Run the extension golden cases and host tests, retaining exact source/result identities.
4. Implement container and semantic adapters under their declared schemas, including hostile-input/resource tests, decoded-sample equivalence and metadata/timing checks.
5. Select and pin a native toolchain, ABI, dependencies and drivers; generate an image and obtain boot/resource/denial evidence. Compare backend results to independent host oracles with stated numerical tolerances.
6. Implement authenticated transport and state-consistent collectives, then execute fault scenarios for replay, partial commits, crash, membership change, fallback and revocation.
7. Promote physical claims only after operator-specific calibration/readback evidence. Review observed accuracy and throughput separately from design calculations and source-reported benchmarks.

The [article application matrix](ARTICLE_APPLICATION_MATRIX.json), three findings registries and stable PGT/SIG/OPT requirements make these changes reviewable per source. [Release validation](../validation/VALIDATION_SUMMARY.json) records implemented host checks; proposed native, codec, logic and device gates retain their separate status.
