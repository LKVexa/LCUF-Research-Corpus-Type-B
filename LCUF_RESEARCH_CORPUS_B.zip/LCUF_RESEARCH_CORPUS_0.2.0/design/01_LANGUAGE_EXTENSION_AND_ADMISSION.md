# LCUF research profiles and admission semantics

## Language partition and compatibility

The applied research adds a separately identified source language, **LCUF-X/0.2**, with a bounded host reference in [lcuf_x.py](../extensions/lcuf_x.py). LCUF/0.1 remains intact in [the frozen baseline](../baseline/0.1.0/README.md). A program must choose its header explicitly; neither compiler accepts the other's header. This separation permits exact finite-residue, vector and compression experiments without silently changing the scalar language or the author's JA arithmetic.

LCUF-X retains the twelve source columns:

`id | site | profile | op | inputs | output | type | effects | caps | after | budget | evidence`.

Declarations are `module NAME`, `site NAME trust=LABEL memory=POSITIVE steps=POSITIVE`, `grant NAME caps=LIST`, and `link FROM TO transfer=copy`, followed by the column header, rows and `end`. Module is the first declaration. Identifiers are ASCII `[A-Za-z_][A-Za-z0-9_.-]*`; list separators are commas, with `-` representing an empty list. A source is UTF-8, optionally BOM-prefixed, bounded to 1 MiB and 1,024 rows. Empty and comment lines are ignored. The parser strips each physical line and each cell. A literal pipe inside JSON must be escaped as `\u007c`; there is no general expression evaluator or dynamic code import.

These choices directly implement the articles' call for explicit columns, dataflow and bounded specialization while preserving the earlier compiler's authority checks. The new profiles operate in one host process. Their declared sites and links are model objects rather than discovered machines.

## Type constructors and domains

| Source type | Admitted value/domain | Retained payload measure |
|---|---|---:|
| `i64` | Exact Python integer, excluding Boolean, in −2⁶³ through 2⁶³−1 | 8 bytes |
| `f64` | Finite real JSON number normalized to host binary64; Boolean excluded | 8 bytes |
| `bool` | JSON Boolean | 1 byte |
| `text` | Unicode string encodable as UTF-8 | UTF-8 byte length |
| `unit` | Terminal result only; no admitted constant/output name | 0 |
| `Zp[p,n]` | Canonical integer representative of Z/(pⁿ), `0 <= x < pⁿ` | ceil(bit_length(pⁿ−1)/8) |
| `Vec[f64,N]` | N finite binary64 values, `1 <= N <= 256` | 8N |
| `PField[p,n]` | Real-valued function on Z/(pⁿ), stored by canonical residue index; `pⁿ <= 256` | 8pⁿ |
| `Raster[u8,W,H,C]` | Flattened row-major interleaved unsigned samples; C in {1,3,4}, WHC <= 4096 | WHC |
| `Residual[N]` | Site-local vector of N finite binary64 compression residuals | 8N |
| `SignPacket[N]` | Validated versioned scaled-sign wire packet | 16 + ceil(N/8) |
| `EFBundle[N]` | Compound packet plus site-local residual | 16 + ceil(N/8) + 8N |

For residue/field types p is prime in 2 through 257 and n is an integer in 1 through 16. Type parameters use positive ASCII decimal syntax without leading zeros. A composite radix, unsupported channel count, excessively long parameter or oversized shape is rejected before evaluation. The finite quotient has zero divisors when n > 1 and is not generally a field. It is neither GF(pⁿ) nor the infinite field Qp.

`const` accepts scalar or flat structured JSON appropriate to the declared type. Duplicate object keys and bare nonfinite constants are rejected. Exponent overflow such as `1e999` is also rejected by finite-value admission. Vector and f64 literal numbers are normalized to binary64 before canonical IR formation; thus `[1,2]` and `[1.0,2.0]` denote the same `Vec[f64,2]` literal. Integer and Boolean types are never conflated. Signed zero in general f64 values remains observable in serialization; the packet scale has the narrower positive-zero rule below.

Only all-zero `Residual` literals may initialize a compression sequence. `SignPacket` and `EFBundle` literals are inadmissible; the host creates them through checked operations. This restriction avoids admitting forged compound packets as source constants. There is no checkpoint restoration operation. A future restore path requires model, layer, codec, topology, epoch and state-digest checks.

`Vec` alone supplies numerical shape, not a semantic role, physical unit, quantum basis or calibrated sensor frame. The richer basis/unit/axes metadata belongs to the architecture profile contract. A native or imported frontend must bind that metadata to its values before receiving those stronger interpretations.

## Closed operation set

The [machine registry](../extensions/PROFILE_CONTRACTS.json) records all 21 operations, their profile owners and implementation boundaries. `const`, `add`, `mul`, `copy`, `assert_eq` and `emit` retain their column roles; add/mul remain i64 arithmetic. Constants admit the new finite types only under the explicit extension header. The fifteen additional operations are:

| Operation and profile | Operand/output contract | Mathematical or operational meaning |
|---|---|---|
| `padic_add`, `padic_mul`; `lcuf.padic.finite` | Two equal `Zp[p,n]` operands, same output | Exact sum/product modulo pⁿ |
| `padic_from_i64`; same profile | i64 to a declared `Zp[p,n]` | Explicit reduction `x mod pⁿ`; potentially information-losing |
| `padic_reduce`; same profile | `Zp[p,n]` to `Zp[p,m]`, same p and m < n | Explicit precision reduction; no inferred lift |
| `padic_val`; same profile | `Zp[p,n]` to i64 | Truncated valuation: vₚ(x) for nonzero representative, n for zero |
| `padic_average`; `lcuf.padic.field` | `PField[p,n]`, i64 k; same field output | Average over cosets with identical low k base-p digits; 0 <= k <= n |
| `hrr_bind`; `lcuf.hrr.real` | Two equal real vectors; same vector output | Real circular convolution |
| `hrr_correlate`; same profile | Bound vector and key of equal length | Circular correlation; generally approximate unbinding |
| `permute`; same profile | Real vector and i64 shift | Explicit cyclic index permutation |
| `diffuse_step`; `lcuf.diffusion.periodic` | Real vector and f64 alpha; same vector output | Periodic convex heat update for 0 <= alpha <= 1/2 |
| `raster_shift`; `lcuf.image.u8` | Exact raster and i64 horizontal shift | Periodic sample-index translation, with no resampling |
| `ef_pack`; `lcuf.compression.component` | `Vec[f64,N]`, `Residual[N]` to `EFBundle[N]` | RMS sign quantization and local error-feedback recurrence |
| `ef_wire`; same profile | Bundle to matching `SignPacket[N]` | Extract transport-eligible wire component |
| `ef_residual`; same profile | Bundle to matching `Residual[N]` | Extract retained local state |
| `sign_decode`; same profile | Sign packet to matching real vector | Validate and reconstruct scaled signs |

Exact ring operations reject implicit radix changes and precision increases. A residue class modulo pⁿ has many lifts modulo pⁿ⁺¹; the host cannot recover discarded digits from type syntax. Ordinary signed order, sign bits and real reciprocal square roots have no implicit p-adic interpretation. In particular, +1 and −1 coincide modulo 2. The source types prevent a sign packet from being confused with a residue or with an optimizer update.

For `PField`, let M=pⁿ, B=pᵏ and q=M/B. The projection is

`A_k(f)[i] = (1/q) sum_{j congruent to i mod B} f[j]`.

The real-valued samples and the p-adic index hierarchy are separate domains. k=0 gives a global mean, k=n gives identity, and repeated projection is mathematically idempotent in exact arithmetic. The implemented binary64 observation is roundoff-qualified. This is a finite conditional average, not a general Vladimirov operator, continuous p-adic heat solver or optical propagator.

For HRR, the host specifies `bind(a,b)[k] = sum_i a[i] b[(k-i) mod N]` and `correlate(c,b)[k] = sum_i c[(k+i) mod N] b[i]`. Products are formed in increasing i order and reduced using `math.fsum`. Nonfinite operands, products or results are denied. The exact circular-convolution algebra is commutative. Correlation with an arbitrary key is not a general inverse. Cyclic shifts do not solve argument-order encoding: shifting each operand only shifts their convolution by the sum of the shifts. A future directional logic frontend needs noncommuting role transforms or tagged symbolic fields and a sound checker.

`diffuse_step` uses `(1−2 alpha)x_i + alpha x_(i−1) + alpha x_(i+1)` with periodic indices. Its convex-weight domain is explicit; the host does not execute Fourier angular-spectrum diffraction. `raster_shift` likewise implements integer array indexing rather than OAM multiplication, image interpolation, palette conversion or physical movement of an optical mode.

## Compression, state locality and phase control

For x and local residual r, the codec forms z=x+r, computes an RMS magnitude s, reconstructs qᵢ as +s for zᵢ >= 0 and −s otherwise, and retains r′=z−q. The RMS implementation scales by the maximum absolute element before squaring normalized elements, avoiding direct square overflow. The exact-zero sign convention is positive. Underflow and ordinary binary64 rounding remain numerical behavior; reconstruction is not lossless quantization.

The wire format is `LSG1 || uint32_le(N) || binary64_le(s) || packed_signs`, with least-significant-bit-first signs and zero unused padding. The scale is finite and nonnegative. Negative-zero scale is rejected; generated zero scales use positive binary64 zero. A packet contains no residual, pointer, capability, topology epoch or hidden buffer address. Transport envelopes must supply those independent contextual identities where needed. Decoding rejects wrong magic, length, padding, codec, base64 spelling or scale.

`ef_pack`, `ef_wire` and `ef_residual` declare effect `optimizer.local_state` and capability `optimizer.state`. The executing site must have the corresponding grant. `Residual` and `EFBundle` cannot be copied to another site. In this prototype “owner-affine” denotes location affinity: immutable values may have multiple readers, and no linear-use or atomic persistent-commit proof is claimed. A wire packet is explicitly extracted before transfer, which still requires the normal directed link, sender grant and receiver grant.

The [CompressionPhase](../extensions/math_kernels.py) host guard separately enforces an exact expected-step counter, a nonempty warmup and compressed horizon, a contract digest and a frozen-state digest at the transition. Steps 0 through freeze_step−1 are warmup; step freeze_step enters the compressed epoch. Stale steps, missing freeze identity, premature freeze identity and exhausted horizons are denied. It is an in-memory phase guard, not an implementation of momentum updates, reconstructed-gradient variance, layer coefficients, durable commits, collectives or full 1-bit LAMB training. [The optimizer volume](04_OPTIMIZER_UNIKERNEL_AND_TELEMETRY.md) specifies those additional obligations from the supplied paper and implementation context.

## Static admission and local evaluation

Each output has one writer. Input names resolve to typed producer rows. Input edges and explicit local `after` edges construct one dependency graph; undefined references and cycles are rejected. The scheduler repeatedly chooses the lexically first ready row. Forward references are permitted when the resulting graph is acyclic. Source row order is not an execution-order authority.

An operation must belong to its registered profile and have the exact arity and type signature. Value operations require a named non-unit output. `assert_eq` and `emit` require type `unit` and output `-`; assertion operands have the same source type, and their normalized JSON values are compared without Boolean/integer aliasing. Emit requires a local receipt.

Pure kernels declare no effects or capabilities. Copy requires exactly `fabric.transfer` and `fabric.receive`; a remote producer additionally requires `fabric.send` and an explicit directed link. A local copy is rejected. Local evidence emission requires exactly `evidence.emit` and `evidence.write`. State components use the optimizer contract above. Extra or missing row effect/capability names are rejected rather than being treated as advisory metadata.

Before kernel evaluation, admission computes every output's modeled retained payload and each site's peak modeled kernel scratch. Text copies inherit the producer's exact encoded size. Each site's declaration must cover retained payload plus peak scratch, and the sum of row budgets must fit its step declaration. Each row must also reserve at least its operation's modeled minimum work. The minima are N² for convolution/correlation, 2M for field projection, 5N for periodic diffusion, 6N for sign packing, N for vector selection/decoding/permutation, WHC for raster shifting, and max(1,word_count²) for finite-ring arithmetic. A ring word count is ceil(bit_length(pⁿ−1)/64), using the source precision for reduction and valuation.

Modeled scratch is respectively 8N,16M,8N,24N,8N,WHC and 8 times ring word count; ordinary scalar operations use zero modeled scratch and one work unit. These quantities bound declared abstract payload/work under this implementation, not total Python object allocation, wall time, native stack, allocator fragmentation, driver buffers or GPU workspace. The native architecture requires those additional measurements and reservations.

After successful static admission, compile preview evaluates the finite DAG and rejects overflow, inadmissible diffusion coefficients, bad coset levels and failed assertions. `run_source` recompiles source and independently walks the admitted order again. It checks equality with preview values. There is no API for trusting externally supplied IR.

Canonical IR includes normalized literals, policy, sites, sorted grants and links, ordered rows, admission measures, the compiler version, operation profiles/arities and the byte identities of the reference compiler and kernels. Source SHA-256 binds the original bytes separately. This normalized contract identity is not a proof of general mathematical equivalence or cross-platform floating-point reproducibility. Local receipts bind row, site, profile, that contract identity, the result hash and the previous receipt hash. The scope tag is `LCUF_X_HOST_RESEARCH`; it confers no remote execution or physical-device attestation.

## Requirement and verification discipline

[X_RULES.json](X_RULES.json) contains 24 stable extension requirements. The [extension data card](../datasets/EXTENSION_DATA_CARD.md) identifies the actual synthetic population, analytical expectations and construction lineage. Operator tests include zero/nonzero valuation, zero divisors, sign alias modulo 2, low-digit cosets, projection composition, approximate HRR recovery, the cyclic-role counterexample, diffusion conservation, raster sample identity, codec bytes, local residual recurrence, packet malleability denials, phase guards, state-transfer rejection and admission-before-evaluation.

The proof obligations for native resource enforcement, ordered symbolic reasoning, physical diffusion, codecs and complete distributed optimization remain separate. Source article adoption has a per-file [decision matrix](ARTICLE_APPLICATION_MATRIX.json), rather than a blanket declaration that every assertion is implemented or established. The user's 8S coupled gate and frozen arithmetic remain unchanged in the baseline mathematical collection.
