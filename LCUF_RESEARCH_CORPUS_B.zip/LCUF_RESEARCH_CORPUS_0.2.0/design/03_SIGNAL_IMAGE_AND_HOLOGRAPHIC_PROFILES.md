# Signal, image, and holographic profiles for LCUF 0.2.0

Prepared 9 October 2026. This volume applies nine supplied research articles to the LCUF design. It defines admission contracts, mathematical distinctions, device interfaces, and evaluation obligations. Requirement identifiers `SIG-01` through `SIG-32` are resolved in [the findings registry](SIGNAL_ARTICLE_FINDINGS.json). The notation below is specification metalanguage; it is not an extension of the frozen column grammar unless a separately versioned compiler explicitly admits it.

## 1. Authority, scope, and implementation boundary

All nine assigned numbered extracts were read from their first line through their works cited. The source locator convention is `ART-XX:Lnnnnn`, referring to the line prefixes in `research_sources/extracted/`. The registry records complete reading ranges and extracted-file SHA-256 identities. Blank equation positions occur throughout the extracts. A missing expression is recorded as missing mathematical authority; surrounding prose and a related primary paper do not establish that the original expression was faithfully extracted. Claims are assessed individually, rather than assigning a single truth verdict to an article.

The frozen `LCUF/0.1` language retains its six operations: `const`, `add`, `mul`, `copy`, `assert_eq`, and `emit`. Its ownership, effects, capability checks, finite dependency graph, integer limits, and local receipt semantics remain the baseline. The separately versioned `LCUF-X/0.2` host extension uses the same twelve-column structure and includes `Vec[f64,N]` and `Raster[u8,W,H,C]`. Its current research kernel source defines bounded real-vector `hrr_bind`, `hrr_correlate`, `permute`, `diffuse_step`, and `raster_shift`. These are source-inspected host functions. Their executed validation status belongs to the release's receipts; this document does not manufacture a successful run. They neither generate bootable unikernels nor control physical optical equipment.

The author's **8S Penteract–S³ Master Coupled Mechanics Law** remains its own preserved arithmetic foundation, including the five coordinates indexed 4 through 8 and the coupled acceptance gate. HRR vector arithmetic, optical models, raster indexing, conventional integer fixtures, and `Count` references do not complete or replace JA semantics. An adapter needs an authoritative mapping of domains, operators, uncertainty, and failure behavior before it can invoke the foundation. No photographic rendering of a law is evidence of a physical quantum processor.

| Article | Full reading range | Concrete contribution | Qualification controlling admission |
|---|---:|---|---|
| ART-01 | L00001–L00192 | Project/evolve/sample/remap loop; field and geometry descriptors | Diffraction is not generally heat diffusion; proposed throughput is unmeasured |
| ART-12 | L00001–L00173 | Positional digit shifts; finite optical mode registers | Radix-power shifts require width, overflow, quotient, and remainder semantics |
| ART-13 | L00001–L00220 | Multichannel acquisition, calibration, spatial targeting | Biological effects require experimental context and measured response |
| ART-15 | L00001–L00235 | HRR binding, retrieval, role encoding, reduced representations | Retrieval is approximate; commutativity loses argument order |
| ART-16 | L00001–L00223 | GIF rendering state; TIFF, BigTIFF, OME and spatial metadata | Losslessness and timing are profile-specific |
| ART-17 | L00001–L00168 | Gaussian interaction-frame model decomposition | A numerical quantum model is distinct from image GIF and quantum hardware |
| ART-18 | L00001–L00187 | Image-to-vector reasoning pipeline and optical logic hypotheses | Similarity output does not certify a logical implication |
| ART-19 | L00001–L00242 | Phase acquisition, encoding, quantization, LUT calibration | Sample fidelity does not establish device fidelity or cryptographic security |
| ART-20 | L00001–L00207 | Streaming, decoding, RF scheduling and physical weight representations | File blocks do not confer MHz frame rates or unlimited storage |

`SIG-01` requires explicit epistemic status: `specified`, `source_inspected`, `host_observed`, `numerically_compared`, or `device_observed`. A receipt must identify its actual observer. These statuses are not ordered substitutes for one another: a device observation under one calibration does not prove a compiler theorem, and a compiler test does not establish device behavior.

## 2. Typed signal values and coordinate contracts

The common signal layer separates sample values from their physical interpretation. A proposed descriptor contains `profile_id`, `profile_version`, scalar representation, finite shape, named axes, axis order, units, coordinate frame, sample origin, and immutable content identity. A complex field carries two explicitly related real components or an admitted complex encoding; an intensity raster is not implicitly a complex field. Axis metadata is validated against dimensionality and shape before any transformation. Reusing a width for an unrelated channel dimension is a type error.

`SIG-02` requires bounded nonempty dimensions, a checked product of dimensions, finite numerical samples, and an explicit maximum decoded allocation. `SIG-03` requires coordinates and units. A field grid might name `x`, `y`, and `wavelength`, with meter units, sample pitch, origin, and orientation. A scientific stack might name `x`, `y`, `z`, `t`, and `channel`, with a coordinate transform and channel identities. Pixel indices are dimensionless indices until a calibrated transform supplies physical coordinates. Reordering axes changes the descriptor and must transport sample values consistently.

Value identity has three levels under `SIG-04`: exact container bytes; canonical decoded samples with their layout; and scientific meaning including axes, units, calibration, and temporal policy. Two TIFF files with different byte order or strip partitioning can contain the same canonical samples. Identical sample numbers under different pixel pitches describe different fields. Hashing compressed bytes alone fails to express either relationship. Domain-separated digests therefore bind a serialization version and the relevant descriptor, with length-delimited fields and an explicit canonical sample encoding. A digest is an identity check, not a truth, ownership, or authenticity certificate.

`SIG-05` prohibits implicit promotion between intensity, phase, amplitude, categorical labels, probabilities, and vector embeddings. A normalized floating-point raster does not become an optical phase map by naming it a hologram. A phase map declares radians, wrap interval, branch convention, and its relationship to a carrier wavelength. Conversions disclose rounding, clipping, normalization, missing values, and uncertainty. An import encountering unsupported semantics returns a structured rejection rather than quietly interpreting scientific values as display colors.

## 3. HRR numerical algebra and host contract

ART-15:L00008–L00027 describes fixed-dimensional bundling, circular-convolution binding, approximate inverse operations, and cleanup memory. Plate's original 1995 paper presents this algebra with noisy reconstruction and a separate recognition memory. It supports a precise vector contract without establishing a universal cognitive or biological mechanism. [Plate, *Holographic Reduced Representations*, May 1995](https://redwood.berkeley.edu/wp-content/uploads/2020/08/Plate-HRR-IEEE-TransNN.pdf).

For real vectors of equal length `n`, `SIG-06` defines the binding orientation as

`bind(a,b)[k] = Σ(i=0..n−1) a[i] × b[(k−i) mod n]`.

`SIG-07` defines the correlation orientation as

`correlate(c,b)[k] = Σ(i=0..n−1) c[(k+i) mod n] × b[i]`.

The direct host functions admit lists of length 1 through 256, convert admitted integer or floating-point scalars to finite binary64, reject Booleans as numbers, reject unequal lengths, and reject nonfinite products or totals. They form products in index order and reduce them using Python `math.fsum`; this is part of the host numerical policy. A future FFT implementation must declare transform sign, scaling, layout, precision, and an error envelope. Algebraic equivalence over exact reals does not imply identical binary64 bytes across different reduction algorithms.

For example, an independently derived fixture is `bind([1,2,3],[4,5,6]) = [31,31,28]`. The identity vector is `[1,0,…,0]`. These fixtures expose indexing errors more directly than comparing a function to a second call to itself. The direct convolution requires `n²` products, at most 65,536 at the current vector ceiling. `SIG-08` requires the work and temporary-storage model to accompany any future fabric operation; vector length alone does not authorize unbounded dictionaries, optimizer state, cleanup candidates, or iteration counts.

The mathematical convolution is commutative and associative. Floating-point tests use disclosed tolerances for properties involving changed reduction order; exact equality is reserved for exact fixtures or identity cases whose arithmetic supports it. The API distinguishes a numerical result from its semantic interpretation. A bound vector is a vector value, not automatically a proposition, probability distribution, encrypted message, or physical wavefield.

## 4. Roles, approximate retrieval, and cognitive claims

Correlation generally returns a noisy approximation, not a guaranteed exact inverse. Exact deconvolution requires separate invertibility assumptions, including nonzero Fourier components, and may be ill-conditioned. `SIG-09` forbids an unconditional `unbind(bind(a,b),b)=a` promise. Tests must include a key with a zero spectral component and a composite memory with interference. Cleanup returns a candidate identity, score, runner-up margin, codebook identity, and `accepted`, `ambiguous`, or `no_match` status under a pinned policy. A tie cannot silently become certainty.

ART-15:L00093–L00099 explicitly introduces permutation to distinguish word order, while ART-18:L00030–L00035 blends binary XOR and real circular convolution. `SIG-10` gives different algebra profiles to real HRR, complex phasor representations, and binary sparse or spatter encodings. Their binding identities, normalization, distance functions, and cleanup thresholds are not interchangeable. Random-vector distributions and dimensions need a seed or immutable codebook digest. Approximate orthogonality is a statistical property; no finite codebook receives a guarantee of zero cross-talk from high dimensionality alone.

Ordered roles need special care. The implemented cyclic permutation is `shift_s(v)[k]=v[(k−s) mod n]`. It is a deterministic transform, but

`bind(shift_s(a),shift_t(b)) = shift_(s+t)(bind(a,b))`.

Consequently, fixed cyclic shifts applied to two argument slots still lose their ordering under a subsequent commutative binding. A future ordered-role profile must use independently specified role composition, a suitable noncommuting/general permutation scheme, or separately preserved symbolic argument fields. `SIG-11` demands a swapped-role counterexample test before claiming ordered relation support. A field called `subject` must remain distinguishable from `object` in both the symbolic record and its vector projection.

ART-15:L00124–L00165 discusses spiking models, semantic pointers, spatial pointers, resonator factorization, and neuromorphic platforms. These motivate proposed profiles with neuron model, integration step, encoder/decoder identity, phase branches, stopping criteria, and capacity experiments. They do not justify claims that LCUF reproduces a biological brain, exceeds a hardware energy benchmark, or has solved unconstrained cognition. `SIG-12` requires those claims to carry a workload, reference implementation, hardware configuration, accuracy criterion, measurement method, and uncertainty.

## 5. Logical reasoning remains independently checkable

ART-18:L00113–L00122 proposes reasoning about image sizes through vectorized relationships. Its cited cellular-automaton paper demonstrates image analogy and rule retrieval, and explicitly notes the symmetry of its rule representation. That observation blocks importing the encoding as a sound implementation of arbitrary directional implication. [Yilmaz, *Analogy Making and Logical Inference on Images*, 2015, section 3](https://ceur-ws.org/Vol-1583/CoCoNIPS_2015_paper_3.pdf).

`SIG-13` separates three outputs: a measured or inferred image attribute; a vector retrieval candidate; and a checked symbolic conclusion. A proposed reasoning adapter retains the original entity identifiers, predicate signature, ordered arguments, assumptions, rule version, and evidence references. A candidate can propose a conclusion to an independent rule checker; it cannot set `proved=true` solely from similarity or detector brightness. The checker must validate every premise and directional rule application, or return an unsupported conclusion.

For a finite image-size example, define an admitted predicate `larger(a,b)` over a declared metric such as calibrated area. Two supported inequalities can yield a transitive conclusion only if the metric and domain support transitivity and the uncertainty policy admits both comparisons. `largest(c,{a,b,c})` additionally requires comparisons against every relevant member; a visually salient candidate is insufficient. Equal sizes, segmentation ambiguity, contradictory measurements, an omitted object, and changed calibration are separate failure cases.

`SIG-14` specifies any future cellular-automaton encoder by rule table, neighborhood, boundary condition, initial binarization, permutation list, included time slices, concatenation order, and seed. Rule 90 is distinct from computationally universal Rule 110; naming a universal automaton does not make a bounded feature-extraction experiment a complete universal computer. Input-image groups, object identities, and graph templates must be controlled across evaluation partitions. Successful retrieval on a small illustrated vocabulary cannot establish general formal reasoning or unseen-domain accuracy.

## 6. Container validation and scientific sample fidelity

ART-16:L00050–L00086 and ART-20:L00055–L00075 describe TIFF directories, offsets, and floating-point data. `SIG-15` requires parsers to distinguish directory field types from raster sample types. TIFF `FLOAT` and `DOUBLE` types describe values inside directory entries; raster typing is established through the admitted `SampleFormat`, `BitsPerSample`, and associated layout tags. The TIFF specification explicitly separates sample type from sample size. [TIFF Revision 6.0, 3 June 1992, section 19](https://www.itu.int/itudoc/itu-t/com16/tiff-fx/docs/tiff6.pdf).

Classic TIFF and BigTIFF are separately identified. BigTIFF changes offset width and directory entry structure; it does not remove memory, arithmetic, parser, file-size, or decompression budgets. A parser validates byte order, magic, directory counts, entry types, count-times-size multiplication, offset-plus-length ranges, image dimensions, strip/tile counts, and directory traversal limits. Duplicate contradictory tags, cycles, overlapping unsupported layouts, truncated blocks, and unreachable required metadata are explicit diagnostic classes. [LibTIFF, BigTIFF design](https://libtiff.gitlab.io/libtiff/specification/bigtiff.html).

`SIG-16` makes losslessness a codec-and-sample contract. The admitted profile states compression, predictor, scalar representation, color transformation, alpha treatment, orientation, and any quantization. A lossless LZW byte stream does not undo a prior palette reduction or float-to-integer quantization. A TIFF container can hold lossy JPEG-compressed samples. Floating-point TIFFs have finite representation precision, contrary to ART-19:L00132's description of infinite precision. A scientific roundtrip compares canonical decoded samples and meaning descriptors, while a separate byte check verifies preservation of the original container.

The initial host image-data contract need not include a TIFF or GIF decoder. A descriptor validator and exact `u8` raster permutation can establish shape and sample indexing without certifying a container implementation. Any eventual decoder is a separately versioned adapter with a pinned library, codec allowlist, strict limits, and differential fixtures. An exported file must be reopened by an independent reader before claiming roundtrip preservation.

## 7. GIF frames, timing, and rendering state

ART-16:L00013–L00049 accurately draws attention to Graphic Control Extensions, timing, and disposal. `SIG-17` preserves the logical canvas, frame rectangle, active local or global palette, transparency index, disposal method, and extension scope. A Graphic Control Extension applies to the following graphic rendering block. It is not a control receipt for a frame already completed. The GIF89a delay is expressed in hundredths of a second; its semantics include a user-input flag and a zero-delay case. [CompuServe, GIF89a specification, 1989, section 23](https://www.w3.org/Graphics/GIF/spec-gif89a.txt).

`SIG-18` distinguishes three time quantities: encoded presentation delay; a scientific acquisition time; and measured device exposure/update time. A rational timebase and an integer tick index can represent a scientific sequence without binary floating-point drift. Its scheduler separately defines earliest issue, deadline, measured start and completion, jitter bounds, dropped-frame policy, and clock identity. GIF playback in a consumer viewer supplies none of those guarantees. Zero delay does not mean infinite frequency, and a centisecond field cannot directly encode a one-microsecond frame interval.

GIF palette indices are labels into an active color table, not automatically optical phase commands. A phase-driving export must pin a bijective mapping where possible, forbid unintended dithering, preserve exact grayscale/LUT codes, and compare decoded codes against the intended quantized array. A local palette change can make the same index represent a different color. Frame compositing must be tested with disposal 1, 2, and 3, transparent subrectangles, and previous-canvas restoration. The canonical sample digest must name whether it covers raw frame indices or fully composited canvas samples.

`SIG-19` bounds compressed bytes, decoded pixels, frames, dictionary state, canvas storage, and extension data. The 1–255-byte subblocks described in ART-20:L00076–L00081 are packaging units; dictionary state and rendering state cross their boundaries. Splitting input into short subblocks therefore does not eliminate decoder memory. Unsupported application extensions are inert metadata. Neither private tags nor looping extensions can grant device capabilities or introduce hidden unlimited computation.

## 8. Multidimensional TIFF profiles and spatial provenance

ART-16:L00117–L00157 motivates OME-TIFF and explicit plane mappings. `SIG-20` treats axes as a validated mapping, not an inference from physical directory order. A profile validates its `DimensionOrder`, plane indices, channel multiplicity, and explicit `TiffData` mapping, and identifies required external files by content digest. A UUID identifies a declared dependency; it does not prove that the referenced pixel data is present. Surviving redundant metadata cannot reconstruct absent samples. [OME-TIFF specification 6.3.1](https://docs.openmicroscopy.org/ome-model/6.3.1/ome-tiff/specification.html).

ART-20:L00075's suggestion that arbitrary eight-dimensional HRR spaces are natively handled by OME-TIFF is not an admitted guarantee. Higher-order conceptual axes need a separate schema and mapping. Similarly, scientific channel identity, wavelength, exposure, sensor saturation, and calibration cannot be replaced by generic RGB labeling. Reduced-resolution pyramid levels declare their downsampling method, scale transform, and relationship to the full-resolution data; they are derived views rather than additional independent measurements.

Spatial transport profiles may preserve GeoTIFF coordinates or use Cloud Optimized GeoTIFF for selective reads. `SIG-21` requires CRS identity, pixel-is-area or pixel-is-point interpretation, transforms, overview selection, and the actual advertised conformance class. A range request is a transport optimization, not a new scientific operation. ART-16:L00110–L00116's universal layout assertions must be checked against the chosen COG requirements rather than being enforced from prose. [OGC, Cloud Optimized GeoTIFF Standard 21-026, 2023](https://docs.ogc.org/is/21-026/21-026.html).

## 9. Wave propagation, heat diffusion, and geometry

ART-01:L00077–L00104 and its table at L00118–L00123 equate free-space angular-spectrum evolution with application of a heat kernel. `SIG-22` rejects this general equivalence. For propagating scalar plane-wave components, a free-space transfer function has phase behavior `exp(i z sqrt(k²−kx²−ky²))`. A flat heat equation uses attenuation `exp(−D t(kx²+ky²))`. One preserves propagating-mode magnitude in an ideal homogeneous model; the other suppresses high spatial frequencies. A particular engineered mapping between them needs an explicit derivation and error domain.

Numerical angular-spectrum calculations also depend on finite-grid sampling and bandwidth. The original band-limited angular-spectrum study identifies numerical errors from sampling the transfer function despite the underlying continuous propagation formula. This qualifies ART-19:L00008–L00022's unqualified numerical exactness claim. [Matsushima and Shimobaba, 2009](https://kansai-u.repo.nii.ac.jp/record/11127/files/KU-1100-20091015-50.pdf).

`SIG-23` gives a proposed wave profile explicit wavelength, refractive index/model, propagation distance, grid pitch, transform convention, boundary/padding, aperture, evanescent-mode policy, and numerical tolerance. A geometric PDE profile separately declares mesh or metric, differential operator, boundary conditions, timestep, discretization, and convergence evidence. Remapping coordinates without transporting the metric and fields does not automatically perform mean-curvature flow or Laplace–Beltrami diffusion.

The inspected host `diffuse_step` is a distinct periodic one-dimensional stencil:

`u'[i]=(1−2α)u[i]+αu[(i−1) mod n]+αu[(i+1) mod n]`, with `0≤α≤1/2`.

Its nonnegative weights sum to one, motivating independent tests for constant preservation, boundedness, and total-sum conservation within the host numerical policy. This model is neither a curved-manifold solver nor an optical apparatus. The unsigned-byte raster shift is likewise an index permutation with wraparound; it is not physical teleportation, phase evolution, or the geometry of the author's 8S foundation.

## 10. Phase acquisition, encoding, and calibrated hardware

ART-19:L00023–L00030 distinguishes intensity measurements from interferometric phase recovery. `SIG-24` requires raw measurement identity, reference-field model, acquisition configuration, reconstruction algorithm/version, and uncertainty. An intensity detector records magnitude information; reconstructing complex phase requires additional measurements or assumptions. Saturation, reference drift, temporal motion, coherence, and filtered spectral overlap must remain visible in the reconstruction receipt. The early digital-hologram work demonstrates numerical reconstruction of specifically acquired holograms, rather than recovery from arbitrary intensity pixels. [Schnars and Jüptner, 10 July 1994](https://opg.optica.org/ao/abstract.cfm?uri=ao-33-20-4373).

Phase-only encoding introduces another explicit transformation. ART-19:L00033–L00060 discusses iterative Gerchberg–Saxton and double-phase encoding. A proposed encoder contract records initial conditions, source/target amplitude constraints, transform policy, iteration ceiling, stopping threshold, achieved residual, quantization, and spatial filtering. An optimizer can fail to converge. Double-phase arrangements trade physical pixel allocation and noise against complex-amplitude approximation; a container's bit depth cannot eliminate that tradeoff.

`SIG-25` binds a deployment LUT to device serial/model, wavelength, polarization, temperature range, phase response, calibration date, and accepted error. The artifact records the desired phase, quantized command code, and measured response as separate values. Nonlinear voltage response, phase flicker, fill factor, neighboring-pixel cross-talk, alignment, and device drift remain failure mechanisms. Generic 8-bit output cannot promise exact optical phase. The original diffractive-network work demonstrates a trained optical arrangement for scoped tasks, not arbitrary programmable computation from any image file. [Lin et al., *All-Optical Machine Learning Using Diffractive Deep Neural Networks*, 2018](https://arxiv.org/abs/1804.08711).

## 11. Positional arithmetic and finite OAM registers

ART-12:L00039–L00055 and ART-18:L00109–L00112 support a useful algebraic distinction. For nonnegative digits `d[j]` in radix `b`, `value(d)=Σ d[j]b^j`; a zero-filled shift by `s` positions multiplies by `b^s` if the receiving width admits the result. A right shift yields a quotient and discards or separately returns the remainder. These are radix-power operations, not arbitrary multiplication and division. `SIG-26` therefore requires radix, digit validity, width, direction, shift count, fill, carry/overflow policy, and remainder policy.

A proposed physical OAM register additionally identifies the finite admitted mode set, radial index, polarization, coordinate slots, launch amplitudes, detection thresholds, mode-confusion matrix, and erasure policy. A theoretical unbounded OAM basis is not an unbounded realizable register. The foundational Laguerre–Gaussian analysis supplies an angular-momentum mode interpretation, rather than a guarantee of unlimited capacity or zero error. [Allen et al., *Orbital angular momentum of light*, 1992](https://journals.aps.org/pra/abstract/10.1103/PhysRevA.45.8185).

Mode purity, diffraction efficiency, and decoded digit error rate are distinct metrics. A high overlap with a target mode does not establish correct arithmetic for every admitted word. Tests cover every digit boundary in small finite registers, maximum representable value, overflow, zero input, right-shift remainders, missing modes, and ambiguity. ART-12:L00151's security guarantee is not imported from mode orthogonality or secret optical routing.

## 12. Streaming budgets, scheduler states, and unikernel integration

ART-20:L00076–L00111 proposes GIF/TIFF spooling through FPGA, RF synthesis, and acousto-optic hardware. `SIG-27` requires a whole-pipeline budget: encoded ingress, decoded sample output, codec throughput, queue depth, DMA alignment, DAC channels/rate, modulator settling, detector acquisition, and feedback transport. Full duplex aggregate bandwidth cannot be used as the one-direction payload limit. Compression ratios require workload measurements and a worst-case admission bound.

A 1024×1024 one-byte frame at 1,000,000 frames per second requires **1,048,576,000,000 decoded bytes per second**, before metadata, multiple channels, or readback. This arithmetic alone prevents extrapolating a cited 200 MiB/s decoder into that frame rate. Reusing a fixed mask can reduce update traffic, but the receipt must then describe mask reuse rather than claim full independent frame updates. The BTO microcavity paper proposes and calculates a high-speed design; it does not establish the supplied closed-loop system's measured MHz operation. [Peng et al., 2019](https://arxiv.org/abs/1908.06495).

Acousto-optic deflection also has aperture and acoustic transit constraints, and a scanned or multitone deflector is not automatically an independently addressable two-dimensional SLM. `SIG-28` requires the device's transfer model and accessible-pattern class. [AA Opto-Electronic, high-resolution deflectors](https://aaoptoelectronic.com/ao-devices/high-resolution-deflectors/).

```mermaid
stateDiagram-v2
    [*] --> Validating
    Validating --> Denied: descriptor, authority, or budget failure
    Validating --> Prepared: sample and deployment identities pinned
    Prepared --> Queued: bounded reservation
    Queued --> Issued: explicit device capability and calibration epoch
    Issued --> Observed: acquisition receipt
    Issued --> Unknown: timeout or disconnected observer
    Observed --> Accepted: independent acceptance policy
    Observed --> Rejected: residual or safety limit exceeded
    Unknown --> Reconciled: device-specific inspection
```

Unknown completion cannot be retried as a harmless pure calculation if a physical effect may have occurred. The future native driver needs pinned buffers, ownership transfer, interrupt and deadline behavior, device reset semantics, and capability-scoped access. File tags remain data; an authorized command envelope separately binds device, operation, calibration epoch, samples, schedule, and resource reservation. No current host function constitutes that driver or a native unikernel image.

## 13. Quantum and biological profiles require their own evidence

ART-17 uses **Gaussian Interaction Frame**, not Graphics Interchange Format. `SIG-29` requires separate namespace identifiers, for example a quantum model descriptor versus an image container profile. The primary pulsed-squeezing study constructs a reduced numerical model and compares predictions; its prospective device implications do not establish universal fault-tolerant hardware. [Yanagimoto et al., submitted 27 November 2021; Optica 2022](https://arxiv.org/abs/2111.13799).

A proposed quantum simulation profile records Hamiltonian, units, basis, initial state, mode discretization, truncation, frame transform, solver, tolerances, loss model, and convergence comparisons. Conservation checks are model-specific. A rendered Wigner portrait cannot establish negativity unless the signed underlying samples, reconstruction procedure, uncertainty, and model are preserved. Non-Gaussianity does not universally require Wigner negativity; a primary experiment explicitly reports a quantum non-Gaussian state with a positive Wigner function. [Ježek et al., 21 July 2011 preprint](https://arxiv.org/abs/1107.4305). Model compression requires residual and truncation evidence, rather than assuming omitted modes are harmless for every regime.

ART-13:L00097–L00112, L00119–L00126, and L00147–L00160 motivate acquisition and targeting descriptors for neurophotonics. `SIG-30` separates anatomical connectivity, observed functional response, inferred causal relationship, and predicted intervention. Measured localization precision is distinct from resolving two structures, identifying a synapse, or proving a physiological mechanism. The original optogenetic experiment and 3D-SHOT study are scoped experimental demonstrations. [Boyden et al., 2005](https://pubmed.ncbi.nlm.nih.gov/16116447/), [Pégard et al., 2017](https://pubmed.ncbi.nlm.nih.gov/29089483/).

A future biological-device adapter must carry sample/species/context identifiers, targeting coordinates, opsin/transducer model, light-dose and pulse limits, thermal/phototoxicity limits, response latency, cross-talk, calibration, and experimental authorization. Source images and barcode matches remain evidence with uncertainty. The MINFLUX primary report motivates localization metadata and photon-count provenance; it does not promise nanometer accuracy for arbitrary LCUF imagery. [Balzarotti et al., 2016 preprint; Science 2017](https://arxiv.org/abs/1611.03401).

## 14. Security, conformance, and evidence gates

`SIG-31` rejects security guarantees based solely on obscure masks, chaotic-looking output, or phase complexity. ART-01:L00149, ART-12:L00151, and ART-19:L00150–L00182 overstate such assurances. Primary cryptanalysis demonstrates known-plaintext vulnerability in double-random-phase encryption. A fabric security profile needs authenticated identity, explicit cryptographic construction, key management, replay policy, and its own threat model; visual noise is not confidentiality proof. [Peng et al., *Known-plaintext attack on optical encryption*, 2006](https://opg.optica.org/ol/abstract.cfm?uri=ol-31-8-1044).

`SIG-32` defines the release gate through independent fixtures and disclosed observations. Numerical tests cover identity convolution, indexing fixtures, unequal/empty vectors, Boolean rejection, overflow, approximate retrieval, cyclic-role collision, and diffusion invariants. Image tests cover shape, channel layout, sample identity, palette changes, compositing, malformed offsets, codec limits, and metadata substitution. Reasoning tests deliberately include swapped arguments, missing premises, ties, contradictory attributes, and unsupported conclusions. Device scenarios inject expired calibration, dropped frames, unknown completion, queue exhaustion, and clock disagreement.

Required evidence includes source hashes, operation/profile versions, admitted descriptors, expected oracle derivation, actual outputs, error envelope, and observer environment. Container fixtures should compare independent decoders; device scenarios require instrumented measurements. The optical full-adder primary abstract reports simulation accuracy on its specified dataset; it does not establish the LCUF runtime's physical full-adder implementation. [Deng et al., 4 June 2025](https://www.mdpi.com/2072-666X/16/6/681).

The development sequence is therefore explicit: validate bounded host kernels and image descriptors; add versioned scientific-container adapters; validate candidate retrieval against independent symbolic checks; then admit physical backends only after device-specific calibration, resource, and failure evidence. Every article remains available as research provenance. Its speculative claims remain separately tagged, and its concrete contributions enter the language through reviewable contracts.
