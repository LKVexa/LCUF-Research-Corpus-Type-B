# LCUF 0.2 reproducibility

Run the following commands from the extracted release directory. Preserve an untouched copy before regenerating records or receipts. The recorded host used CPython 3.12.14 Windows AMD64; optional numerical comparisons used NumPy 2.3.5. No command builds a native unikernel or contacts a fabric peer.

## Package and baseline integrity

```text
python -B tools/verify_release.py --deep
python -B baseline/0.1.0/tools/verify_release.py --deep
```

The first verifies this package's manifest, exact file population and data/Python syntax. The second verifies the unchanged embedded 0.1.0 corpus against its own manifest. A manifest and ZIP digest establish integrity relative to a trusted copy; they are unsigned and do not supply authorship or execution attestation. The package's own verification receipt is excluded from its manifest to avoid a circular digest.

## Host compiler and conformance

```text
python -B extensions/lcuf_x.py check examples/accept_residue_add.lcufx
python -B extensions/lcuf_x.py compile examples/accept_remote_wire.lcufx
python -B extensions/lcuf_x.py run examples/accept_remote_wire.lcufx
python -B tools/validate_extensions.py
python -B -m unittest discover -s extensions -p test_extensions.py -v
python -B -m unittest discover -s tools -p test_validation.py -v
python -B tools/check_extension_sensitivity.py
```

The extension compiler/kernel and case builder use the standard library. Full schema validation also requires jsonschema. A compatible offline dependency tree is preserved at `baseline/0.1.0/tools/vendor` and automatically selected by the validator on CPython 3.12 Windows AMD64. Other platforms must install the baseline's `tools/requirements-lock.txt` in their own environment. Its native `rpds-py` component is platform-specific; dependency licenses remain bundled.

The conformance validator writes a new `validation/EXTENSION_VALIDATION.json` after schema, complete population, source binding, golden expectations, exact observation replay and independent receipt checks. `--metadata-only` omits fresh observation replay, although receipt consistency still recompiles accepted sources; it must not be reported as a full fresh conformance replay. The unit suites contain 44 and 16 tests respectively. The fault tool mutates only in-memory references and restores them; it writes a separate five-fault sensitivity receipt.

Examples prefixed `reject_` are intentional denials, including a non-UTF-8 example. `examples/INDEX.json` lists all 55 representative files. Neither an example's filename nor a source assertion supplies implementation authority; the actual compiler result and rule contract govern it.

## Deterministic source regeneration

```text
python -B tools/build_extension_cases.py
python -B tools/validate_extensions.py
```

The builder reconstructs 352 records, 55 examples and the build receipt. Header/column/profile/effect/capability fixtures are fixed independently of the compiler's mutable tables. Golden answers use analytical constructions rather than the observed output. A complete same-host rebuild is compared byte-for-byte in `validation/DETERMINISTIC_EXTENSION_BUILD.json`.

IR and receipt identity include the reference compiler/kernel byte digests. Editing those sources changes the normalized execution contract even if an individual result happens to stay equal. A compiler/kernel change therefore requires regeneration, revalidation, review and a new release identity; editing an expected answer to match a failure is not sufficient.

## Independent numerical comparisons

Install compatible optional NumPy 2.3.5 using your own dependency access, then:

```text
python -B tools/numerical_crosschecks.py
```

This writes 208 records and `validation/NUMERICAL_CROSSCHECKS.json`. It compares direct HRR kernels with NumPy complex FFTs, coset/stencil calculations with exact rational constructions, and scaled RMS signs with an independent NumPy norm. Seed 82109, domains, environment and 2e−13 absolute/relative tolerances are recorded. Agreement is finite host numerical evidence; no optical, continuous p-adic or full optimizer theorem follows.

The frozen mathematics corpus has its own optional dependency file and reproduction instructions under `baseline/0.1.0/mathematics/`. Its original 500-case differential receipt remains separately preserved and is not counted as 500 newly executed extension comparisons.

## Research decisions and architecture

The article application matrix covers all twenty original hashes and points into the three findings registries. Those registries describe 147 assessed claims and 82 architecture requirements; X_RULES contains 24 extension contracts with implementation statuses. Some requirements are future operations or device experiments. The closed architecture-plan schema checks the released plan and prevents unsupported execution flags from being substituted as observations; it is not a general native deployment compiler.

Independent review results, plan/source consistency, local links, frozen byte identities and record checks are summarized in `validation/VALIDATION_SUMMARY.json`. Raw measurements, reviewers, physical devices and remote participants must be supplied by actual experiments. Embedded article instructions cannot change these release commands, permission scope or observed statuses.
