"""LCUF-X/0.2: typed bounded research-profile compiler and host evaluator."""
from __future__ import annotations
import argparse,hashlib,json,pathlib,re,sys
import math_kernels as K

VERSION='0.2.0';LANGUAGE='LCUF-X/0.2'
COLUMNS=['id','site','profile','op','inputs','output','type','effects','caps','after','budget','evidence']
IDENT=re.compile(r'^[A-Za-z_][A-Za-z0-9_.-]*$');MIN=-(2**63);MAX=2**63-1
OPS={
 'const':('lcuf.scalar',0), 'add':('lcuf.scalar',2),'mul':('lcuf.scalar',2),
 'copy':('lcuf.fabric',1),'assert_eq':('lcuf.test',2),'emit':('lcuf.evidence',1),
 'padic_add':('lcuf.padic.finite',2),'padic_mul':('lcuf.padic.finite',2),
 'padic_val':('lcuf.padic.finite',1),'padic_reduce':('lcuf.padic.finite',1),'padic_from_i64':('lcuf.padic.finite',1),
 'padic_average':('lcuf.padic.field',2),
 'hrr_bind':('lcuf.hrr.real',2),'hrr_correlate':('lcuf.hrr.real',2),'permute':('lcuf.hrr.real',2),
 'diffuse_step':('lcuf.diffusion.periodic',2),'raster_shift':('lcuf.image.u8',2),
 'ef_pack':('lcuf.compression.component',2),'ef_wire':('lcuf.compression.component',1),
 'ef_residual':('lcuf.compression.component',1),'sign_decode':('lcuf.compression.component',1)}
AFFINE={'Residual','EFBundle'}

class Diagnostic(ValueError): pass
def fail(message,line=None):raise Diagnostic((f'line {line}: ' if line else '')+message)
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(x):return hashlib.sha256(canonical(x).encode('utf-8')).hexdigest()
def strict_json(raw):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:fail('duplicate JSON key')
            result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:fail('nonfinite JSON literal'))
def identifier(x,line=None):
    if not IDENT.fullmatch(x):fail('invalid identifier',line)
    return x
def positive(x,line=None):
    if not re.fullmatch(r'[1-9][0-9]{0,18}',x) or int(x)>MAX:fail('positive ASCII i64 resource required',line)
    return int(x)
def names(x,line=None,repeated=False):
    if x=='-':return []
    parts=x.split(',')
    if not repeated and len(parts)!=len(set(parts)):fail('duplicate list item',line)
    return [identifier(p,line) for p in parts]

def typ(text):
    if text in ('i64','f64','bool','text','unit'):return (text,)
    patterns=[('Zp',r'Zp\[([1-9][0-9]*),([1-9][0-9]*)\]'),('Vec',r'Vec\[f64,([1-9][0-9]*)\]'),
      ('PField',r'PField\[([1-9][0-9]*),([1-9][0-9]*)\]'),('Raster',r'Raster\[u8,([1-9][0-9]*),([1-9][0-9]*),([1-9][0-9]*)\]'),
      ('SignPacket',r'SignPacket\[([1-9][0-9]*)\]'),('Residual',r'Residual\[([1-9][0-9]*)\]'),('EFBundle',r'EFBundle\[([1-9][0-9]*)\]')]
    for kind,pattern in patterns:
        match=re.fullmatch(pattern,text)
        if not match:continue
        if any(len(s)>5 for s in match.groups()):fail('type parameter outside bounded research domain')
        values=tuple(map(int,match.groups()))
        try:
            if kind in ('Zp','PField'):
                m=K.modulus(*values)
                if kind=='PField' and m>256:fail('PField cardinality exceeds 256')
            elif kind=='Raster':
                w,h,c=values
                if w*h*c>4096 or c not in (1,3,4):fail('bounded raster dimensions required')
            elif not 1<=values[0]<=256:fail('bounded vector length 1..256 required')
        except K.KernelError as error:fail(str(error))
        return (kind,*values)
    fail('unsupported research type '+text)

def check(value,t,literal=False):
    kind=t[0]
    try:
        if kind=='i64':
            if type(value) is not int or not MIN<=value<=MAX:fail('i64 bounds or scalar type')
        elif kind=='f64':K.real(value)
        elif kind=='bool':
            if type(value) is not bool:fail('Boolean scalar required')
        elif kind=='text':
            if type(value) is not str:fail('Unicode text required')
            value.encode('utf-8')
        elif kind=='unit':
            if value is not None:fail('unit value required')
        elif kind=='Zp':K.residue(value,*t[1:])
        elif kind in ('Vec','Residual'):
            K.vector(value,t[1])
            if literal and kind=='Residual' and any(x!=0 for x in value):fail('only zero initial residual literals admitted')
        elif kind=='PField':K.vector(value,t[1]**t[2])
        elif kind=='Raster':K.raster_shift(value,*t[1:],0)
        elif kind=='SignPacket':
            if literal:fail('packet literals are not admitted')
            K.packet_bytes(value)
            if value['length']!=t[1]:fail('sign packet type length mismatch')
        elif kind=='EFBundle':
            if literal:fail('bundle literals are not admitted')
            if type(value) is not dict or set(value)!={'wire','local_residual'}:fail('EFBundle structure required')
            check(value['wire'],('SignPacket',t[1]));check(value['local_residual'],('Residual',t[1]))
    except (K.KernelError,UnicodeError,OverflowError,TypeError,ValueError) as error:
        if isinstance(error,Diagnostic):raise
        fail(str(error))

def size(t,literal=None):
    kind=t[0]
    if kind in ('i64','f64'):return 8
    if kind=='bool':return 1
    if kind=='unit':return 0
    if kind=='text':return len(literal.encode('utf-8')) if literal is not None else None
    if kind=='Zp':return ((t[1]**t[2]-1).bit_length()+7)//8
    if kind in ('Vec','Residual'):return 8*t[1]
    if kind=='PField':return 8*t[1]**t[2]
    if kind=='Raster':return t[1]*t[2]*t[3]
    if kind=='SignPacket':return 16+(t[1]+7)//8
    if kind=='EFBundle':return 16+(t[1]+7)//8+8*t[1]

def normalized(value,t):
    if t[0]=='f64':return K.real(value)
    if t[0] in ('Vec','Residual'):return K.vector(value,t[1])
    if t[0]=='PField':return K.vector(value,t[1]**t[2])
    return value

def authority(op):
    if op=='copy':return {'fabric.transfer'},{'fabric.receive'}
    if op=='emit':return {'evidence.emit'},{'evidence.write'}
    if op in ('ef_pack','ef_wire','ef_residual'):return {'optimizer.local_state'},{'optimizer.state'}
    return set(),set()

def parse(source):
    if type(source) is str:raw=source.encode('utf-8')
    elif type(source) is bytes:raw=source
    else:fail('source bytes or text required')
    if len(raw)>1048576:fail('source exceeds 1 MiB host research limit')
    try:text=raw.decode('utf-8-sig')
    except UnicodeError:fail('UTF-8 source required')
    lines=[(i,line.strip()) for i,line in enumerate(text.split('\n'),1) if line.strip() and not line.strip().startswith('#')]
    if not lines or lines[0][1]!=LANGUAGE:fail('required header '+LANGUAGE)
    module=None;sites={};grants={};links=[];rows=[];in_rows=False;ended=False
    for line,text in lines[1:]:
        if ended:fail('content after end',line)
        if text=='end':ended=True;continue
        if module is None and not text.startswith('module '):fail('module must be first',line)
        if not in_rows:
            if text.startswith('module '):
                parts=text.split()
                if module is not None or len(parts)!=2:fail('one module identifier required',line)
                module=identifier(parts[1],line)
            elif text.startswith('site '):
                match=re.fullmatch(r'site (\S+) trust=(\S+) memory=([0-9]+) steps=([0-9]+)',text)
                if not match:fail('site declaration shape',line)
                name,trust,memory,steps=match.groups();identifier(name,line);identifier(trust,line)
                if name in sites:fail('duplicate site',line)
                sites[name]={'trust':trust,'memory':positive(memory,line),'steps':positive(steps,line)}
            elif text.startswith('grant '):
                match=re.fullmatch(r'grant (\S+) caps=(\S+)',text)
                if not match:fail('grant declaration shape',line)
                site,caps=match.groups();identifier(site,line)
                if site in grants:fail('duplicate grant',line)
                grants[site]=names(caps,line)
            elif text.startswith('link '):
                match=re.fullmatch(r'link (\S+) (\S+) transfer=copy',text)
                if not match:fail('directed copy link shape',line)
                a,b=match.groups();identifier(a,line);identifier(b,line)
                if a==b or (a,b) in links:fail('duplicate or self link',line)
                links.append((a,b))
            elif [x.strip() for x in text.split('|')]==COLUMNS:in_rows=True
            else:fail('unknown declaration or columns',line)
        else:
            cells=[x.strip() for x in text.split('|')]
            if len(cells)!=12:fail('twelve column cells required',line)
            row=dict(zip(COLUMNS,cells));row['line']=line
            for field in ('id','site','profile'):identifier(row[field],line)
            if row['op'] not in OPS:fail('unsupported operation',line)
            typ(row['type'])
            if row['output']!='-':identifier(row['output'],line)
            for field in ('effects','caps','after'):row[field]=names(row[field],line)
            row['budget']=positive(row['budget'],line)
            if row['evidence'] not in ('none','receipt'):fail('evidence must be none or receipt',line)
            if row['op']=='const':
                try:row['literal']=strict_json(row['inputs'])
                except (ValueError,TypeError,RecursionError):fail('strict bounded JSON literal required',line)
                row['inputs']=[]
            else:row['inputs']=names(row['inputs'],line,True)
            rows.append(row)
            if len(rows)>1024:fail('host row limit 1024')
    if not ended or not module or not sites or not rows or not in_rows:fail('complete module/sites/rows/end required')
    return raw,{'language':LANGUAGE,'module':module,'sites':sites,'grants':grants,'links':links,'rows':rows}

def signature(op,out,args):
    kinds=[t[0] for t in args]
    if op=='const':return
    if op in ('emit','assert_eq'):
        if out!=('unit',):fail('terminal output type unit required')
        if op=='assert_eq' and args[0]!=args[1]:fail('assertion operand type mismatch')
    elif op in ('add','mul'):
        if out!=('i64',) or args!=[out,out]:fail('scalar arithmetic requires i64 operands')
    elif op=='copy':
        if args!=[out]:fail('copy preserves exact type')
        if out[0] in AFFINE:fail('owner-affine optimizer state cannot cross sites')
    elif op in ('padic_add','padic_mul'):
        if out[0]!='Zp' or args!=[out,out]:fail('equal radix and precision Zp operands required')
    elif op=='padic_val':
        if out!=('i64',) or kinds!=['Zp']:fail('valuation requires Zp to i64')
    elif op=='padic_from_i64':
        if out[0]!='Zp' or args!=[('i64',)]:fail('explicit i64 to finite residue conversion required')
    elif op=='padic_reduce':
        if out[0]!='Zp' or kinds!=['Zp'] or out[1]!=args[0][1] or not out[2]<args[0][2]:fail('explicit same-radix precision reduction required')
    elif op=='padic_average':
        if out[0]!='PField' or args!=[out,('i64',)]:fail('finite field plus i64 coset level required')
    elif op in ('hrr_bind','hrr_correlate'):
        if out[0]!='Vec' or args!=[out,out]:fail('matching real vector operands required')
    elif op=='permute':
        if out[0]!='Vec' or args!=[out,('i64',)]:fail('vector and explicit integer shift required')
    elif op=='diffuse_step':
        if out[0]!='Vec' or args!=[out,('f64',)]:fail('periodic vector plus f64 step required')
    elif op=='raster_shift':
        if out[0]!='Raster' or args!=[out,('i64',)]:fail('raster plus i64 horizontal shift required')
    elif op=='ef_pack':
        if out[0]!='EFBundle' or args!=[('Vec',out[1]),('Residual',out[1])]:fail('typed vector/local residual packing required')
    elif op in ('ef_wire','ef_residual'):
        want='SignPacket' if op=='ef_wire' else 'Residual'
        if out[0]!=want or args!=[('EFBundle',out[1])]:fail('bundle extraction type mismatch')
    elif op=='sign_decode':
        if out[0]!='Vec' or args!=[('SignPacket',out[1])]:fail('sign packet/vector type mismatch')

def costs(op,t,args):
    kind=t[0];n=t[1] if kind in ('Vec','Residual','SignPacket','EFBundle') else t[1]**t[2] if kind=='PField' else 1
    if op in ('hrr_bind','hrr_correlate'):return n*n,8*n
    if op=='padic_average':return 2*n,16*n
    if op=='diffuse_step':return 5*n,8*n
    if op=='ef_pack':return 6*n,24*n
    if op in ('ef_wire','ef_residual','sign_decode','permute'):return n,8*n
    if op=='raster_shift':return size(t),size(t)
    if op in ('padic_add','padic_mul','padic_reduce','padic_val','padic_from_i64'):
        ring=args[0] if op in ('padic_reduce','padic_val') else t;words=((ring[1]**ring[2]-1).bit_length()+63)//64
        return max(1,words*words),8*words
    return 1,0

def evaluate(op,args,t,literal=None):
    try:
        if op=='const':value=literal
        elif op=='add':value=args[0]+args[1]
        elif op=='mul':value=args[0]*args[1]
        elif op=='copy':value=args[0]
        elif op=='assert_eq':
            if canonical(args[0])!=canonical(args[1]):fail('typed assertion fails')
            value=None
        elif op=='emit':value=None
        elif op=='padic_add':value=K.residue_add(*args,*t[1:])
        elif op=='padic_mul':value=K.residue_mul(*args,*t[1:])
        elif op=='padic_from_i64':value=K.residue_from_i64(args[0],*t[1:])
        elif op=='padic_val':value=K.residue_valuation(args[0]['value'],args[0]['p'],args[0]['n'])
        elif op=='padic_reduce':value=K.residue_reduce(args[0]['value'],args[0]['p'],args[0]['n'],t[2])
        elif op=='padic_average':value=K.padic_average(args[0],*t[1:],args[1])
        elif op=='hrr_bind':value=K.hrr_bind(*args)
        elif op=='hrr_correlate':value=K.hrr_correlate(*args)
        elif op=='permute':value=K.permute(*args)
        elif op=='diffuse_step':value=K.diffuse_step(*args)
        elif op=='raster_shift':value=K.raster_shift(args[0],*t[1:],args[1])
        elif op=='ef_pack':value=K.sign_pack(*args)
        elif op=='ef_wire':value=args[0]['wire']
        elif op=='ef_residual':value=args[0]['local_residual']
        elif op=='sign_decode':value=K.sign_decode(args[0])
        else:fail('unknown kernel')
        value=normalized(value,t);check(value,t);return value
    except K.KernelError as error:fail(str(error))

def compile_source(source):
    raw,p=parse(source);rows=p['rows'];sites=p['sites'];grants=p['grants'];links=p['links'];by_id={};outputs={};steps={s:0 for s in sites}
    if any(s not in sites for s in grants) or any(a not in sites or b not in sites for a,b in links):fail('unknown grant/link site')
    for row in rows:
        line=row['line'];op=row['op'];t=typ(row['type']);site=row['site']
        if row['id'] in by_id:fail('duplicate row id',line)
        by_id[row['id']]=row
        if site not in sites:fail('unknown row site',line)
        if row['profile']!=OPS[op][0] or len(row['inputs'])!=OPS[op][1]:fail('profile or operation arity mismatch',line)
        if op in ('assert_eq','emit'):
            if t!=('unit',) or row['output']!='-':fail('terminal shape mismatch',line)
        elif t==('unit',) or row['output']=='-':fail('typed value output required',line)
        if row['output']!='-':
            if row['output'] in outputs:fail('multiple output writers',line)
            outputs[row['output']]=row
        effects,caps=authority(op)
        if set(row['effects'])!=effects or set(row['caps'])!=caps or not caps.issubset(grants.get(site,[])):fail('effects/capability contract denied',line)
        if op=='emit' and row['evidence']!='receipt':fail('emit requires receipt',line)
        if op=='const':
            check(row['literal'],t,True);row['literal']=normalized(row['literal'],t)
        steps[site]+=row['budget']
    deps={r['id']:set(r['after']) for r in rows};types={name:typ(r['type']) for name,r in outputs.items()}
    out_sizes={};scratch={s:0 for s in sites};minimum={}
    for r in rows:
        op=r['op'];t=typ(r['type']);line=r['line'];site=r['site'];producers=[]
        for name in r['inputs']:
            if name not in outputs:fail('undefined input',line)
            producer=outputs[name];producers.append(producer);deps[r['id']].add(producer['id'])
            if producer['site']!=site:
                if op!='copy' or (producer['site'],site) not in links or 'fabric.send' not in grants.get(producer['site'],[]):fail('directed transfer/sender authority denied',line)
            elif op=='copy':fail('copy requires remote owner',line)
        signature(op,t,[types[name] for name in r['inputs']])
        if any(x not in by_id for x in deps[r['id']]):fail('undefined dependency',line)
        if any(by_id[x]['site']!=site for x in r['after']):fail('after must name local rows',line)
        work,temp=costs(op,t,[types[name] for name in r['inputs']]);minimum[r['id']]=work;scratch[site]=max(scratch[site],temp)
        if r['budget']<work:fail('kernel work reservation below modeled minimum',line)
    remaining=set(by_id);order=[]
    while remaining:
        ready=sorted(r for r in remaining if deps[r].isdisjoint(remaining))
        if not ready:fail('dependency cycle')
        chosen=ready[0];remaining.remove(chosen);order.append(chosen)
    retained={s:0 for s in sites}
    for rid in order:
        r=by_id[rid];t=typ(r['type'])
        if r['output']=='-':continue
        count=size(t,r.get('literal'))
        if count is None:
            if r['op']!='copy':fail('text size lineage required')
            count=out_sizes[r['inputs'][0]]
        out_sizes[r['output']]=count;retained[r['site']]+=count
    for site in sites:
        if steps[site]>sites[site]['steps']:fail('site step reservation exceeded')
        if retained[site]+scratch[site]>sites[site]['memory']:fail('site payload plus peak scratch reservation exceeded')
    values={}
    for rid in order:
        r=by_id[rid];args=[values[name] for name in r['inputs']];t=typ(r['type'])
        if r['op'] in ('padic_reduce','padic_val'):
            src=types[r['inputs'][0]];args=[{'value':args[0],'p':src[1],'n':src[2]}]
        value=evaluate(r['op'],args,t,r.get('literal'))
        if r['output']!='-':values[r['output']]=value
    implementation={'compiler_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'kernels_sha256':hashlib.sha256(pathlib.Path(K.__file__).read_bytes()).hexdigest()}
    ir={'language':LANGUAGE,'module':p['module'],'sites':sites,'grants':{s:sorted(c) for s,c in grants.items()},'links':[{'from':a,'to':b,'transfer':'copy'} for a,b in sorted(links)],'rows':[{k:(sorted(v) if k in ('effects','caps','after') else v) for k,v in by_id[rid].items() if k!='line'} for rid in order],'admission':{'reserved_work':steps,'retained_payload_bytes':retained,'peak_modeled_scratch_bytes':scratch,'minimum_row_work':minimum},'compiler_version':VERSION,'profile_contracts':{op:{'profile':profile,'arity':arity} for op,(profile,arity) in sorted(OPS.items())},'reference_implementation':implementation,'implementation_scope':'single_process_host_research'}
    return {'ir':ir,'source_sha256':hashlib.sha256(raw).hexdigest(),'semantic_sha256':digest(ir),'preview_values':values}

def run_source(source):
    c=compile_source(source);ir=c['ir'];values={};types={r['output']:typ(r['type']) for r in ir['rows'] if r['output']!='-'};receipts=[];previous='0'*64
    for r in ir['rows']:
        args=[values[x] for x in r['inputs']];t=typ(r['type'])
        if r['op'] in ('padic_reduce','padic_val'):
            src=types[r['inputs'][0]];args=[{'value':args[0],'p':src[1],'n':src[2]}]
        value=evaluate(r['op'],args,t,r.get('literal'))
        if r['output']!='-':values[r['output']]=value
        if r['evidence']=='receipt':
            result=value if r['op']!='emit' else args[0]
            receipt={'scope':'LCUF_X_HOST_RESEARCH','row':r['id'],'site':r['site'],'profile':r['profile'],'semantic_sha256':c['semantic_sha256'],'previous_sha256':previous,'result_sha256':digest(result)}
            previous=digest(receipt);receipts.append({**receipt,'sha256':previous})
    if canonical(values)!=canonical(c['preview_values']):fail('compile/evaluate deterministic disagreement')
    return {'status':'host_research_pass','source_sha256':c['source_sha256'],'semantic_sha256':c['semantic_sha256'],'values':values,'admission':ir['admission'],'row_order':[r['id'] for r in ir['rows']],'receipts':receipts,'receipt_chain_head':previous,'native_unikernel_built':False,'authenticated_network_executed':False,'physical_optics_executed':False,'full_onebit_lamb_executed':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('command',choices=['check','compile','run']);parser.add_argument('source',type=pathlib.Path);args=parser.parse_args()
    try:
        raw=args.source.read_bytes();result=run_source(raw) if args.command=='run' else compile_source(raw)
        if args.command=='check':result={'status':'host_static_admission_pass','semantic_sha256':result['semantic_sha256']}
        print(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False));sys.exit(0)
    except (Diagnostic,K.KernelError,OSError,UnicodeError,ValueError) as error:
        print(json.dumps({'status':'rejected','diagnostic':str(error)}));sys.exit(2)
