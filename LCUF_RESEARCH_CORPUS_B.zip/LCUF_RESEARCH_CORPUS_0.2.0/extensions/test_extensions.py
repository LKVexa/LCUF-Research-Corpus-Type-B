import base64,copy,math,pathlib,struct,sys,unittest
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'extensions'));sys.path.insert(0,str(ROOT/'tools'))
import math_kernels as K
import lcuf_x as X
import build_extension_cases as B

class MathematicalKernels(unittest.TestCase):
    def test_quotient_wrap(self):self.assertEqual(K.residue_add(8,8,3,2),7)
    def test_quotient_product(self):self.assertEqual(K.residue_mul(8,8,3,2),1)
    def test_signed_conversion_loss(self):self.assertEqual(K.residue_from_i64(-1,2,4),15)
    def test_zero_capped_valuation(self):self.assertEqual(K.residue_valuation(0,3,4),4)
    def test_nonzero_valuation(self):self.assertEqual(K.residue_valuation(18,3,4),2)
    def test_mod2_sign_alias(self):self.assertEqual(K.residue_from_i64(-1,2,1),K.residue_from_i64(1,2,1))
    def test_no_boolean_residue(self):
        with self.assertRaises(K.KernelError):K.residue(True,2,3)
    def test_no_boolean_vector_length(self):
        with self.assertRaises(K.KernelError):K.vector([1.],True)
    def test_not_a_prime_field(self):self.assertEqual(K.residue_mul(3,3,3,2),0)
    def test_no_composite_radix(self):
        with self.assertRaises(K.KernelError):K.residue(1,4,2)
    def test_no_inferred_precision_lift(self):
        with self.assertRaises(K.KernelError):K.residue_reduce(1,2,2,3)
    def test_low_digit_coset(self):self.assertEqual(K.padic_average(list(range(8)),2,3,1),[3.,4.]*4)
    def test_projection_composition(self):
        xs=[float(i*i) for i in range(8)]
        self.assertEqual(K.padic_average(K.padic_average(xs,2,3,2),2,3,1),K.padic_average(xs,2,3,1))
    def test_projection_idempotence(self):
        xs=K.padic_average(list(range(8)),2,3,1);self.assertEqual(K.padic_average(xs,2,3,1),xs)
    def test_projection_identity(self):self.assertEqual(K.padic_average(list(range(8)),2,3,3),[float(i) for i in range(8)])
    def test_hrr_identity_key(self):self.assertEqual(K.hrr_bind([2.,3.,5.,7.],[1.,0.,0.,0.]),[2.,3.,5.,7.])
    def test_hrr_correlation_is_not_general_inverse(self):
        a=[1.,0.,2.,0.];key=[1.,1.,0.,0.];self.assertEqual(K.hrr_correlate(K.hrr_bind(a,key),key),[2.,3.,4.,3.])
    def test_cyclic_roles_remain_commutative(self):
        a=[1.,2.,0.,0.];b=[0.,1.,3.,0.]
        self.assertEqual(K.hrr_bind(K.permute(a,1),K.permute(b,2)),K.hrr_bind(K.permute(b,1),K.permute(a,2)))
    def test_periodic_mass(self):
        out=K.diffuse_step([1.,0.,0.,0.],.25);self.assertEqual(out,[.5,.25,0.,.25]);self.assertEqual(sum(out),1.)
    def test_diffusion_stability_admission(self):
        with self.assertRaises(K.KernelError):K.diffuse_step([1.,0.],.51)
    def test_raster_exact_indexing(self):self.assertEqual(K.raster_shift([0,1,2,3],2,2,1,1),[1,0,3,2])
    def test_raster_dimensions_require_exact_integers(self):
        for dimensions in [(True,1,1),(1,True,1),(1,1,True),(1.,1,1)]:
            with self.assertRaises(K.KernelError):K.raster_shift([9],*dimensions,0)
    def test_nonfinite_products_deny(self):
        with self.assertRaises(K.KernelError):K.hrr_bind([1e308],[1e308])

class SignCodecAndPhase(unittest.TestCase):
    def test_wire_golden_bytes(self):
        packet=K.sign_pack([1.,-1.,1.,-1.],[0.]*4)['wire'];self.assertEqual(K.packet_bytes(packet),b'LSG1'+struct.pack('<Id',4,1.)+b'\x05')
    def test_residual_recurrence(self):
        bundle=K.sign_pack([1.,0.,0.,0.],[0.]*4);self.assertEqual(bundle['local_residual'],[.5,-.5,-.5,-.5]);self.assertEqual(K.sign_decode(bundle['wire']),[.5]*4)
    def test_zero_scale_and_sign(self):
        bundle=K.sign_pack([0.,-0.],[0.,0.]);self.assertEqual(K.packet_bytes(bundle['wire']),b'LSG1'+struct.pack('<Id',2,0.)+b'\x03')
    def test_scale_robust_to_large_finite_norm(self):
        packet=K.sign_pack([1e308]*256,[0.]*256)['wire'];self.assertEqual(packet['scale'],1e308)
    def test_wire_excludes_residual(self):
        wire=K.sign_pack([1.,0.,0.,0.],[0.]*4)['wire'];self.assertEqual(set(wire),{'codec','length','scale','bits_base64'});self.assertEqual(len(K.packet_bytes(wire)),17)
    def test_padding_deny(self):
        packet=K.sign_pack([1.,1.],[0.,0.])['wire'];packet['bits_base64']=base64.b64encode(b'\x83').decode()
        with self.assertRaises(K.KernelError):K.packet_bytes(packet)
    def test_negative_zero_scale_deny(self):
        with self.assertRaises(K.KernelError):K.packet_from_bytes(b'LSG1'+struct.pack('<Id',1,-0.)+b'\x01')
    def test_truncated_wire_deny(self):
        with self.assertRaises(K.KernelError):K.packet_from_bytes(b'LSG1'+struct.pack('<Id',9,1.)+b'\x01')
    def test_wire_roundtrip(self):
        packet=K.sign_pack([1.,-2.,3.],[0.]*3)['wire'];self.assertEqual(K.packet_from_bytes(K.packet_bytes(packet)),packet)
    def test_phase_boundary(self):
        state=K.CompressionPhase(2,4,'a'*64);self.assertEqual(state.advance(0)['phase'],'warmup');self.assertEqual(state.advance(1)['phase'],'warmup');self.assertEqual(state.advance(2,'b'*64)['epoch'],1);self.assertEqual(state.advance(3)['phase'],'compressed')
    def test_freeze_requires_digest(self):
        state=K.CompressionPhase(1,3,'a'*64);state.advance(0)
        with self.assertRaises(K.KernelError):state.advance(1)
        self.assertEqual(state.step,1);self.assertEqual(state.phase,'warmup')
    def test_replayed_step_denied(self):
        state=K.CompressionPhase(1,3,'a'*64);state.advance(0)
        with self.assertRaises(K.KernelError):state.advance(0)

class LanguageAdmission(unittest.TestCase):
    def test_golden_profile_population(self):
        for family in B.POSITIVE:
            raw,expected=B.positive(family,0);observed=X.run_source(raw)
            self.assertTrue(all(B.equal(value,observed['values'][name]) for name,value in expected.items()),family)
    def test_negative_boundaries(self):
        for family in B.NEGATIVE:
            raw,diagnostic=B.negative(family,0)
            with self.assertRaisesRegex(X.Diagnostic,diagnostic):X.compile_source(raw)
    def test_normalized_float_identity(self):
        raw,other,_=B.paired('typed_float_literal_normalization',0);self.assertEqual(X.compile_source(raw)['semantic_sha256'],X.compile_source(other)['semantic_sha256'])
    def test_scratch_is_admitted_before_evaluation(self):
        raw,_=B.negative('payload_scratch_underreserve',0);saved=X.evaluate;X.evaluate=lambda *a,**k:self.fail('evaluation ran before static resource denial')
        try:
            with self.assertRaisesRegex(X.Diagnostic,'peak scratch'):X.compile_source(raw)
        finally:X.evaluate=saved
    def test_owner_affine_residual_deny(self):
        raw,_=B.negative('residual_transfer',0)
        with self.assertRaisesRegex(X.Diagnostic,'owner-affine'):X.compile_source(raw)
    def test_boolean_integer_assertion_type(self):
        raw=B.program('bad',[B.const('a','x',True,'bool'),B.const('b','y',1),B.row('c','assert_eq','x,y','-','unit')])
        with self.assertRaisesRegex(X.Diagnostic,'type mismatch'):X.compile_source(raw)
    def test_text_copy_payload_lineage(self):
        raw=B.program('text',[B.const('a','x','λ','text'),B.row('b','copy','x','y','text',site='t')],remote=True);out=X.run_source(raw);self.assertEqual(out['admission']['retained_payload_bytes'],{'s':2,'t':2})
    def test_receipts_bind_local_origin(self):
        raw,_=B.positive('remote_wire',0);out=X.run_source(raw);self.assertTrue(out['receipts']);self.assertTrue(all(r['scope']=='LCUF_X_HOST_RESEARCH' for r in out['receipts']));self.assertFalse(out['authenticated_network_executed'])
    def test_physical_op_is_not_admitted(self):
        raw,_=B.negative('unsupported_physical_op',0)
        with self.assertRaises(X.Diagnostic):X.compile_source(raw)

if __name__=='__main__':unittest.main()
