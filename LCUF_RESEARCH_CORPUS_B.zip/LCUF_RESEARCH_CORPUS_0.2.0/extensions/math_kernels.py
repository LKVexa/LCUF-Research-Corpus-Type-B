"""Bounded host research kernels. No physical optics, network or full optimizer."""
from __future__ import annotations
import base64, math, struct

class KernelError(ValueError): pass

def integer(x):
    if type(x) is not int: raise KernelError('integer required; Boolean is not an integer')
    return x

def real(x):
    if type(x) not in (int,float): raise KernelError('finite real scalar required')
    try: value=float(x)
    except (ValueError,OverflowError) as error: raise KernelError('finite binary64 domain') from error
    if not math.isfinite(value): raise KernelError('finite binary64 domain')
    return value

def prime(p):
    integer(p)
    if not 2<=p<=257 or any(p%d==0 for d in range(2,math.isqrt(p)+1)): raise KernelError('prime radix in 2..257 required')
    return p

def modulus(p,n):
    prime(p);integer(n)
    if not 1<=n<=16:raise KernelError('residue precision in 1..16 required')
    return p**n

def residue(x,p,n):
    m=modulus(p,n);integer(x)
    if not 0<=x<m:raise KernelError('canonical residue outside 0..p^n-1')
    return x

def residue_add(a,b,p,n):return (residue(a,p,n)+residue(b,p,n))%modulus(p,n)
def residue_mul(a,b,p,n):return (residue(a,p,n)*residue(b,p,n))%modulus(p,n)
def residue_from_i64(x,p,n):
    integer(x)
    if not -(2**63)<=x<=2**63-1:raise KernelError('signed i64 input required')
    return x%modulus(p,n)
def residue_valuation(x,p,n):
    residue(x,p,n)
    if x==0:return n
    value=0
    while x%p==0:x//=p;value+=1
    return value

def residue_reduce(x,p,n,target_n):
    residue(x,p,n);integer(target_n)
    if not 1<=target_n<n:raise KernelError('explicit precision reduction required; no inferred refinement')
    return x%modulus(p,target_n)

def vector(xs,n=None):
    if n is not None:integer(n)
    if type(xs) is not list or not 1<=len(xs)<=256 or (n is not None and len(xs)!=n):raise KernelError('bounded nonempty vector shape')
    return [real(x) for x in xs]

def total(xs):
    try:return real(math.fsum(xs))
    except (OverflowError,ValueError) as error:raise KernelError('nonfinite numerical result') from error

def hrr_bind(a,b):
    a=vector(a);b=vector(b,len(a));n=len(a)
    return [total(real(a[i]*b[(k-i)%n]) for i in range(n)) for k in range(n)]

def hrr_correlate(bound,key):
    bound=vector(bound);key=vector(key,len(bound));n=len(bound)
    return [total(real(bound[(k+i)%n]*key[i]) for i in range(n)) for k in range(n)]

def permute(xs,shift):
    xs=vector(xs);integer(shift);n=len(xs)
    return [xs[(k-shift)%n] for k in range(n)]

def diffuse_step(xs,alpha):
    xs=vector(xs);alpha=real(alpha)
    if not 0<=alpha<=0.5:raise KernelError('periodic diffusion requires alpha in [0,1/2]')
    n=len(xs)
    return [total([real((1-2*alpha)*xs[i]),real(alpha*xs[(i-1)%n]),real(alpha*xs[(i+1)%n])]) for i in range(n)]

def padic_average(xs,p,n,k):
    m=modulus(p,n);integer(k)
    if m>256 or not 0<=k<=n:raise KernelError('bounded finite p-adic field and coset level required')
    xs=vector(xs,m);blocks=p**k;size=m//blocks
    averages=[real(total(xs[i] for i in range(r,m,blocks))/size) for r in range(blocks)]
    return [averages[i%blocks] for i in range(m)]

def raster_shift(pixels,width,height,channels,shift):
    integer(shift);integer(width);integer(height);integer(channels)
    if type(pixels) is not list or len(pixels)!=width*height*channels or any(type(x) is not int or not 0<=x<=255 for x in pixels):raise KernelError('exact u8 raster required')
    if width<=0 or height<=0 or channels not in (1,3,4) or len(pixels)>4096:raise KernelError('bounded raster shape required')
    return [pixels[((y*width+(x-shift)%width)*channels+c)] for y in range(height) for x in range(width) for c in range(channels)]

def sign_pack(xs,residual):
    """RMS sign codec component; residual remains local, not in the wire packet."""
    xs=vector(xs);residual=vector(residual,len(xs));z=[real(a+b) for a,b in zip(xs,residual)];n=len(z)
    peak=max(abs(x) for x in z)
    scale=real(peak*math.sqrt(total((x/peak)**2 for x in z)/n)) if peak else 0.0
    bits=bytearray((n+7)//8)
    for i,x in enumerate(z):
        if x>=0:bits[i//8]|=1<<(i%8)
    decoded=[scale if bits[i//8]>>(i%8)&1 else -scale for i in range(n)]
    remaining=[real(x-y) for x,y in zip(z,decoded)]
    packet={'codec':'lcuf.rms-sign/1','length':n,'scale':scale,'bits_base64':base64.b64encode(bits).decode('ascii')}
    return {'wire':packet,'local_residual':remaining}

def packet_bytes(packet):
    if type(packet) is not dict or set(packet)!={'codec','length','scale','bits_base64'} or packet['codec']!='lcuf.rms-sign/1':raise KernelError('invalid sign packet contract')
    n=integer(packet['length']);scale=real(packet['scale'])
    if not 1<=n<=256 or scale<0:raise KernelError('invalid packet dimensions or scale')
    if scale==0.0 and math.copysign(1.0,scale)<0:raise KernelError('negative zero scale is not canonical')
    try:bits=base64.b64decode(packet['bits_base64'],validate=True)
    except (TypeError,ValueError) as error:raise KernelError('invalid packed signs') from error
    if len(bits)!=(n+7)//8 or (n%8 and bits[-1]>>(n%8)):raise KernelError('packet length or padding bits mismatch')
    if base64.b64encode(bits).decode('ascii')!=packet['bits_base64']:raise KernelError('noncanonical base64 signs')
    return b'LSG1'+struct.pack('<Id',n,scale)+bits

def sign_decode(packet):
    raw=packet_bytes(packet);n=packet['length'];scale=real(packet['scale']);bits=raw[16:]
    return [scale if bits[i//8]>>(i%8)&1 else -scale for i in range(n)]

def packet_from_bytes(raw):
    if type(raw) is not bytes or len(raw)<17 or raw[:4]!=b'LSG1':raise KernelError('invalid packet byte header')
    n,scale=struct.unpack('<Id',raw[4:16]);packet={'codec':'lcuf.rms-sign/1','length':n,'scale':scale,'bits_base64':base64.b64encode(raw[16:]).decode('ascii')}
    if packet_bytes(packet)!=raw:raise KernelError('noncanonical packet bytes')
    return packet

class CompressionPhase:
    """Research phase-admission guard, not LAMB update mathematics or collectives."""
    def __init__(self,freeze_step,total_steps,contract_sha256):
        integer(freeze_step);integer(total_steps)
        if not 0<freeze_step<total_steps:raise KernelError('nonempty warmup and compressed horizons required')
        if type(contract_sha256) is not str or len(contract_sha256)!=64 or any(c not in '0123456789abcdef' for c in contract_sha256):raise KernelError('explicit contract digest required')
        self.freeze_step=freeze_step;self.total_steps=total_steps;self.contract_sha256=contract_sha256;self.step=0;self.phase='warmup';self.frozen_state_sha256=None;self.epoch=0
    def advance(self,expected_step,frozen_state_sha256=None):
        integer(expected_step)
        if expected_step!=self.step or self.step>=self.total_steps:raise KernelError('stale or exhausted optimizer step')
        if self.phase=='warmup' and self.step==self.freeze_step:
            if type(frozen_state_sha256) is not str or len(frozen_state_sha256)!=64 or any(c not in '0123456789abcdef' for c in frozen_state_sha256):raise KernelError('freeze transition requires state digest')
            self.frozen_state_sha256=frozen_state_sha256;self.phase='compressed';self.epoch+=1
        elif frozen_state_sha256 is not None:raise KernelError('freeze state only supplied at the transition')
        result={'step':self.step,'phase':self.phase,'epoch':self.epoch,'contract_sha256':self.contract_sha256,'frozen_state_sha256':self.frozen_state_sha256};self.step+=1
        return result
